package app.linkskip

import android.content.ClipboardManager
import android.content.Context
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.text.DateFormat
import java.util.Date

// ============================================================
//  ثيم بستايل iOS 16
// ============================================================

@Immutable
class IosColors(
    val bg: Color,
    val card: Color,
    val label: Color,
    val secondary: Color,
    val separator: Color,
    val accent: Color,
    val fill: Color,
    val segment: Color,
    val green: Color,
    val red: Color,
    val bar: Color
)

val LightIos = IosColors(
    bg = Color(0xFFF2F2F7),
    card = Color(0xFFFFFFFF),
    label = Color(0xFF000000),
    secondary = Color(0xFF8E8E93),
    separator = Color(0x4A3C3C43),
    accent = Color(0xFF007AFF),
    fill = Color(0x1F767680),
    segment = Color(0xFFFFFFFF),
    green = Color(0xFF34C759),
    red = Color(0xFFFF3B30),
    bar = Color(0xF2F9F9F9)
)

val DarkIos = IosColors(
    bg = Color(0xFF000000),
    card = Color(0xFF1C1C1E),
    label = Color(0xFFFFFFFF),
    secondary = Color(0xFF8E8E93),
    separator = Color(0x66545458),
    accent = Color(0xFF0A84FF),
    fill = Color(0x3D767680),
    segment = Color(0xFF636366),
    green = Color(0xFF30D158),
    red = Color(0xFFFF453A),
    bar = Color(0xF21C1C1E)
)

val LocalIos = staticCompositionLocalOf { LightIos }

@Composable
fun LinkSkipTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = if (dark) DarkIos else LightIos
    val scheme = if (dark) {
        darkColorScheme(primary = c.accent, background = c.bg, surface = c.card)
    } else {
        lightColorScheme(primary = c.accent, background = c.bg, surface = c.card)
    }
    CompositionLocalProvider(
        LocalIos provides c,
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

// ============================================================
//  مكوّنات صغيرة
// ============================================================

/** ضغطة بأسلوب iOS: بدون ripple، شفافية تنزل أثناء اللمس. */
@Composable
fun Modifier.iosClick(enabled: Boolean = true, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    return this
        .alpha(if (pressed) 0.55f else 1f)
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

@Composable
fun Gap(h: Dp) {
    Spacer(Modifier.height(h))
}

@Composable
fun LargeTitle(title: String, sub: String? = null) {
    val c = LocalIos.current
    Column(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 4.dp)) {
        Text(title, color = c.label, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        if (sub != null) {
            Text(sub, color = c.secondary, fontSize = 15.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text,
        color = LocalIos.current.secondary,
        fontSize = 13.sp,
        modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp)
    )
}

@Composable
fun Footer(text: String) {
    Text(
        text,
        color = LocalIos.current.secondary,
        fontSize = 13.sp,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp)
    )
}

@Composable
fun Group(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalIos.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.card),
        content = content
    )
}

@Composable
fun Hairline(inset: Dp = 16.dp) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = inset)
            .height(0.5.dp)
            .background(LocalIos.current.separator)
    )
}

@Composable
fun PrimaryButton(text: String, destructive: Boolean = false, onClick: () -> Unit) {
    val c = LocalIos.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .iosClick(true, onClick)
            .clip(RoundedCornerShape(14.dp))
            .background(if (destructive) c.red else c.accent),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalIos.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = c.label, fontSize = 17.sp)
            Text(sub, color = c.secondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = c.green,
                checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = c.fill,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalIos.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(c.fill)
            .padding(2.dp)
    ) {
        options.forEachIndexed { i, t ->
            val sel = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(32.dp)
                    .iosClick(true) { onSelect(i) }
                    .clip(RoundedCornerShape(7.dp))
                    .background(if (sel) c.segment else Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    t,
                    color = c.label,
                    fontSize = 13.sp,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
fun ProgressBar(fraction: Float) {
    val c = LocalIos.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(c.fill)
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(c.accent)
        )
    }
}

// ============================================================
//  الشاشة الرئيسية
// ============================================================

@Composable
fun App(e: SkipEngine) {
    val c = LocalIos.current
    BackHandler(enabled = e.tab != 0) { e.tab = 0 }
    Column(Modifier.fillMaxSize().background(c.bg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (e.tab) {
                0 -> SkipScreen(e)
                1 -> HistoryScreen(e)
                else -> SettingsScreen(e)
            }
        }
        TabBar(e.tab) { e.tab = it }
    }
}

@Composable
fun TabBar(selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalIos.current
    val items = listOf(
        "تخطّي" to Icons.Filled.Home,
        "السجل" to Icons.Filled.DateRange,
        "الإعدادات" to Icons.Filled.Settings
    )
    Column(Modifier.fillMaxWidth().background(c.bar).navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(c.separator))
        Row(Modifier.fillMaxWidth().height(52.dp)) {
            items.forEachIndexed { i, (label, icon) ->
                val sel = i == selected
                val tint = if (sel) c.accent else c.secondary
                Column(
                    Modifier.weight(1f).fillMaxHeight().iosClick(true) { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(25.dp))
                    Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

// ============================================================
//  تبويب: تخطّي
// ============================================================

@Composable
fun SkipScreen(e: SkipEngine) {
    val c = LocalIos.current
    val ctx = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        LargeTitle("تخطّي الإعلانات", "الصق رابط أي موقع تحميل واترك الباقي علينا")
        Gap(12.dp)

        Group {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = e.input,
                    onValueChange = { e.input = it },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(
                        color = c.label,
                        fontSize = 17.sp,
                        textDirection = TextDirection.Ltr,
                        textAlign = TextAlign.Left
                    ),
                    cursorBrush = SolidColor(c.accent),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { if (!e.running) e.start(e.input) }),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (e.input.isEmpty()) {
                                Text("https://…", color = c.secondary, fontSize = 17.sp)
                            }
                            inner()
                        }
                    }
                )
                Text(
                    "لصق",
                    color = c.accent,
                    fontSize = 17.sp,
                    modifier = Modifier
                        .padding(start = 12.dp)
                        .iosClick(true) {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = cm.primaryClip
                            val t = if (clip != null && clip.itemCount > 0) {
                                clip.getItemAt(0).coerceToText(ctx)?.toString()
                            } else null
                            if (!t.isNullOrBlank()) e.input = t.trim()
                        }
                )
            }
        }

        Gap(14.dp)
        PrimaryButton(
            text = if (e.running) "إيقاف" else "ابدأ التخطّي",
            destructive = e.running
        ) {
            if (e.running) e.stop() else e.start(e.input)
        }

        Gap(16.dp)
        StatusCard(e)

        SectionHeader("المتصفح المدمج")
        Box(
            Modifier
                .fillMaxWidth()
                .height(400.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(c.card)
        ) {
            AndroidView(
                factory = { _ ->
                    (e.web.parent as? ViewGroup)?.removeView(e.web)
                    e.web
                },
                modifier = Modifier.fillMaxSize()
            )
        }
        Footer("إذا ظهر كابتشا («أنا لست روبوت») حلّه بنفسك داخل المتصفح، والتطبيق يكمّل الباقي.")
        Gap(24.dp)
    }
}

@Composable
fun StatusCard(e: SkipEngine) {
    val c = LocalIos.current
    val active = e.history.firstOrNull { it.state == 0 }
    val last = e.history.firstOrNull()

    Group {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
                when {
                    e.running || active != null ->
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = c.accent,
                            strokeWidth = 2.dp
                        )
                    last != null && last.state == 1 ->
                        Icon(Icons.Filled.CheckCircle, null, tint = c.green, modifier = Modifier.size(26.dp))
                    last != null && last.state == 2 ->
                        Icon(Icons.Filled.Warning, null, tint = c.red, modifier = Modifier.size(26.dp))
                    else ->
                        Icon(Icons.Filled.Info, null, tint = c.secondary, modifier = Modifier.size(26.dp))
                }
            }
            Text(
                e.status,
                color = c.label,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f).padding(start = 12.dp)
            )
        }

        if (active != null) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                ProgressBar(if (active.progress >= 0) active.progress / 100f else 0f)
                Text(
                    if (active.progress >= 0) "${active.progress}%" else "…",
                    color = c.secondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        if (last != null && last.state == 1) {
            Hairline(0.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .iosClick(true) { e.openFile(last) }
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (last.name.endsWith(".apk", true)) "تثبيت التطبيق" else "فتح الملف",
                    color = c.accent,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

// ============================================================
//  تبويب: السجل
// ============================================================

@Composable
fun HistoryScreen(e: SkipEngine) {
    val c = LocalIos.current
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        LargeTitle("السجل")

        if (e.history.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
                Text("ما في تحميلات بعد", color = c.secondary, fontSize = 17.sp)
            }
        } else {
            Gap(8.dp)
            Group {
                e.history.forEachIndexed { index, item ->
                    if (index > 0) Hairline()
                    HistoryRow(item, e)
                }
            }
            Gap(14.dp)
            Box(
                Modifier.fillMaxWidth().iosClick(true) { e.clearHistory() }.padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("مسح السجل", color = c.red, fontSize = 17.sp)
            }
        }
        Gap(24.dp)
    }
}

@Composable
fun HistoryRow(item: DownloadItem, e: SkipEngine) {
    val c = LocalIos.current
    val time = remember(item.time) {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(item.time))
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                item.name,
                color = c.label,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(textDirection = TextDirection.Ltr)
            )
            val st = when (item.state) {
                0 -> "جاري التحميل " + (if (item.progress >= 0) "${item.progress}%" else "")
                1 -> "تم • $time"
                else -> "فشل • $time"
            }
            Text(st, color = if (item.state == 2) c.red else c.secondary, fontSize = 13.sp)
        }
        if (item.state == 1) {
            Text(
                if (item.name.endsWith(".apk", true)) "تثبيت" else "فتح",
                color = c.accent,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.iosClick(true) { e.openFile(item) }
            )
        }
        Icon(
            Icons.Filled.Delete,
            contentDescription = null,
            tint = c.secondary,
            modifier = Modifier
                .padding(start = 14.dp)
                .size(22.dp)
                .iosClick(true) { e.remove(item) }
        )
    }
}

// ============================================================
//  تبويب: الإعدادات
// ============================================================

@Composable
fun SettingsScreen(e: SkipEngine) {
    val c = LocalIos.current
    val speeds = listOf(1, 5, 12)
    val sel = speeds.indexOf(e.speed).let { if (it < 0) 1 else it }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        LargeTitle("الإعدادات")

        SectionHeader("التخطّي")
        Group {
            ToggleRow(
                "ضغط الأزرار تلقائياً",
                "يضغط متابعة / Get Link / Skip بدالك",
                e.autoClick
            ) { e.updateAutoClick(it) }
            Hairline()
            ToggleRow(
                "حظر الإعلانات والنوافذ المنبثقة",
                "يمنع شبكات الإعلانات وفتح تبويبات جديدة",
                e.blockAds
            ) { e.updateBlockAds(it) }
        }

        SectionHeader("سرعة العدّاد")
        Group {
            Column(Modifier.padding(12.dp)) {
                Segmented(listOf("عادي", "سريع ×5", "أسرع ×12"), sel) { e.updateSpeed(speeds[it]) }
            }
        }
        Footer("يسرّع عدّاد الانتظار داخل الصفحة. إذا الموقع يتحقق من الوقت على السيرفر وفشل، جرّب «عادي».")

        SectionHeader("بعد التحميل")
        Group {
            ToggleRow(
                "فتح شاشة التثبيت تلقائياً",
                "بعد ما ينتهي تحميل ملف APK",
                e.autoInstall
            ) { e.updateAutoInstall(it) }
        }

        SectionHeader("حول")
        Group {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("الإصدار", color = c.label, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text("1.0", color = c.secondary, fontSize = 17.sp)
            }
        }
        Footer("بعض المواقع تعتمد على كابتشا أو تتحقق من السيرفر، وهذي ما تقدر أي أداة تتخطاها تلقائياً.")
        Gap(24.dp)
    }
}

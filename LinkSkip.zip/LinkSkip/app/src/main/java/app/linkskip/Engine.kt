package app.linkskip

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.provider.Settings
import android.util.Patterns
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ConsoleMessage
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

data class DownloadItem(
    val dmId: Long,
    val name: String,
    val source: String,
    val time: Long,
    val state: Int, // 0 = جاري التحميل، 1 = تم، 2 = فشل
    val progress: Int = -1
)

/**
 * محرّك التخطي: WebView مخفي الإعلانات + سكربتات تضغط "متابعة/Get Link" تلقائياً،
 * تسرّع العدّادات، تلقط رابط الـ APK وتنزّله عن طريق DownloadManager.
 */
class SkipEngine(private val act: ComponentActivity) {

    companion object {
        const val APK_MIME = "application/vnd.android.package-archive"

        private val AD_HOSTS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adnxs.com",
            "popads.net", "popcash.net", "propellerads.com", "propellerclick.com",
            "adsterra.com", "highperformanceformat.com", "exoclick.com", "exosrv.com",
            "juicyads.com", "adcash.com", "clickadu.com", "hilltopads.net", "mgid.com",
            "taboola.com", "outbrain.com", "revcontent.com", "bidvertiser.com",
            "adskeeper.com", "trafficjunky.net", "a-ads.com", "profitablecpmrate.com",
            "effectivegatecpm.com", "monetag.com", "onclickads.net", "richads.com",
            "pushnami.com", "popunder.net", "adspyglass.com", "ad-maven.com", "admaven.com"
        )
    }

    private val prefs = act.getSharedPreferences("linkskip", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    private var bootHandle: ScriptHandler? = null
    private var docStartOk = false
    private var lastDownloadUrl: String? = null
    private var currentUrl: String = ""

    val web: WebView = WebView(act)

    // ---------- حالة الواجهة ----------
    var tab by mutableIntStateOf(0)
    var input by mutableStateOf("")
    var status by mutableStateOf("الصق رابط الموقع وابدأ")
        private set
    var running by mutableStateOf(false)
        private set
    var progress by mutableIntStateOf(0)
        private set
    val history = mutableStateListOf<DownloadItem>()

    // ---------- الإعدادات ----------
    var autoClick by mutableStateOf(prefs.getBoolean("autoClick", true))
        private set
    var blockAds by mutableStateOf(prefs.getBoolean("blockAds", true))
        private set
    var autoInstall by mutableStateOf(prefs.getBoolean("autoInstall", true))
        private set
    var speed by mutableIntStateOf(prefs.getInt("speed", 5))
        private set

    fun updateAutoClick(v: Boolean) { autoClick = v; prefs.edit().putBoolean("autoClick", v).apply() }
    fun updateBlockAds(v: Boolean) { blockAds = v; prefs.edit().putBoolean("blockAds", v).apply() }
    fun updateAutoInstall(v: Boolean) { autoInstall = v; prefs.edit().putBoolean("autoInstall", v).apply() }
    fun updateSpeed(v: Int) { speed = v; prefs.edit().putInt("speed", v).apply() }

    // ---------- مراقب الوقت ----------
    private val watchdog = Runnable {
        if (running) {
            status = "ما لقيت رابط التحميل بعد. إذا ظهر كابتشا حلّها داخل المتصفح، أو اضغط الزر بنفسك."
        }
    }

    private fun arm() {
        main.removeCallbacks(watchdog)
        main.postDelayed(watchdog, 40_000)
    }

    // ---------- استقبال انتهاء التحميل ----------
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            onDownloadFinished(id)
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            var any = false
            for (i in history.indices) {
                val item = history[i]
                if (item.state != 0) continue
                any = true
                var finished = false
                dm.query(DownloadManager.Query().setFilterById(item.dmId)).use { c ->
                    if (c.moveToFirst()) {
                        val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        if (st == DownloadManager.STATUS_SUCCESSFUL || st == DownloadManager.STATUS_FAILED) {
                            finished = true
                        } else {
                            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            val p = if (total > 0) (got * 100 / total).toInt() else -1
                            if (p != item.progress) history[i] = item.copy(progress = p)
                        }
                    } else {
                        history[i] = item.copy(state = 2)
                        saveHistory()
                    }
                }
                if (finished) onDownloadFinished(item.dmId)
            }
            main.postDelayed(this, if (any) 700L else 2000L)
        }
    }

    // ---------- جسر JavaScript ----------
    inner class Bridge {
        @JavascriptInterface
        fun onApk(url: String) {
            main.post { if (running) foundApk(url) }
        }

        @JavascriptInterface
        fun onStatus(msg: String) {
            main.post { if (running) status = msg }
        }
    }

    // ---------- سكربتات ----------
    private fun bootJs(): String = """
(function(){
  if (window.top !== window) return;
  if (window.__lsBoot) return; window.__lsBoot = true;
  var F = __FACTOR__;
  try {
    if (F > 1) {
      var si = window.setInterval, st = window.setTimeout;
      window.setInterval = function(fn, d){ var a = Array.prototype.slice.call(arguments); a[1] = Math.max(1, (d||0)/F); return si.apply(window, a); };
      window.setTimeout = function(fn, d){ var a = Array.prototype.slice.call(arguments); a[1] = (d||0) > 50 ? Math.max(1, (d||0)/F) : d; return st.apply(window, a); };
    }
  } catch(e) {}
  try { window.open = function(){ return null; }; } catch(e) {}
  try {
    Object.defineProperty(document, 'hidden', {get: function(){ return false; }});
    Object.defineProperty(document, 'visibilityState', {get: function(){ return 'visible'; }});
    document.addEventListener('visibilitychange', function(e){ e.stopImmediatePropagation(); }, true);
  } catch(e) {}
})();
""".trimIndent().replace("__FACTOR__", speed.toString())

    private fun helperJs(): String = """
(function(){
  if (window.__lsHelper) return; window.__lsHelper = true;
  var AUTO = __AUTO__;
  var t0 = Date.now();
  var lastClean = 0;
  var seen = new WeakMap();
  var IDS = ['#getlink','#get-link','#btn-main','#btn6','#tp-snp2','#skip_button','#surl','#go-link','#linkbtn','#makingdifference','a.get-link','a.btn-success.btn-lg','.skip-btn','#skipBtn','#downloadButton','#downloadBtn','#uc-download-link'];
  var STRONG = /^(continue|skip|skip ad|skip ads|get link|get the link|go to link|go to the link|click here to continue|click to continue|continue to .{2,25}|proceed|generate link|get download link|unlock link|open link|verify|i am human|i'm human|next|get started|تخطي|متابعة|استمرار|اكمل|إكمال|التالي|احصل على الرابط|الذهاب للرابط|انتقل)\s*[>»›→!.]*${'$'}/i;
  var WEAK = /^(download|download now|download file|تحميل|تنزيل)\s*[!.]*${'$'}/i;

  function vis(n){
    var r = n.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var cs = getComputedStyle(n);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity) > 0.05;
  }

  function press(n, label){
    var last = seen.get(n) || 0;
    if (Date.now() - last < 4000) return false;
    seen.set(n, Date.now());
    try { LinkSkip.onStatus('ضغط: ' + label); } catch(e) {}
    try { n.scrollIntoView({block: 'center'}); } catch(e) {}
    n.click();
    return true;
  }

  function cleanup(){
    var ads = document.querySelectorAll('ins.adsbygoogle,[id^=google_ads],[class*=adsbox],[id*=popunder]');
    for (var i = 0; i < ads.length; i++) { try { ads[i].remove(); } catch(e) {} }
    var els = document.querySelectorAll('div,a,iframe');
    for (var j = 0; j < els.length; j++) {
      var el = els[j];
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'absolute') continue;
      if ((parseInt(cs.zIndex) || 0) < 900) continue;
      if (el.offsetWidth < window.innerWidth * 0.8 || el.offsetHeight < window.innerHeight * 0.8) continue;
      if ((el.innerText || '').trim().length > 2) continue;
      if (el.tagName === 'IFRAME' && /captcha|turnstile|challenge/i.test(el.src || '')) continue;
      if (el.querySelector('input,button,canvas,iframe[src*=captcha],iframe[src*=turnstile],iframe[src*=challenge]')) continue;
      try { el.remove(); } catch(e) {}
    }
    if (document.body && getComputedStyle(document.body).overflow === 'hidden') document.body.style.overflow = 'auto';
  }

  function tick(){
    try {
      var as = document.querySelectorAll('a[href]');
      for (var i = 0; i < as.length; i++) {
        var h = as[i].href || '';
        if (/\.apk([?#]|${'$'})/i.test(h)) { LinkSkip.onApk(h); return; }
      }
      if (Date.now() - lastClean > 1200) { lastClean = Date.now(); cleanup(); }
      if (!AUTO) return;
      for (var k = 0; k < IDS.length; k++) {
        var e = document.querySelector(IDS[k]);
        if (e && vis(e) && !e.disabled && press(e, IDS[k])) return;
      }
      var nodes = document.querySelectorAll('a,button,input[type=button],input[type=submit],div[role=button],span[role=button]');
      for (var j = 0; j < nodes.length; j++) {
        var n = nodes[j];
        var txt = ((n.innerText || n.value || '') + '').trim();
        if (!txt || txt.length > 40) continue;
        if (!vis(n) || n.disabled) continue;
        if (STRONG.test(txt) && press(n, txt)) return;
      }
      if (Date.now() - t0 > 6000) {
        for (var m = 0; m < nodes.length; m++) {
          var w = nodes[m];
          var t2 = ((w.innerText || w.value || '') + '').trim();
          if (!t2 || t2.length > 40) continue;
          if (!vis(w) || w.disabled) continue;
          if (WEAK.test(t2) && press(w, t2)) return;
        }
      }
    } catch(e) {}
  }

  setInterval(tick, 900);
  tick();
})();
""".trimIndent().replace("__AUTO__", autoClick.toString())

    // ---------- أدوات ----------
    private fun isAd(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        return AD_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun toast(msg: String) = Toast.makeText(act, msg, Toast.LENGTH_LONG).show()

    private fun extractUrl(raw: String): String? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        val m = Patterns.WEB_URL.matcher(t)
        if (!m.find()) return null
        val s = m.group() ?: return null
        return if (s.startsWith("http://", true) || s.startsWith("https://", true)) s else "https://$s"
    }

    private fun installBoot() {
        try { bootHandle?.remove() } catch (e: Exception) { }
        bootHandle = null
        docStartOk = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (docStartOk) {
            bootHandle = WebViewCompat.addDocumentStartJavaScript(web, bootJs(), setOf("*"))
        }
    }

    // ---------- تشغيل / إيقاف ----------
    fun start(raw: String) {
        val url = extractUrl(raw)
        if (url == null) {
            status = "الرابط غير صالح"
            return
        }
        input = url
        lastDownloadUrl = null
        running = true
        status = "جاري فتح الرابط…"
        installBoot()
        web.stopLoading()
        web.loadUrl(url)
        arm()
    }

    fun stop() {
        running = false
        main.removeCallbacks(watchdog)
        web.stopLoading()
        web.loadUrl("about:blank")
        status = "تم الإيقاف"
    }

    private fun foundApk(url: String) {
        if (!url.startsWith("http", true)) return
        status = "لقيت رابط الـ APK… جاري التحميل"
        download(url, web.settings.userAgentString, null, APK_MIME)
    }

    // ---------- التحميل ----------
    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        if (url == lastDownloadUrl) return
        if (!url.startsWith("http", true)) {
            status = "نوع الرابط غير مدعوم"
            return
        }
        lastDownloadUrl = url
        var name = URLUtil.guessFileName(url, cd, mime)
        val isApk = mime == APK_MIME ||
            url.substringBefore('?').endsWith(".apk", true) ||
            name.endsWith(".apk", true)
        if (isApk && !name.endsWith(".apk", true)) {
            name = name.substringBeforeLast('.', name) + ".apk"
        }
        try {
            val req = DownloadManager.Request(Uri.parse(url))
            if (!ua.isNullOrBlank()) req.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (currentUrl.isNotBlank()) req.addRequestHeader("Referer", currentUrl)
            val type = if (isApk) APK_MIME else mime
            if (!type.isNullOrBlank()) req.setMimeType(type)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            val id = dm.enqueue(req)
            history.add(0, DownloadItem(id, name, url, System.currentTimeMillis(), 0))
            saveHistory()
            main.removeCallbacks(watchdog)
            status = "جاري تحميل $name"
        } catch (ex: Exception) {
            lastDownloadUrl = null
            status = "تعذّر بدء التحميل: ${ex.message}"
        }
    }

    private fun onDownloadFinished(id: Long) {
        val idx = history.indexOfFirst { it.dmId == id }
        if (idx < 0 || history[idx].state != 0) return
        dm.query(DownloadManager.Query().setFilterById(id)).use { c ->
            if (!c.moveToFirst()) return
            val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val ok = st == DownloadManager.STATUS_SUCCESSFUL
            history[idx] = history[idx].copy(state = if (ok) 1 else 2, progress = -1)
            saveHistory()
            running = false
            if (ok) {
                val item = history[idx]
                status = "تم التحميل: ${item.name}"
                web.stopLoading()
                if (autoInstall && item.name.endsWith(".apk", true)) openFile(item)
            } else {
                status = "فشل التحميل"
            }
        }
    }

    fun openFile(item: DownloadItem) {
        val uri = try { dm.getUriForDownloadedFile(item.dmId) } catch (e: Exception) { null }
        if (uri == null) {
            toast("الملف غير موجود")
            return
        }
        val apk = item.name.endsWith(".apk", true)
        if (apk && !act.packageManager.canRequestPackageInstalls()) {
            toast("فعّل «السماح بالتثبيت» لتطبيق LinkSkip ثم اضغط تثبيت مرة ثانية")
            act.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val type = if (apk) APK_MIME else (dm.getMimeTypeForDownloadedFile(item.dmId) ?: "*/*")
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, type)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            act.startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("ما في تطبيق يفتح هذا الملف")
        }
    }

    fun remove(item: DownloadItem) {
        history.remove(item)
        saveHistory()
    }

    fun clearHistory() {
        history.clear()
        saveHistory()
    }

    private fun saveHistory() {
        val arr = JSONArray()
        history.take(50).forEach {
            arr.put(
                JSONObject()
                    .put("id", it.dmId)
                    .put("name", it.name)
                    .put("src", it.source)
                    .put("t", it.time)
                    .put("st", it.state)
            )
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    private fun loadHistory() {
        try {
            val arr = JSONArray(prefs.getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(
                    DownloadItem(
                        o.getLong("id"), o.getString("name"), o.getString("src"),
                        o.getLong("t"), o.getInt("st")
                    )
                )
            }
        } catch (e: Exception) { }
    }

    // ---------- إعداد WebView ----------
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun setupWebView() {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            allowFileAccess = false
            allowContentAccess = false
            loadWithOverviewMode = true
            useWideViewPort = true
            userAgentString = userAgentString.replace("; wv", "")
        }

        web.setOnTouchListener { v, ev ->
            val end = ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL
            v.parent?.requestDisallowInterceptTouchEvent(!end)
            false
        }

        web.addJavascriptInterface(Bridge(), "LinkSkip")

        web.setDownloadListener { url, ua, cd, mime, _ ->
            download(url, ua, cd, mime)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val scheme = u.scheme ?: return true
                if (scheme != "http" && scheme != "https") return true // يمنع intent:// و market://
                return blockAds && isAd(u.host)
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (blockAds && isAd(request?.url?.host)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                currentUrl = url ?: ""
                if (running && !docStartOk) view?.evaluateJavascript(bootJs(), null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (!running) return
                if (status.startsWith("جاري فتح") || status.startsWith("ضغط")) {
                    status = "جاري تخطي الإعلانات…"
                }
                view?.evaluateJavascript(helperJs(), null)
                arm()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress = newProgress
            }

            // منع النوافذ المنبثقة (إعلانات)
            override fun onCreateWindow(
                view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
            ): Boolean = false

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                result?.confirm(); return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                result?.cancel(); return true
            }

            override fun onJsBeforeUnload(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                result?.confirm(); return true
            }

            override fun onJsPrompt(
                view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult?
            ): Boolean {
                result?.cancel(); return true
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean = true
        }
    }

    fun destroy() {
        main.removeCallbacksAndMessages(null)
        try { act.unregisterReceiver(receiver) } catch (e: Exception) { }
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    init {
        loadHistory()
        setupWebView()
        ContextCompat.registerReceiver(
            act, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        main.postDelayed(poll, 1000)
    }
}

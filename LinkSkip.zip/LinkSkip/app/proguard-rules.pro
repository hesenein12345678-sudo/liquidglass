# Minify is disabled, no rules needed.

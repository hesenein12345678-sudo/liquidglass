# Backdrop Catalog Bottom Tabs Demo

Android Compose demo containing the **actual `LiquidBottomTabs` / `LiquidBottomTab`
implementation adapted from Kyant0/AndroidLiquidGlass's Backdrop Catalog**.
It is not a hand-drawn imitation.

## Toolchain

- Android Gradle Plugin: 9.3.2
- Gradle: 9.7.1
- Kotlin + Compose compiler plugin: 2.4.10
- JDK: 17
- compileSdk / targetSdk: 37
- Compose UI/Foundation: 1.12.1

These versions are pinned rather than using dynamic `+` versions.

## Build locally

Use Gradle 9.7.1 with JDK 17:

```text
gradle --no-daemon :app:assembleDebug
```

## GitHub Actions

Copy `build-exact.yml` to:

```text
.github/workflows/build.yml
```

and keep `BackdropCatalogExact.zip` at the repository root.

The workflow:
1. installs JDK 17,
2. installs Gradle 9.7.1,
3. unzips the project,
4. runs `:app:assembleDebug`,
5. uploads `app-debug.apk`.

## Important fixes included

- Removed the unnecessary Material 3 dependency from the bottom-tabs demo; the sample now uses Compose Foundation text so it does not depend on Material 3.
- Replaced the unavailable `Offset.VectorConverter` usage with a local `TwoWayConverter<Offset, AnimationVector2D>`.
- Added the correct `rememberSaveable` import and removed stale Material3 imports.
- Kept the Backdrop Catalog bottom-tabs implementation and its liquid effects.
- Pinned Compose dependencies to a consistent stable release line.

## Attribution

The bottom-tabs component is adapted from:

https://github.com/Kyant0/AndroidLiquidGlass

See `NOTICE`. The upstream project is Apache-2.0.

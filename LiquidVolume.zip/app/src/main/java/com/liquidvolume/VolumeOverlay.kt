package com.liquidvolume

import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

@Composable
fun VolumeOverlay(
    state: PanelState,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onIconTap: () -> Unit
) {
    val backdrop = rememberLayerBackdrop()

    // Drives the enter animation: starts hidden, flips to visible after first composition.
    val transition = remember { MutableTransitionState(false) }
    transition.targetState = state.visible

    Box(Modifier.fillMaxSize()) {

        // 1) Backdrop source: a screenshot of the screen, aligned 1:1 with what is behind the window.
        //    It is only *recorded* for the glass to sample – it is practically invisible itself
        //    (alpha ~0), so it never covers / disturbs the real screen behind the window.
        Box(
            Modifier
                .fillMaxSize()
                .alpha(0.01f)
                .layerBackdrop(backdrop)
                .drawBehind {
                    val shot = state.screenshot
                    if (shot != null) {
                        drawImage(
                            image = shot,
                            dstOffset = IntOffset(-state.winX, -state.winY),
                            dstSize = IntSize(state.screenW, state.screenH)
                        )
                    }
                }
        )

        // 2) The liquid glass pill with spring enter / exit animations.
        AnimatedVisibility(
            visibleState = transition,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            enter = slideInHorizontally(
                animationSpec = spring(dampingRatio = 0.68f, stiffness = 380f)
            ) { fullWidth -> fullWidth + 160 } +
                scaleIn(
                    initialScale = 0.75f,
                    animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)
                ) +
                fadeIn(tween(160)),
            exit = slideOutHorizontally(tween(260)) { fullWidth -> fullWidth + 160 } +
                scaleOut(targetScale = 0.8f, animationSpec = tween(260)) +
                fadeOut(tween(220))
        ) {
            VolumePill(state, backdrop, onDrag, onDragEnd, onIconTap)
        }
    }
}

private fun iconFor(stream: Int, fraction: Float): Int = when (stream) {
    AudioManager.STREAM_RING -> R.drawable.ic_bell
    AudioManager.STREAM_VOICE_CALL -> R.drawable.ic_phone
    AudioManager.STREAM_ALARM -> R.drawable.ic_alarm
    else -> when {
        fraction <= 0f -> R.drawable.ic_volume_off
        fraction < 0.5f -> R.drawable.ic_volume_down
        else -> R.drawable.ic_volume_up
    }
}

@Composable
private fun VolumePill(
    state: PanelState,
    backdrop: Backdrop,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onIconTap: () -> Unit
) {
    val cfg = state.config
    val scale = cfg.scale

    // Level animation – bouncy like a liquid. While dragging, follow the finger exactly.
    val animatedFill by animateFloatAsState(
        targetValue = state.fraction,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 320f),
        label = "fill"
    )
    val fill = if (state.dragging) state.fraction else animatedFill

    // Slight "press" growth while the finger is down.
    val pressScale by animateFloatAsState(
        targetValue = if (state.dragging) 1.06f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 400f),
        label = "press"
    )

    // "Bump" animation on every key press (stronger when we hit min / max).
    val bump = remember { Animatable(0f) }
    LaunchedEffect(state.tick) {
        if (state.tick > 0) {
            bump.snapTo(if (state.atLimit) 1f else 0.45f)
            bump.animateTo(0f, spring(dampingRatio = 0.28f, stiffness = 230f))
        }
    }

    // White on dark glass, dark when the white fill is behind the icon.
    val iconColor = lerp(Color.White, Color(0xFF2B2B2E), (fill * 6f).coerceIn(0f, 1f))

    // User options.
    val refraction = cfg.refraction
    val refractionHeight = minOf(refraction * 0.46f, 28f * scale)
    val blurRadius = cfg.blur
    val tint = cfg.tint

    Box(
        modifier = Modifier
            .size(width = 64.dp * scale, height = 260.dp * scale)
            .graphicsLayer {
                val b = bump.value
                scaleX = (1f + 0.08f * b) * pressScale
                scaleY = (1f - 0.04f * b) * pressScale
                translationY = if (state.atLimit) -state.lastDir * 14.dp.toPx() * b else 0f
            }
            .drawBackdrop(
                backdrop = backdrop,
                shape = { CircleShape },
                effects = {
                    vibrancy()
                    if (blurRadius > 0f) blur(blurRadius.dp.toPx())
                    if (refraction > 0f) lens(refractionHeight.dp.toPx(), refraction.dp.toPx())
                },
                onDrawSurface = { drawRect(Color.White.copy(alpha = tint)) }
            )
            // Drag anywhere on the pill to change the volume.
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        state.dragging = true
                        onDrag(1f - offset.y / size.height)
                    },
                    onDragEnd = {
                        state.dragging = false
                        onDragEnd()
                    },
                    onDragCancel = {
                        state.dragging = false
                        onDragEnd()
                    },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        onDrag(1f - change.position.y / size.height)
                    }
                )
            }
    ) {
        // Volume level (rounded liquid top edge).
        Canvas(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
        ) {
            val h = size.height * fill.coerceIn(0f, 1f)
            if (h > 0f) {
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.62f),
                    topLeft = Offset(0f, size.height - h),
                    size = Size(size.width, h + size.width),
                    cornerRadius = CornerRadius(size.width / 2f)
                )
            }
        }

        // Icon = current stream. Tap it to switch media -> ringer -> call -> alarm.
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .size(width = 64.dp * scale, height = 62.dp * scale)
                .pointerInput(Unit) { detectTapGestures { onIconTap() } },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(iconFor(state.stream, state.fraction)),
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier
                    .size(26.dp * scale)
                    .alpha(if (state.fraction <= 0f) 0.55f else 1f)
                    .graphicsLayer {
                        val s = 1f - 0.18f * bump.value
                        scaleX = s
                        scaleY = s
                    }
            )
        }
    }
}

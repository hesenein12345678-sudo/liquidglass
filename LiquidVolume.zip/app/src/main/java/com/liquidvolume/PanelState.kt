package com.liquidvolume

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap

/** Shared state between the accessibility service and the Compose overlay. */
class PanelState {
    var fraction by mutableFloatStateOf(0f)
    var visible by mutableStateOf(false)
    var screenshot by mutableStateOf<ImageBitmap?>(null)

    /** Incremented on every key press – drives the "bump" animation. */
    var tick by mutableIntStateOf(0)

    /** +1 = volume up, -1 = volume down. */
    var lastDir by mutableIntStateOf(0)

    /** True when the key was pressed but the volume was already at min/max. */
    var atLimit by mutableStateOf(false)

    // Overlay window position / screen size in px (used to align the screenshot backdrop).
    var winX by mutableIntStateOf(0)
    var winY by mutableIntStateOf(0)
    var screenW by mutableIntStateOf(0)
    var screenH by mutableIntStateOf(0)
}

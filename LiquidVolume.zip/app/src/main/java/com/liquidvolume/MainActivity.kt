package com.liquidvolume

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = Color(0xFF0B0B0D)) {
                        HomeScreen()
                    }
                }
            }
        }
    }
}

private fun isServiceEnabled(activity: ComponentActivity): Boolean {
    val enabled = Settings.Secure.getString(
        activity.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return enabled.contains(activity.packageName)
}

@Composable
private fun HomeScreen() {
    val context = LocalContext.current as ComponentActivity
    var enabled by remember { mutableStateOf(isServiceEnabled(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { enabled = isServiceEnabled(context) }

    Column(
        modifier = Modifier
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Liquid Volume", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            if (enabled) "✅ الخدمة شغّالة. اضغط زر الصوت وشوف النتيجة."
            else "⚠️ الخدمة مو مفعّلة.",
            fontSize = 17.sp,
            color = if (enabled) Color(0xFF7BE495) else Color(0xFFFFB454)
        )
        Spacer(Modifier.height(4.dp))
        Text("طريقة التفعيل:", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Text("١) اضغط الزر تحت وافتح إعدادات إمكانية الوصول.", fontSize = 16.sp)
        Text("٢) ادخل على التطبيقات المُثبّتة (Installed apps) واختار Liquid Volume.", fontSize = 16.sp)
        Text("٣) فعّل الخدمة ووافق على التحذير.", fontSize = 16.sp)
        Text(
            "ملاحظة: أندرويد 13+ يمنع تفعيل الخدمة لتطبيقات من خارج المتجر. إذا الخيار رمادي: " +
                "إعدادات ← التطبيقات ← Liquid Volume ← ⋮ ← السماح بالإعدادات المقيّدة، بعدها ارجع فعّلها.",
            fontSize = 14.sp,
            color = Color(0xFFB0B0B8)
        )
        Button(
            onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("فتح إعدادات إمكانية الوصول")
        }
        Text(
            "الزجاج الحقيقي (الانكسار) يحتاج أندرويد 13 أو أحدث. الخدمة تأخذ لقطة شاشة لحظية فقط لتكون خلفية تأثير الزجاج، ولا تحفظ شي.",
            fontSize = 13.sp,
            color = Color(0xFF8E8E96)
        )
    }
}

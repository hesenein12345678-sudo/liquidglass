package com.liquidvolume

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = Color(0xFF0B0B0D),
                        contentColor = Color.White
                    ) {
                        HomeScreen()
                    }
                }
            }
        }
    }
}

private fun isServiceEnabled(activity: ComponentActivity): Boolean {
    val enabled = Settings.Secure.getString(
        activity.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return enabled.contains(activity.packageName)
}

private val streamOptions = listOf(
    0 to "تلقائي (وسائط، ومكالمات وقت المكالمة)",
    1 to "الوسائط",
    2 to "الرنين والإشعارات",
    3 to "المكالمات",
    4 to "المنبّه"
)

@Composable
private fun HomeScreen() {
    val activity = LocalContext.current as ComponentActivity
    var serviceOn by remember { mutableStateOf(isServiceEnabled(activity)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { serviceOn = isServiceEnabled(activity) }

    var cfg by remember { mutableStateOf(Prefs.load(activity)) }
    fun update(new: GlassConfig) {
        cfg = new
        Prefs.save(activity, new)
    }

    Column(
        modifier = Modifier
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text("Liquid Volume", fontSize = 30.sp, fontWeight = FontWeight.Bold)

        // ---- service status -------------------------------------------------------------
        Text(
            if (serviceOn) "✅ الخدمة شغّالة" else "⚠️ الخدمة مو مفعّلة في إعدادات إمكانية الوصول",
            fontSize = 16.sp,
            color = if (serviceOn) Color(0xFF7BE495) else Color(0xFFFFB454)
        )
        Button(
            onClick = { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("فتح إعدادات إمكانية الوصول") }
        Text(
            "إذا الخيار رمادي (أندرويد 13+): إعدادات ← التطبيقات ← Liquid Volume ← ⋮ ← السماح بالإعدادات المقيّدة.",
            fontSize = 13.sp,
            color = Color(0xFF8E8E96)
        )

        HorizontalDivider(color = Color(0xFF2A2A2E))

        // ---- on / off ---------------------------------------------------------------------
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text("تشغيل Liquid Volume", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "إذا طفيته يرجع شريط الصوت الأصلي للنظام.",
                    fontSize = 13.sp,
                    color = Color(0xFF8E8E96)
                )
            }
            Switch(checked = cfg.enabled, onCheckedChange = { update(cfg.copy(enabled = it)) })
        }

        // ---- preview ----------------------------------------------------------------------
        OutlinedButton(
            onClick = {
                val s = VolumeAccessibilityService.instance
                if (s != null) s.preview()
                else Toast.makeText(activity, "فعّل الخدمة أول شي", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("معاينة الشكل") }

        HorizontalDivider(color = Color(0xFF2A2A2E))

        // ---- look -------------------------------------------------------------------------
        Text("الشكل", fontSize = 20.sp, fontWeight = FontWeight.Bold)

        LabeledSlider(
            label = "شدة الانكسار",
            valueText = "${cfg.refraction.roundToInt()}",
            value = cfg.refraction,
            range = 0f..60f
        ) { update(cfg.copy(refraction = it)) }

        LabeledSlider(
            label = "الضبابية",
            valueText = "${cfg.blur.roundToInt()}",
            value = cfg.blur,
            range = 0f..24f
        ) { update(cfg.copy(blur = it)) }

        LabeledSlider(
            label = "الحجم",
            valueText = "${(cfg.scale * 100).roundToInt()}%",
            value = cfg.scale,
            range = 0.7f..1.4f
        ) { update(cfg.copy(scale = it)) }

        LabeledSlider(
            label = "تعتيم الزجاج (اللون الأبيض)",
            valueText = "${(cfg.tint * 100).roundToInt()}%",
            value = cfg.tint,
            range = 0f..0.5f
        ) { update(cfg.copy(tint = it)) }

        LabeledSlider(
            label = "مدة الظهور",
            valueText = "${"%.1f".format(cfg.durationSec)} ث",
            value = cfg.durationSec,
            range = 1f..5f
        ) { update(cfg.copy(durationSec = it)) }

        OutlinedButton(
            onClick = { update(GlassConfig(enabled = cfg.enabled, defaultStream = cfg.defaultStream)) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("إرجاع الشكل للإعدادات الافتراضية") }

        HorizontalDivider(color = Color(0xFF2A2A2E))

        // ---- default stream -----------------------------------------------------------------
        Text("أزرار الصوت تتحكم بـ", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            "وبنفس الوقت تگدر تضغط على أيقونة اللوحة نفسها لتبديل: وسائط ← رنين ← مكالمات ← منبّه.",
            fontSize = 13.sp,
            color = Color(0xFF8E8E96)
        )
        streamOptions.forEach { (id, title) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = cfg.defaultStream == id,
                    onClick = { update(cfg.copy(defaultStream = id)) }
                )
                Text(title, fontSize = 16.sp)
            }
        }

        HorizontalDivider(color = Color(0xFF2A2A2E))

        // ---- per-stream volume levels --------------------------------------------------------
        Text("مستويات الصوت", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        StreamSlider("الوسائط", AudioManager.STREAM_MUSIC)
        StreamSlider("الرنين والإشعارات", AudioManager.STREAM_RING)
        StreamSlider("المكالمات", AudioManager.STREAM_VOICE_CALL)
        StreamSlider("المنبّه", AudioManager.STREAM_ALARM)
        Text(
            "ملاحظة: الرنين قد لا يتغير إذا كان وضع «عدم الإزعاج» شغّال.",
            fontSize = 12.sp,
            color = Color(0xFF8E8E96)
        )

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 15.sp)
            Text(valueText, fontSize = 15.sp, color = Color(0xFF9EC9FF))
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps
        )
    }
}

@Composable
private fun StreamSlider(label: String, stream: Int) {
    val ctx = LocalContext.current
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val min = audio.getStreamMinVolume(stream)
    val max = audio.getStreamMaxVolume(stream)
    var value by remember { mutableFloatStateOf(audio.getStreamVolume(stream).toFloat()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        value = audio.getStreamVolume(stream).toFloat()
    }
    if (max <= min) return

    LabeledSlider(
        label = label,
        valueText = "${value.roundToInt()} / $max",
        value = value,
        range = min.toFloat()..max.toFloat(),
        steps = (max - min - 1).coerceAtLeast(0)
    ) { v ->
        value = v
        try {
            audio.setStreamVolume(stream, v.roundToInt(), 0)
        } catch (_: SecurityException) {
            // Do Not Disturb restrictions
        }
    }
}

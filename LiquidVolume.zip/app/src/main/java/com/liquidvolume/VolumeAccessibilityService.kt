package com.liquidvolume

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class VolumeAccessibilityService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager

    private val handler = Handler(Looper.getMainLooper())
    private val owner = OverlayOwner()
    private val state = PanelState()

    private var overlay: ComposeView? = null
    private var capturing = false
    private var screenshotBitmap: Bitmap? = null

    private val hideRunnable = Runnable { startHide() }
    private val removeRunnable = Runnable { removeOverlay() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager

        val info = serviceInfo ?: return
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (event.action == KeyEvent.ACTION_DOWN) {
            onVolumeKey(up = code == KeyEvent.KEYCODE_VOLUME_UP)
        }
        // Consume the key so the system volume panel never appears.
        return true
    }

    private fun pickStream(): Int {
        val mode = audio.mode
        return if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) {
            AudioManager.STREAM_VOICE_CALL
        } else {
            AudioManager.STREAM_MUSIC
        }
    }

    private fun onVolumeKey(up: Boolean) {
        val stream = pickStream()
        val before = audio.getStreamVolume(stream)
        audio.adjustStreamVolume(
            stream,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            0 // no FLAG_SHOW_UI
        )
        val now = audio.getStreamVolume(stream)
        val min = audio.getStreamMinVolume(stream)
        val max = audio.getStreamMaxVolume(stream)

        state.fraction = (now - min).toFloat() / (max - min).coerceAtLeast(1)
        state.lastDir = if (up) 1 else -1
        state.atLimit = now == before
        state.tick++

        if (overlay != null && state.visible) {
            scheduleHide()
            return
        }
        if (overlay != null) removeOverlay() // was still fading out
        if (capturing) return                 // the pending callback will show it

        capturing = true
        captureThenShow()
    }

    /** Takes a screenshot to use as the real backdrop behind the glass. */
    private fun captureThenShow() {
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val buffer = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        buffer.close()
                        capturing = false
                        screenshotBitmap = bmp
                        showOverlay(bmp)
                    }

                    override fun onFailure(errorCode: Int) {
                        capturing = false
                        showOverlay(null)
                    }
                }
            )
        } catch (t: Throwable) {
            capturing = false
            showOverlay(null)
        }
    }

    private fun showOverlay(bmp: Bitmap?) {
        val bounds = wm.maximumWindowMetrics.bounds
        val density = resources.displayMetrics.density
        val winW = (WIN_W_DP * density).toInt()
        val winH = minOf((WIN_H_DP * density).toInt(), bounds.height())
        val x = bounds.width() - winW
        val y = (bounds.height() - winH) / 2

        state.screenW = bounds.width()
        state.screenH = bounds.height()
        state.winX = x
        state.winY = y
        state.screenshot = bmp?.asImageBitmap()
        state.visible = true

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent { VolumeOverlay(state) }
        }

        val lp = WindowManager.LayoutParams(
            winW,
            winH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        try {
            wm.addView(view, lp)
            overlay = view
        } catch (_: Exception) {
            state.visible = false
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(removeRunnable)
        handler.postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    private fun startHide() {
        state.visible = false
        handler.postDelayed(removeRunnable, REMOVE_DELAY_MS)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(removeRunnable)
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
        state.visible = false
        state.screenshot = null
        screenshotBitmap?.recycle()
        screenshotBitmap = null
    }

    override fun onDestroy() {
        removeOverlay()
        owner.destroy()
        super.onDestroy()
    }

    companion object {
        // Overlay window size = pill + margins (the extra margin gives the lens room to refract).
        const val WIN_W_DP = 100f
        const val WIN_H_DP = 308f
        const val HIDE_DELAY_MS = 1800L
        const val REMOVE_DELAY_MS = 550L
    }
}

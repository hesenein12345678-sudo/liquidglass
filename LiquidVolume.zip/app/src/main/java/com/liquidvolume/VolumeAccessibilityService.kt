package com.liquidvolume

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlin.math.roundToInt

class VolumeAccessibilityService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager

    private val handler = Handler(Looper.getMainLooper())
    private val owner = OverlayOwner()
    private val state = PanelState()

    private var overlay: ComposeView? = null
    private var capturing = false
    private var screenshotBitmap: Bitmap? = null

    private val hideRunnable = Runnable { startHide() }
    private val removeRunnable = Runnable { removeOverlay() }
    private val refreshRunnable = Runnable { refreshBackdrop() }

    /** True while a re-capture of the screen is in progress (the pill is hidden meanwhile). */
    private var refreshing = false
    private var pendingCapture: Runnable? = null

    /** Streams the user can switch between by tapping the icon. */
    private val streams = intArrayOf(
        AudioManager.STREAM_MUSIC,
        AudioManager.STREAM_RING,
        AudioManager.STREAM_VOICE_CALL,
        AudioManager.STREAM_ALARM
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        instance = this

        val info = serviceInfo ?: return
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        serviceInfo = info
    }

    /**
     * The glass samples a screenshot, so when the screen underneath changes (page swipe,
     * scrolling, another app opening) that screenshot becomes stale. We drop it immediately
     * (no wrong content is ever shown) and take a fresh one once things settle.
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !isShowing() || state.dragging) return
        if (event.packageName == packageName) return // ignore our own overlay
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (state.screenshot != null) state.screenshot = null
                handler.removeCallbacks(refreshRunnable)
                handler.postDelayed(refreshRunnable, REFRESH_DEBOUNCE_MS)
            }
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        val cfg = Prefs.load(this)
        // App switched off from settings -> let the system volume panel work normally.
        if (!cfg.enabled) return false

        if (event.action == KeyEvent.ACTION_DOWN) {
            onVolumeKey(up = code == KeyEvent.KEYCODE_VOLUME_UP, cfg = cfg)
        }
        // Consume the key so the system volume panel never appears.
        return true
    }

    private fun streamFor(cfg: GlassConfig): Int = when (cfg.defaultStream) {
        1 -> AudioManager.STREAM_MUSIC
        2 -> AudioManager.STREAM_RING
        3 -> AudioManager.STREAM_VOICE_CALL
        4 -> AudioManager.STREAM_ALARM
        else -> {
            val mode = audio.mode
            if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) {
                AudioManager.STREAM_VOICE_CALL
            } else {
                AudioManager.STREAM_MUSIC
            }
        }
    }

    private fun readFraction(stream: Int): Float {
        val min = audio.getStreamMinVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        val now = audio.getStreamVolume(stream)
        return (now - min).toFloat() / (max - min).coerceAtLeast(1)
    }

    private fun isShowing() = overlay != null && state.visible

    private fun onVolumeKey(up: Boolean, cfg: GlassConfig) {
        if (!isShowing()) {
            state.config = cfg
            state.stream = streamFor(cfg)
        }
        val stream = state.stream
        val before = audio.getStreamVolume(stream)
        try {
            audio.adjustStreamVolume(
                stream,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                0 // no FLAG_SHOW_UI
            )
        } catch (_: SecurityException) {
            // e.g. Do Not Disturb restrictions on the ring stream
        }
        val now = audio.getStreamVolume(stream)

        state.fraction = readFraction(stream)
        state.lastDir = if (up) 1 else -1
        state.atLimit = now == before
        state.tick++

        present()
    }

    /** Shows the panel (taking a fresh screenshot first) or just extends the timer. */
    private fun present() {
        if (isShowing()) {
            scheduleHide()
            return
        }
        if (overlay != null) removeOverlay() // was still fading out
        if (capturing) return                 // the pending callback will show it

        capturing = true
        captureThenShow()
    }

    /** Called from the settings screen to preview the current look. */
    fun preview() {
        val cfg = Prefs.load(this)
        if (!isShowing()) {
            state.config = cfg
            state.stream = streamFor(cfg)
        }
        state.fraction = readFraction(state.stream)
        state.lastDir = 1
        state.atLimit = false
        state.tick++
        present()
    }

    // ---- touch interaction coming from the overlay -------------------------------------------

    private fun setFractionFromUser(f: Float) {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(removeRunnable)
        val fraction = f.coerceIn(0f, 1f)
        val stream = state.stream
        val min = audio.getStreamMinVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        val target = (min + fraction * (max - min)).roundToInt()
        try {
            audio.setStreamVolume(stream, target, 0)
        } catch (_: SecurityException) {
        }
        state.fraction = fraction
    }

    private fun onDragEnd() {
        state.fraction = readFraction(state.stream)
        scheduleHide()
    }

    private fun cycleStream() {
        val next = streams[(streams.indexOf(state.stream) + 1) % streams.size]
        state.stream = next
        state.fraction = readFraction(next)
        state.lastDir = 0
        state.atLimit = false
        state.tick++
        scheduleHide()
    }

    // ---- screenshot + overlay window ----------------------------------------------------------

    /** Takes a screenshot to use as the real backdrop behind the glass. */
    private fun captureThenShow() {
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val buffer = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        buffer.close()
                        capturing = false
                        screenshotBitmap = bmp
                        showOverlay(bmp)
                    }

                    override fun onFailure(errorCode: Int) {
                        capturing = false
                        showOverlay(null)
                    }
                }
            )
        } catch (t: Throwable) {
            capturing = false
            showOverlay(null)
        }
    }

    /** Re-captures the screen behind the panel. The pill is hidden for a moment so it never captures itself. */
    private fun refreshBackdrop() {
        val view = overlay ?: return
        if (!state.visible || capturing || refreshing) return
        refreshing = true
        view.visibility = View.INVISIBLE
        val r = Runnable { doRefreshCapture(view) }
        pendingCapture = r
        handler.postDelayed(r, 70) // let the window actually disappear first
    }

    private fun doRefreshCapture(view: View) {
        pendingCapture = null
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val buffer = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        buffer.close()
                        refreshing = false
                        if (overlay === view) {
                            screenshotBitmap = bmp
                            state.screenshot = bmp?.asImageBitmap()
                            view.visibility = View.VISIBLE
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        refreshing = false
                        if (overlay === view) {
                            view.visibility = View.VISIBLE
                            if (errorCode == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                                handler.postDelayed(refreshRunnable, 350)
                            }
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            refreshing = false
            view.visibility = View.VISIBLE
        }
    }

    private fun showOverlay(bmp: Bitmap?) {
        val bounds = wm.maximumWindowMetrics.bounds
        val density = resources.displayMetrics.density

        // Make sure the panel always fits on the screen (landscape etc.).
        val maxScale = ((bounds.height() / density) - WIN_EXTRA_H_DP) / PILL_H_DP
        val scale = minOf(state.config.scale, maxScale).coerceAtLeast(0.5f)
        state.config = state.config.copy(scale = scale)

        val winW = ((PILL_W_DP * scale + WIN_EXTRA_W_DP) * density).toInt()
        val winH = minOf(((PILL_H_DP * scale + WIN_EXTRA_H_DP) * density).toInt(), bounds.height())
        val x = bounds.width() - winW
        val y = (bounds.height() - winH) / 2

        state.screenW = bounds.width()
        state.screenH = bounds.height()
        state.winX = x
        state.winY = y
        state.screenshot = bmp?.asImageBitmap()
        state.visible = true

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                VolumeOverlay(
                    state = state,
                    onDrag = ::setFractionFromUser,
                    onDragEnd = ::onDragEnd,
                    onIconTap = ::cycleStream
                )
            }
        }

        val lp = WindowManager.LayoutParams(
            winW,
            winH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            // Touchable (so the panel can be dragged), but touches outside the
            // small window still go to the app underneath.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        try {
            wm.addView(view, lp)
            overlay = view
        } catch (_: Exception) {
            state.visible = false
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(removeRunnable)
        handler.postDelayed(hideRunnable, (state.config.durationSec * 1000).toLong())
    }

    private fun startHide() {
        if (state.dragging) { // never hide while the finger is down
            scheduleHide()
            return
        }
        state.visible = false
        handler.postDelayed(removeRunnable, REMOVE_DELAY_MS)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(removeRunnable)
        handler.removeCallbacks(refreshRunnable)
        pendingCapture?.let { handler.removeCallbacks(it) }
        pendingCapture = null
        refreshing = false
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
        state.visible = false
        state.dragging = false
        state.screenshot = null
        screenshotBitmap = null
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        removeOverlay()
        owner.destroy()
        super.onDestroy()
    }

    companion object {
        /** Base pill size (before the user's size multiplier). */
        const val PILL_W_DP = 64f
        const val PILL_H_DP = 260f

        /** Extra room around the pill inside the overlay window (bump animation, edge gap). */
        const val WIN_EXTRA_W_DP = 28f
        const val WIN_EXTRA_H_DP = 40f

        const val REMOVE_DELAY_MS = 550L
        const val REFRESH_DEBOUNCE_MS = 250L

        /** Used by the settings screen for the "preview" button. */
        @Volatile
        var instance: VolumeAccessibilityService? = null
    }
}

package com.liquidvolume

import android.content.Context

/** All user-customisable options. */
data class GlassConfig(
    val enabled: Boolean = true,
    /** Refraction strength in dp (0 = off). */
    val refraction: Float = 26f,
    /** Blur radius in dp (0 = off). */
    val blur: Float = 2f,
    /** Panel size multiplier. */
    val scale: Float = 1f,
    /** White tint over the glass (0..0.5). */
    val tint: Float = 0.14f,
    /** How long the panel stays visible, in seconds. */
    val durationSec: Float = 2f,
    /** 0 = auto, 1 = media, 2 = ring/notifications, 3 = calls, 4 = alarm. */
    val defaultStream: Int = 0
)

object Prefs {
    private const val FILE = "liquid_volume_prefs"

    fun load(ctx: Context): GlassConfig {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = GlassConfig()
        return GlassConfig(
            enabled = p.getBoolean("enabled", d.enabled),
            refraction = p.getFloat("refraction", d.refraction),
            blur = p.getFloat("blur", d.blur),
            scale = p.getFloat("scale", d.scale),
            tint = p.getFloat("tint", d.tint),
            durationSec = p.getFloat("durationSec", d.durationSec),
            defaultStream = p.getInt("defaultStream", d.defaultStream)
        )
    }

    fun save(ctx: Context, c: GlassConfig) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", c.enabled)
            .putFloat("refraction", c.refraction)
            .putFloat("blur", c.blur)
            .putFloat("scale", c.scale)
            .putFloat("tint", c.tint)
            .putFloat("durationSec", c.durationSec)
            .putInt("defaultStream", c.defaultStream)
            .apply()
    }
}

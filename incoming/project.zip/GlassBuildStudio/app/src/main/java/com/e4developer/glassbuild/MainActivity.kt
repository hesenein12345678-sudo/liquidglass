package com.e4developer.glassbuild

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 10, 26)
        window.navigationBarColor = android.graphics.Color.rgb(5, 10, 26)
        setContent { GlassBuildApp() }
    }
}

private enum class Profile(val title: String, val description: String, val jdk: String, val note: String) {
    MODERN("Android حديث + Liquid Glass", "Kotlin / Compose / Backdrop Catalog", "17", "مناسب لمشاريع Compose ومكتبة Backdrop؛ يحتفظ بإصدار Gradle الموجود داخل المشروع."),
    JAVA("Java Android", "مشاريع Android المكتوبة بلغة Java", "17", "يستخدم Gradle Wrapper الخاص بالمشروع ولا يفرض إصدار Gradle جديداً."),
    LEGACY("مشروع قديم", "للمشاريع التي تعتمد Gradle أو Android Gradle Plugin أقدم", "11", "إذا كان المشروع يحتاج JDK 8 أو 11 غيّر قيمة Java في ملف Workflow حسب متطلبات AGP."),
    JDK21("JDK 21", "للمشاريع المهيأة لإصدارات حديثة متوافقة", "21", "لا تختَر JDK 21 إلا إذا كان إصدار Android Gradle Plugin وGradle في مشروعك يدعمانه.")
}

@Composable
private fun GlassBuildApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(Profile.MODERN) }
    var includeBackdropFix by remember { mutableStateOf(true) }
    var showWorkflow by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("اختَر نوع مشروعك حتى نجهّز ملف البناء المناسب") }
    val workflow = remember(selected, includeBackdropFix) { makeWorkflow(selected, includeBackdropFix) }
    val bg = Brush.linearGradient(listOf(Color(0xFF050A19), Color(0xFF101D3C), Color(0xFF080D20)))

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF65CFFF), secondary = Color(0xFFB5A0FF), background = Color(0xFF070D1D),
        surface = Color(0xCC14213B), onSurface = Color(0xFFF4F7FF), onBackground = Color(0xFFF4F7FF)
    )) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF6AD9FF), Color(0xFF6655D9)))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Build, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("GlassBuild Studio", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Android Build Workflow Generator", fontSize = 12.sp, color = Color(0xFFB8C8E8))
                    }
                    Box(Modifier.clip(CircleShape).background(Color(0x332CBDF7)).padding(10.dp)) { Icon(Icons.Default.Tune, null, tint = Color(0xFF7BD8FF)) }
                }
                GlassPanel {
                    Text("ابنِ مشاريعك بدون وجع راس", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("جهّز ملف .github/workflows/android.yml لمشروعك، ثم ارفعه إلى GitHub وشغّل Actions لبناء APK.", color = Color(0xFFCBD7F0), lineHeight = 21.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Info, null, tint = Color(0xFF75D8FF))
                        Text("التطبيق يولّد إعدادات البناء؛ عملية البناء نفسها تتم على GitHub Actions.", fontSize = 12.sp, color = Color(0xFF9FB7D9))
                    }
                }
                Text("1. اختَر ملف تعريف المشروع", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Profile.entries.forEach { p ->
                    val active = selected == p
                    Surface(
                        onClick = { selected = p; status = "تم اختيار: ${p.title}" },
                        shape = RoundedCornerShape(20.dp),
                        color = if (active) Color(0x663A8CCB) else Color(0x331A2945),
                        border = androidx.compose.foundation.BorderStroke(if (active) 1.5.dp else 1.dp, if (active) Color(0xFF72D7FF) else Color(0x557F9BC4))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            RadioButton(selected = active, onClick = { selected = p }, colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF77D8FF)))
                            Column(Modifier.weight(1f)) {
                                Text(p.title, fontWeight = FontWeight.SemiBold)
                                Text(p.description, fontSize = 12.sp, color = Color(0xFFB6C7E5))
                                if (active) Text("JDK ${p.jdk} · ${p.note}", fontSize = 11.sp, color = Color(0xFF7EDAFF), lineHeight = 16.sp)
                            }
                        }
                    }
                }
                GlassPanel {
                    Text("توافق Backdrop / Liquid Glass", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("إذا كان مشروعك يحتوي على tools/fetch_backdrop_catalog_components.sh، شغّل السكربت قبل البناء. خيار الإصلاح يضيف توافق withFrameNanos لمشكلة awaitFrame القديمة.", fontSize = 12.sp, color = Color(0xFFCBD7F0), lineHeight = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = includeBackdropFix, onCheckedChange = { includeBackdropFix = it }, colors = CheckboxDefaults.colors(checkedColor = Color(0xFF55C7FF)))
                        Text("إضافة إصلاح توافق Backdrop", fontSize = 14.sp)
                    }
                }
                Button(onClick = { showWorkflow = !showWorkflow; status = if (showWorkflow) "ملف Workflow جاهز للنسخ" else "تم تحديث المعاينة" }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF247FD1))) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text(if (showWorkflow) "إخفاء ملف Workflow" else "إنشاء ملف Workflow", fontWeight = FontWeight.Bold)
                }
                if (showWorkflow) {
                    GlassPanel {
                        Text(".github/workflows/android.yml", fontWeight = FontWeight.Bold, color = Color(0xFF82DEFF))
                        Spacer(Modifier.height(8.dp))
                        Text(workflow, modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), fontSize = 11.sp, lineHeight = 15.sp, color = Color(0xFFE0E9FA))
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("android.yml", workflow))
                            status = "تم نسخ ملف Workflow؛ أنشئ الملف بالمسار الموضح والصق المحتوى."
                        }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("نسخ ملف Workflow")
                        }
                    }
                }
                GlassPanel {
                    Text("خطوات الاستخدام", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("1) فك ضغط مشروع Android داخل مستودع GitHub.\n2) أنشئ المسار .github/workflows/\n3) أنشئ android.yml والصق الملف المنسوخ.\n4) تأكد أن المشروع يحتوي gradlew وملفات Gradle.\n5) افتح Actions وشغّل Android APK Build.\n6) نزّل APK من Artifacts بعد نجاح البناء.", color = Color(0xFFCBD7F0), lineHeight = 22.sp)
                }
                Text(status, color = Color(0xFF81D9FF), fontSize = 12.sp)
                Text("تنبيه: لا يوجد إعداد واحد يناسب كل المشاريع؛ توافق Java وGradle وAndroid Gradle Plugin يعتمد على إصدار المشروع نفسه.", color = Color(0xFF9CAECF), fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0x553E6F9C), Color(0x331C2A49), Color(0x442B2354))))
            .border(1.dp, Color(0x668CCBFF), RoundedCornerShape(24.dp)).padding(16.dp),
        content = content
    )
}

private fun makeWorkflow(profile: Profile, backdropFix: Boolean): String {
    val backdropBlock = if (backdropFix) """
          if [ -f tools/fetch_backdrop_catalog_components.sh ]; then
            chmod +x tools/fetch_backdrop_catalog_components.sh
            bash tools/fetch_backdrop_catalog_components.sh
            DAMPED=\"app/src/main/java/com/kyant/backdrop/catalog/utils/DampedDragAnimation.kt\"
            if [ -f \"${'$'}DAMPED\" ] && grep -q 'awaitFrame()' \"${'$'}DAMPED\"; then
              sed -i 's/awaitFrame()/withFrameNanos { }/g' \"${'$'}DAMPED\"
              grep -q '^import androidx.compose.runtime.withFrameNanos$' \"${'$'}DAMPED\" || sed -i '/^import androidx.compose.runtime.snapshotFlow$/a import androidx.compose.runtime.withFrameNanos' \"${'$'}DAMPED\"
            fi
          fi
""".trimIndent() else ""
    return """name: Android APK Build

on:
  workflow_dispatch:
  push:
    branches: [ \"main\", \"master\" ]

permissions:
  contents: read

env:
  JAVA_VERSION: \"${profile.jdk}\"

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout source
        uses: actions/checkout@v4

      - name: Set up JDK ${profile.jdk}
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: \"${profile.jdk}\"

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4

      - name: Prepare project
        shell: bash
        run: |
          set -euo pipefail
          test -f settings.gradle || test -f settings.gradle.kts
          test -f app/build.gradle || test -f app/build.gradle.kts
          if [ -f gradlew ]; then chmod +x gradlew; else
            echo \"ERROR: gradlew is missing. Add the Gradle Wrapper to this project first.\" >&2
            exit 1
          fi
${backdropBlock.prependIndent("          ")}
      - name: Build debug APK
        run: ./gradlew --no-daemon --stacktrace assembleDebug

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: ${profile.name.lowercase().replace(' ', '-')}-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
          retention-days: 14
""".trimIndent()
}

# GlassBuild Studio

A small Android app that generates a project-specific GitHub Actions workflow for building Android APKs. It is designed to help phone-only developers prepare a workflow without manually writing YAML.

## Build this app

The repository includes `.github/workflows/android.yml`. Upload the contents of this folder to a GitHub repository, then open **Actions → Build GlassBuild Studio APK → Run workflow**. Download `GlassBuildStudio-debug-apk` from the workflow artifacts.

## Use the app

1. Choose a project profile.
2. Generate and copy the workflow.
3. In the target Android project, create `.github/workflows/android.yml` and paste the generated contents.
4. Make sure the target project contains `settings.gradle`/`settings.gradle.kts`, `app/build.gradle`/`app/build.gradle.kts`, and a working Gradle Wrapper (`gradlew` plus `gradle/wrapper/`).
5. Commit and push, then run the target repository's Actions workflow.

## Important compatibility note

There is no single Java, Android Gradle Plugin, Gradle, or SDK version that works for every Android project. The app provides common profiles, but the project's existing Gradle Wrapper and Android Gradle Plugin compatibility requirements take priority. Backdrop is a UI dependency and does not replace the Android build toolchain. The optional Backdrop patch is intended only for projects that use the supplied component-fetch script and whose copied `DampedDragAnimation.kt` contains `awaitFrame()`.

## Build an Android project supplied as a ZIP

This repository includes `.github/workflows/build-uploaded-project.yml`. To use it:

1. Create an `incoming` folder at the repository root.
2. Upload the project archive as `incoming/project.zip` (the ZIP must contain `gradlew`, `gradle/wrapper/gradle-wrapper.properties`, `settings.gradle` or `settings.gradle.kts`, and the Android module build files).
3. Open **Actions → Build Android project from ZIP → Run workflow**.
4. Download `android-debug-apk` from the completed workflow's Artifacts section.

The workflow checks ZIP paths before extracting, searches for the Gradle project root, sets up a JDK, runs the project's own Gradle Wrapper, and uploads generated debug APKs. It optionally runs the project's Backdrop source-fetch script and applies the known `awaitFrame()` compatibility patch when the expected source file exists.

**Important:** this workflow builds on GitHub-hosted runners, not on the phone. A truly local build feature requires a local Java/Gradle/Android SDK toolchain (for example through a separately installed Termux environment), substantial storage, and project-specific compatibility handling. No single JDK/Gradle/SDK combination can build every Android project. The JDK auto-detection here is conservative and may need adjustment for legacy or unusual projects.

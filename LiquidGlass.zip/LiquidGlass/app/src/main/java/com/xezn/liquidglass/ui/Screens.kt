package com.xezn.liquidglass.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.xezn.liquidglass.ProfileData

// ---------------------------------------------------------------- Background

@Composable
fun AuroraBackground() {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "p"
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(listOf(Color(0xFF0B1026), Color(0xFF1B1140), Color(0xFF0A1F3D)))
        )
        fun blob(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(color, Color.Transparent),
                    center = Offset(cx, cy),
                    radius = r
                ),
                radius = r,
                center = Offset(cx, cy)
            )
        }
        val w = size.width
        val h = size.height
        blob(Color(0xFFFF4081).copy(alpha = 0.75f), w * (0.2f + 0.5f * p), h * (0.18f + 0.1f * p), w * 0.7f)
        blob(Color(0xFF00B0FF).copy(alpha = 0.75f), w * (0.85f - 0.5f * p), h * (0.45f + 0.1f * p), w * 0.75f)
        blob(Color(0xFF7C4DFF).copy(alpha = 0.8f), w * (0.3f + 0.3f * p), h * (0.78f - 0.1f * p), w * 0.8f)
        blob(Color(0xFFFFB300).copy(alpha = 0.45f), w * (0.9f - 0.2f * p), h * (0.92f - 0.2f * p), w * 0.5f)
        // thin rings so the glass refraction is visible
        for (i in 1..7) {
            drawCircle(
                color = Color.White.copy(alpha = 0.07f),
                radius = w * 0.18f * i,
                center = Offset(w * 0.5f, h * (0.35f + 0.05f * p)),
                style = Stroke(width = 2f)
            )
        }
    }
}

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(backdrop: Backdrop) {
    var toggle by remember { mutableStateOf(true) }
    var slider by remember { mutableFloatStateOf(0.45f) }
    var likes by remember { mutableIntStateOf(0) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 28.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Liquid Glass", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Text(
            "Built with the Backdrop library",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 16.sp
        )

        GlassCard(backdrop) {
            Text("Welcome", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Everything here is real glass: it blurs, bends and refracts the colorful world behind it. Try the controls below.",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp,
                lineHeight = 21.sp
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            GlassButton("Like $likes", backdrop, Modifier.weight(1f), Icons.Filled.Favorite) { likes++ }
            GlassButton("Star", backdrop, Modifier.weight(1f), Icons.Filled.Star) { likes += 2 }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIconButton(Icons.Filled.Add, backdrop, size = 56.dp) { likes++ }
            GlassIconButton(Icons.Filled.Share, backdrop, size = 56.dp) { likes++ }
            GlassIconButton(Icons.Filled.Edit, backdrop, size = 56.dp) { likes++ }
            GlassIconButton(Icons.Filled.Close, backdrop, size = 56.dp) { likes = 0 }
        }

        GlassCard(backdrop) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Glass Switch", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (toggle) "Enabled" else "Disabled",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 14.sp
                    )
                }
                GlassSwitch(toggle, { toggle = it }, backdrop)
            }
        }

        GlassCard(backdrop) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Glass Slider",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text("${(slider * 100).toInt()}%", color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            GlassSlider(slider, { slider = it }, backdrop)
        }
    }
}

// ---------------------------------------------------------------- About

@Composable
fun AboutScreen(backdrop: Backdrop) {
    val uri = LocalUriHandler.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 28.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(96.dp)
                .glass(backdrop, RoundedCornerShape(30.dp), Color.White.copy(alpha = 0.18f))
                .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Info, null, tint = Color.White, modifier = Modifier.size(44.dp))
        }
        Text("About", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)

        GlassCard(backdrop) {
            Text(
                "Liquid Glass",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "تطبيق تجريبي يستعرض مكتبة Backdrop لتصميم الزجاج السائل (Liquid Glass) على أندرويد باستخدام Jetpack Compose.\n\n" +
                    "يحتوي على شريط سفلي زجاجي مع مؤشر قابل للسحب، وتأثيرات انكسار وتمويه للضوء، وحركات سلسة بأسلوب Apple.\n\n" +
                    "تبويب Profile يتيح لك ملفاً شخصياً بأسلوب تيك توك: صورة، بانر بتلاشي من الأسفل، اسم ومعرف، وقصة تختفي بعد 24 ساعة. كل شيء قابل للتخصيص.",
                color = Color.White.copy(alpha = 0.88f),
                fontSize = 15.sp,
                lineHeight = 24.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Text("Follow me", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            GlassButton(
                "Telegram", backdrop, Modifier.weight(1f),
                tint = Color(0xFF29A8E8).copy(alpha = 0.35f)
            ) { uri.openUri("https://t.me/xezn9") }
            GlassButton(
                "TikTok", backdrop, Modifier.weight(1f),
                tint = Color(0xFFFF2D6F).copy(alpha = 0.35f)
            ) { uri.openUri("https://www.tiktok.com/@xezn99") }
        }
        Text("Telegram: @xezn9  •  TikTok: @xezn99", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
    }
}

// ---------------------------------------------------------------- Profile

@Composable
fun ProfileScreen(
    backdrop: Backdrop,
    profile: ProfileData,
    storyActive: Boolean,
    remaining: String,
    avatar: ImageBitmap?,
    banner: ImageBitmap?,
    storyImage: ImageBitmap?,
    onEdit: () -> Unit,
    onAddStory: () -> Unit,
    onViewStory: () -> Unit,
    onDeleteStory: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 130.dp)
    ) {
        Box(Modifier.fillMaxWidth()) {
            // Banner: fades out only at the bottom (TikTok style)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            brush = Brush.verticalGradient(
                                0f to Color.Black,
                                0.55f to Color.Black,
                                1f to Color.Transparent
                            ),
                            blendMode = BlendMode.DstIn
                        )
                    }
            ) {
                if (banner != null) {
                    Image(
                        bitmap = banner,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF7C4DFF), Color(0xFF00B0FF), Color(0xFFFF4081))
                                )
                            )
                    )
                }
            }

            GlassIconButton(
                Icons.Filled.Edit, backdrop,
                Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(16.dp),
                onClick = onEdit
            )

            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 200.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                StoryAvatar(
                    bitmap = avatar,
                    initial = profile.name.take(1).uppercase(),
                    hasStory = storyActive,
                    backdrop = backdrop,
                    onClick = { if (storyActive) onViewStory() else onEdit() },
                    onAdd = onAddStory
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    profile.name.ifBlank { "Your name" },
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
                Text(
                    "@" + profile.username.ifBlank { "username" },
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 16.sp
                )
                Spacer(Modifier.height(20.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GlassButton("Edit Profile", backdrop, Modifier.weight(1f), Icons.Filled.Edit, onClick = onEdit)
                    GlassButton("Add Story", backdrop, Modifier.weight(1f), Icons.Filled.Add, onClick = onAddStory)
                }
                Spacer(Modifier.height(20.dp))

                if (storyActive) {
                    GlassCard(
                        backdrop,
                        Modifier
                            .padding(horizontal = 20.dp)
                            .bouncyClick(onClick = onViewStory)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        Brush.linearGradient(listOf(Color(0xFFFF4081), Color(0xFFFFB300)))
                                    )
                            ) {
                                if (storyImage != null) {
                                    Image(
                                        bitmap = storyImage,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Your story", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    profile.storyText.ifBlank { "Photo story" },
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(remaining, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                            }
                            GlassIconButton(Icons.Filled.Close, backdrop, size = 40.dp, onClick = onDeleteStory)
                        }
                    }
                } else {
                    Text(
                        "No active story. Tap + to share one — it disappears after 24 hours.",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 36.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StoryAvatar(
    bitmap: ImageBitmap?,
    initial: String,
    hasStory: Boolean,
    backdrop: Backdrop,
    onClick: () -> Unit,
    onAdd: () -> Unit
) {
    val ring: Brush = if (hasStory) {
        Brush.sweepGradient(
            listOf(Color(0xFFFF4081), Color(0xFFFFB300), Color(0xFFFFEB3B), Color(0xFFFF4081))
        )
    } else {
        SolidColor(Color.White.copy(alpha = 0.4f))
    }
    Box(Modifier.size(116.dp)) {
        Box(
            Modifier
                .fillMaxSize()
                .bouncyClick(onClick = onClick)
        ) {
            Box(Modifier.fillMaxSize().border(3.5.dp, ring, CircleShape))
            Box(
                Modifier
                    .padding(8.dp)
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color(0xFF2A2F4A)),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(initial, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        GlassIconButton(
            Icons.Filled.Add, backdrop,
            Modifier.align(Alignment.BottomEnd),
            size = 36.dp,
            onClick = onAdd
        )
    }
}

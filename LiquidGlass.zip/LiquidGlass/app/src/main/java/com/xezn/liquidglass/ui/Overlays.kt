package com.xezn.liquidglass.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.xezn.liquidglass.ProfileData
import com.xezn.liquidglass.ProfileStore
import kotlinx.coroutines.launch

// ---------------------------------------------------------------- Bottom sheet

@Composable
fun BoxScope.GlassSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    backdrop: Backdrop,
    content: @Composable ColumnScope.() -> Unit
) {
    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .noRipple(onDismiss)
        )
    }
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = slideInVertically(spring<IntOffset>(dampingRatio = 0.82f, stiffness = 330f)) { it } + fadeIn(),
        exit = slideOutVertically(tween<IntOffset>(260)) { it } + fadeOut()
    ) {
        val shape = RoundedCornerShape(36.dp)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(10.dp)
                .glass(backdrop, shape, Color(0xFF0E1230).copy(alpha = 0.55f), 14.dp)
                .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
                .noRipple { }
                .verticalScroll(rememberScrollState())
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

@Composable
fun GlassField(value: String, onChange: (String) -> Unit, hint: String, singleLine: Boolean = true) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.12f))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        if (value.isEmpty()) {
            Text(hint, color = Color.White.copy(alpha = 0.45f), fontSize = 16.sp)
        }
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// ---------------------------------------------------------------- Edit profile

@Composable
fun ColumnScope.EditProfileContent(
    profile: ProfileData,
    store: ProfileStore,
    backdrop: Backdrop,
    onSave: (ProfileData) -> Unit,
    onCancel: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(profile.name) }
    var username by remember { mutableStateOf(profile.username) }
    var avatarPath by remember { mutableStateOf(profile.avatarPath) }
    var bannerPath by remember { mutableStateOf(profile.bannerPath) }
    val avatarImg = rememberImage(avatarPath)
    val bannerImg = rememberImage(bannerPath)

    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { store.importAsync(uri, "avatar")?.let { avatarPath = it } }
    }
    val pickBanner = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { store.importAsync(uri, "banner")?.let { bannerPath = it } }
    }
    val imageOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)

    Text("Edit Profile", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)

    // Banner
    Box(
        Modifier
            .bouncyClick { pickBanner.launch(imageOnly) }
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF7C4DFF), Color(0xFF00B0FF), Color(0xFFFF4081)))),
        contentAlignment = Alignment.Center
    ) {
        if (bannerImg != null) {
            Image(bannerImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Text(
            "Tap to change banner",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(Capsule)
                .background(Color.Black.copy(alpha = 0.35f))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }

    // Avatar
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .bouncyClick { pickAvatar.launch(imageOnly) }
                .size(72.dp)
                .clip(CircleShape)
                .background(Color(0xFF2A2F4A)),
            contentAlignment = Alignment.Center
        ) {
            if (avatarImg != null) {
                Image(avatarImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Text(name.take(1).uppercase(), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(14.dp))
        Text("Tap the circle to change your profile photo", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
    }

    GlassField(name, { name = it.take(30) }, "Name")
    GlassField(username, { username = it.filter { c -> c.isLetterOrDigit() || c == '_' || c == '.' }.take(24) }, "Username")

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        GlassButton("Cancel", backdrop, Modifier.weight(1f), onClick = onCancel)
        GlassButton("Save", backdrop, Modifier.weight(1f), tint = Color(0xFF34C759).copy(alpha = 0.4f)) {
            onSave(
                profile.copy(
                    name = name.trim(),
                    username = username.trim(),
                    avatarPath = avatarPath,
                    bannerPath = bannerPath
                )
            )
        }
    }
}

// ---------------------------------------------------------------- Story editor

@Composable
fun ColumnScope.StoryEditorContent(
    store: ProfileStore,
    backdrop: Backdrop,
    onPost: (String, String?) -> Unit,
    onCancel: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var imagePath by remember { mutableStateOf<String?>(null) }
    val img = rememberImage(imagePath)
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { store.importAsync(uri, "story")?.let { imagePath = it } }
    }

    Text("New Story", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Text("Disappears automatically after 24 hours.", color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp)

    Box(
        Modifier
            .bouncyClick { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFFF4081), Color(0xFFFFB300)))),
        contentAlignment = Alignment.Center
    ) {
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Text(
            if (img == null) "Tap to add a photo" else "Tap to change photo",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(Capsule)
                .background(Color.Black.copy(alpha = 0.35f))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }

    GlassField(text, { text = it.take(200) }, "Write something…", singleLine = false)

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        GlassButton("Cancel", backdrop, Modifier.weight(1f), onClick = onCancel)
        GlassButton("Post", backdrop, Modifier.weight(1f), tint = Color(0xFFFF4081).copy(alpha = 0.45f)) {
            if (text.isNotBlank() || imagePath != null) onPost(text.trim(), imagePath)
        }
    }
}

// ---------------------------------------------------------------- Story viewer

@Composable
fun BoxScope.StoryViewer(
    visible: Boolean,
    profile: ProfileData,
    remaining: String,
    avatar: ImageBitmap?,
    storyImage: ImageBitmap?,
    backdrop: Backdrop,
    onClose: () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.fillMaxSize(),
        enter = scaleIn(initialScale = 0.85f) + fadeIn(),
        exit = scaleOut(targetScale = 0.9f) + fadeOut()
    ) {
        val progress = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            progress.animateTo(1f, tween(7000, easing = LinearEasing))
            onClose()
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .noRipple(onClose)
        ) {
            if (storyImage != null) {
                Image(storyImage, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)))
            } else {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.linearGradient(listOf(Color(0xFF7C4DFF), Color(0xFFFF4081), Color(0xFFFFB300))))
                )
            }
            if (profile.storyText.isNotBlank()) {
                Text(
                    profile.storyText,
                    color = Color.White,
                    fontSize = 30.sp,
                    lineHeight = 38.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.Black.copy(alpha = if (storyImage != null) 0.35f else 0f))
                        .padding(16.dp)
                )
            }
            Column(Modifier.statusBarsPadding().padding(16.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(Capsule)
                        .background(Color.White.copy(alpha = 0.3f))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(progress.value)
                            .height(4.dp)
                            .background(Color.White)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2A2F4A)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (avatar != null) {
                            Image(avatar, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        } else {
                            Text(profile.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(profile.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(remaining, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
                    }
                    GlassIconButton(Icons.Filled.Close, backdrop, size = 40.dp, onClick = onClose)
                }
            }
        }
    }
}

package com.xezn.liquidglass.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sign

data class TabItem(val label: String, val icon: ImageVector)

/**
 * Liquid glass bottom tabs modelled on the "Bottom tabs" screen of Backdrop Catalog:
 *  - glass capsule that grows while pressed and rubber-bands while dragging
 *  - a hidden accent-colored copy of the tabs ("tabsBackdrop") that the selection
 *    pill refracts, so the selected tab is revealed in the accent color
 *  - a draggable pill with damped (spring) motion, jelly deformation by velocity
 *    and a lens that appears while pressed
 */
@Composable
fun LiquidBottomTabs(
    backdrop: Backdrop,
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val dark = isSystemInDarkTheme()
    val accent = if (dark) Color(0xFF0091FF) else Color(0xFF0088FF)
    val container = if (dark) Color(0xFF121212).copy(alpha = 0.4f) else Color(0xFFFAFAFA).copy(alpha = 0.4f)
    val content = if (dark) Color.White else Color.Black

    val count = tabs.size
    val tabsBackdrop = rememberLayerBackdrop()
    val scope = rememberCoroutineScope()
    val currentSelected by rememberUpdatedState(selected)

    val value = remember { Animatable(selected.toFloat()) }      // pill position, in tab units
    val press = remember { Animatable(0f) }                      // 0..1 press progress
    val offsetAnim = remember { Animatable(0f) }                 // rubber-band offset of whole panel (px)

    LaunchedEffect(selected) {
        value.animateTo(selected.toFloat(), spring<Float>(dampingRatio = 0.8f, stiffness = 380f))
    }

    BoxWithConstraints(modifier, contentAlignment = Alignment.CenterStart) {
        val density = LocalDensity.current
        val barW = constraints.maxWidth.toFloat()
        val inset = with(density) { 4.dp.toPx() }
        val maxShift = with(density) { 4.dp.toPx() }
        val tabWidthPx = (barW - inset * 2f) / count

        fun panelOffsetPx(): Float {
            val f = (offsetAnim.value / barW).coerceIn(-1f, 1f)
            return maxShift * f.sign * EaseOut.transform(abs(f))
        }

        // ---------------------------------------------------------------- glass container + tabs
        Row(
            Modifier
                .graphicsLayer { translationX = panelOffsetPx() }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { Capsule },
                    effects = {
                        vibrancy()
                        blur(8.dp.toPx())
                        lens(24.dp.toPx(), 24.dp.toPx())
                    },
                    layerBlock = {
                        val s = lerp(1f, 1f + 16.dp.toPx() / size.width, press.value)
                        scaleX = s
                        scaleY = s
                    },
                    onDrawSurface = {
                        drawRect(container)
                        // soft glow that follows the pill while it is pressed
                        val p = press.value
                        if (p > 0.01f) {
                            val cx = (value.value + 0.5f) * tabWidthPx + inset
                            drawRect(
                                Brush.radialGradient(
                                    listOf(Color.White.copy(alpha = 0.22f * p), Color.Transparent),
                                    center = Offset(cx, size.height / 2f),
                                    radius = size.height * 1.2f
                                )
                            )
                        }
                    }
                )
                .height(64.dp)
                .fillMaxWidth()
                .pointerInput(count, tabWidthPx) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        scope.launch { press.animateTo(1f, spring<Float>(dampingRatio = 1f, stiffness = 1000f)) }
                        var moved = false
                        drag(down.id) { change ->
                            if (!moved && abs(change.position.x - down.position.x) > viewConfiguration.touchSlop) {
                                moved = true
                            }
                            if (moved) {
                                val dx = change.positionChange().x
                                scope.launch {
                                    value.snapTo(
                                        (value.value + dx / tabWidthPx).coerceIn(0f, (count - 1).toFloat())
                                    )
                                    offsetAnim.snapTo(offsetAnim.value + dx)
                                }
                                change.consume()
                            }
                        }
                        val idx = (
                            if (moved) value.value.roundToInt()
                            else ((down.position.x - inset) / tabWidthPx).toInt()
                            ).coerceIn(0, count - 1)
                        scope.launch { press.animateTo(0f, spring<Float>(dampingRatio = 1f, stiffness = 1000f)) }
                        scope.launch { value.animateTo(idx.toFloat(), spring<Float>(dampingRatio = 0.8f, stiffness = 380f)) }
                        scope.launch { offsetAnim.animateTo(0f, spring<Float>(1f, 300f, 0.5f)) }
                        if (idx != currentSelected) onSelect(idx)
                    }
                }
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { TabCell(it, content) { 1f } }
        }

        // ---------------------------------------------------------------- hidden accent copy (refracted by the pill)
        Row(
            Modifier
                .clearAndSetSemantics { }
                .alpha(0f)
                .layerBackdrop(tabsBackdrop)
                .graphicsLayer { translationX = panelOffsetPx() }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { Capsule },
                    effects = {
                        val p = press.value
                        vibrancy()
                        blur(8.dp.toPx())
                        lens(24.dp.toPx() * p, 24.dp.toPx() * p)
                    },
                    onDrawSurface = { drawRect(container) }
                )
                .height(56.dp)
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { TabCell(it, accent) { lerp(1f, 1.2f, press.value) } }
        }

        // ---------------------------------------------------------------- selection pill
        Box(
            Modifier
                .padding(horizontal = 4.dp)
                .graphicsLayer { translationX = value.value * tabWidthPx + panelOffsetPx() }
                .drawBackdrop(
                    backdrop = rememberCombinedBackdrop(backdrop, tabsBackdrop),
                    shape = { Capsule },
                    effects = {
                        val p = press.value
                        lens(10.dp.toPx() * p, 14.dp.toPx() * p)
                    },
                    layerBlock = {
                        val s = lerp(1f, 78f / 56f, press.value)
                        val v = value.velocity / 10f
                        scaleX = s / (1f - (v * 0.75f).coerceIn(-0.2f, 0.2f))
                        scaleY = s * (1f - (v * 0.25f).coerceIn(-0.2f, 0.2f))
                    },
                    onDrawSurface = {
                        val p = press.value
                        drawRect(container.copy(alpha = 0.3f), alpha = 1f - p)
                        drawRect(Color.Black.copy(alpha = 0.03f * p))
                    }
                )
                .height(56.dp)
                .width(with(density) { tabWidthPx.toDp() })
        )
    }
}

@Composable
private fun RowScope.TabCell(item: TabItem, color: Color, scale: () -> Float) {
    Column(
        Modifier
            .clip(Capsule)
            .fillMaxHeight()
            .weight(1f)
            .graphicsLayer {
                val s = scale()
                scaleX = s
                scaleY = s
            },
        verticalArrangement = Arrangement.spacedBy(2.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(item.icon, contentDescription = item.label, tint = color, modifier = Modifier.size(24.dp))
        Text(item.label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

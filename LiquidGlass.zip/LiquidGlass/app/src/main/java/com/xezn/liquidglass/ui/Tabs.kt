package com.xezn.liquidglass.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

data class TabItem(val label: String, val icon: ImageVector)

/**
 * Liquid glass bottom tabs (same idea as the Backdrop catalog "Bottom tabs"):
 * a glass capsule with a draggable glass indicator that stretches while pressed.
 */
@Composable
fun LiquidBottomTabs(
    backdrop: Backdrop,
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val count = tabs.size
    val pad = 5.dp
    val currentSelected by rememberUpdatedState(selected)

    BoxWithConstraints(modifier.fillMaxWidth().height(70.dp)) {
        val tabWidth = (maxWidth - pad * 2) / count
        val tabW = with(density) { tabWidth.toPx() }
        val padPx = with(density) { pad.toPx() }

        val anim = remember(tabW) { Animatable(selected * tabW) }
        var dragX by remember { mutableStateOf<Float?>(null) }
        var pressed by remember { mutableStateOf(false) }

        LaunchedEffect(selected, tabW) {
            anim.animateTo(selected * tabW, spring(0.62f, 380f))
        }

        val x = dragX ?: anim.value
        val indicatorScale by animateFloatAsState(
            if (pressed) 1.14f else 1f, spring(0.5f, 420f), label = "indicatorScale"
        )
        val active = (x / tabW).roundToInt().coerceIn(0, count - 1)

        Box(
            Modifier
                .fillMaxSize()
                .glass(backdrop, Capsule, Color.White.copy(alpha = 0.12f), 10.dp)
                .border(1.dp, Color.White.copy(alpha = 0.25f), Capsule)
                .pointerInput(tabW, count) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        pressed = true
                        var moved = false
                        drag(down.id) { change ->
                            if (!moved && abs(change.position.x - down.position.x) > viewConfiguration.touchSlop) {
                                moved = true
                            }
                            if (moved) {
                                val cur = dragX ?: anim.value
                                dragX = (cur + change.positionChange().x)
                                    .coerceIn(0f, tabW * (count - 1))
                                change.consume()
                            }
                        }
                        pressed = false
                        val from = dragX ?: anim.value
                        val idx = if (moved) {
                            (from / tabW).roundToInt().coerceIn(0, count - 1)
                        } else {
                            ((down.position.x - padPx) / tabW).toInt().coerceIn(0, count - 1)
                        }
                        dragX = null
                        scope.launch {
                            anim.snapTo(from)
                            anim.animateTo(idx * tabW, spring(0.62f, 380f))
                        }
                        if (idx != currentSelected) onSelect(idx)
                    }
                }
        ) {
            // Glass indicator
            Box(
                Modifier
                    .padding(pad)
                    .offset { IntOffset(x.roundToInt(), 0) }
                    .width(tabWidth)
                    .fillMaxHeight()
                    .graphicsLayer {
                        scaleX = indicatorScale
                        scaleY = indicatorScale
                    }
                    .glass(backdrop, Capsule, Color.White.copy(alpha = 0.28f), 2.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.45f), Capsule)
            )

            // Tab items
            Row(Modifier.padding(pad).fillMaxSize()) {
                tabs.forEachIndexed { i, t ->
                    val color by animateColorAsState(
                        if (i == active) Color.White else Color.White.copy(alpha = 0.6f),
                        label = "tabColor"
                    )
                    Column(
                        Modifier.width(tabWidth).fillMaxHeight(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(t.icon, contentDescription = t.label, tint = color, modifier = Modifier.size(24.dp))
                        Text(t.label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

package com.xezn.liquidglass.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.xezn.liquidglass.ProfileData
import com.xezn.liquidglass.ProfileStore
import kotlinx.coroutines.delay

@Composable
fun LiquidApp() {
    val context = LocalContext.current
    val store = remember { ProfileStore(context) }
    var profile by remember { mutableStateOf(store.load()) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var showStoryEditor by rememberSaveable { mutableStateOf(false) }
    var showViewer by rememberSaveable { mutableStateOf(false) }

    val bgBackdrop = rememberLayerBackdrop()
    val contentBackdrop = rememberLayerBackdrop()

    val storyActive = profile.isStoryActive(now)
    val remaining = profile.remainingText(now)
    val avatarImg = rememberImage(profile.avatarPath)
    val bannerImg = rememberImage(profile.bannerPath)
    val storyImg = rememberImage(profile.storyImagePath)

    fun commit(p: ProfileData) {
        profile = p
        store.save(p)
    }

    val tabs = remember {
        listOf(
            TabItem("Home", Icons.Filled.Home),
            TabItem("About", Icons.Filled.Info),
            TabItem("Profile", Icons.Filled.Person)
        )
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Everything the glass tab bar can "see" lives inside contentBackdrop.
        Box(Modifier.fillMaxSize().layerBackdrop(contentBackdrop)) {
            // Colorful world that cards/buttons refract.
            Box(Modifier.fillMaxSize().layerBackdrop(bgBackdrop)) {
                AuroraBackground()
            }

            AnimatedContent(
                targetState = tab,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally(spring<IntOffset>(dampingRatio = 0.85f, stiffness = 300f)) { dir * it / 3 } +
                        fadeIn()) togetherWith
                        (slideOutHorizontally(spring<IntOffset>(dampingRatio = 0.85f, stiffness = 300f)) { -dir * it / 3 } +
                            fadeOut())
                },
                label = "screens"
            ) { page ->
                when (page) {
                    0 -> HomeScreen(bgBackdrop)
                    1 -> AboutScreen(bgBackdrop)
                    else -> ProfileScreen(
                        backdrop = bgBackdrop,
                        profile = profile,
                        storyActive = storyActive,
                        remaining = remaining,
                        avatar = avatarImg,
                        banner = bannerImg,
                        storyImage = storyImg,
                        onEdit = { showEditor = true },
                        onAddStory = { showStoryEditor = true },
                        onViewStory = { showViewer = true },
                        onDeleteStory = {
                            commit(profile.copy(storyText = "", storyImagePath = null, storyTime = 0L))
                        }
                    )
                }
            }
        }

        LiquidBottomTabs(
            backdrop = contentBackdrop,
            tabs = tabs,
            selected = tab,
            onSelect = { tab = it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 14.dp)
        )

        GlassSheet(showEditor, { showEditor = false }, contentBackdrop) {
            EditProfileContent(
                profile = profile,
                store = store,
                backdrop = contentBackdrop,
                onSave = {
                    commit(it)
                    showEditor = false
                },
                onCancel = { showEditor = false }
            )
        }

        GlassSheet(showStoryEditor, { showStoryEditor = false }, contentBackdrop) {
            StoryEditorContent(
                store = store,
                backdrop = contentBackdrop,
                onPost = { text, path ->
                    commit(
                        profile.copy(
                            storyText = text,
                            storyImagePath = path,
                            storyTime = System.currentTimeMillis()
                        )
                    )
                    showStoryEditor = false
                },
                onCancel = { showStoryEditor = false }
            )
        }

        StoryViewer(
            visible = showViewer && storyActive,
            profile = profile,
            remaining = remaining,
            avatar = avatarImg,
            storyImage = storyImg,
            backdrop = contentBackdrop,
            onClose = { showViewer = false }
        )
    }
}

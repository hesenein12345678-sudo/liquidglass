package com.xezn.liquidglass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

const val DAY_MS = 24L * 60L * 60L * 1000L

data class ProfileData(
    val name: String = "Xezn",
    val username: String = "xezn99",
    val avatarPath: String? = null,
    val bannerPath: String? = null,
    val storyText: String = "",
    val storyImagePath: String? = null,
    val storyTime: Long = 0L
) {
    /** Story is alive only for 24 hours after posting. */
    fun isStoryActive(now: Long): Boolean =
        storyTime > 0L &&
            now - storyTime < DAY_MS &&
            (storyText.isNotBlank() || storyImagePath != null)

    fun remainingText(now: Long): String {
        val r = (DAY_MS - (now - storyTime)).coerceAtLeast(0L)
        val h = r / 3_600_000L
        val m = (r / 60_000L) % 60L
        return "Expires in ${h}h ${m}m"
    }
}

class ProfileStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("profile", Context.MODE_PRIVATE)

    fun load(): ProfileData {
        var p = ProfileData(
            name = prefs.getString("name", "Xezn") ?: "Xezn",
            username = prefs.getString("username", "xezn99") ?: "xezn99",
            avatarPath = prefs.getString("avatar", null),
            bannerPath = prefs.getString("banner", null),
            storyText = prefs.getString("storyText", "") ?: "",
            storyImagePath = prefs.getString("storyImage", null),
            storyTime = prefs.getLong("storyTime", 0L)
        )
        if (!p.isStoryActive(System.currentTimeMillis())) {
            p = p.copy(storyText = "", storyImagePath = null, storyTime = 0L)
        }
        return p
    }

    fun save(p: ProfileData) {
        prefs.edit()
            .putString("name", p.name)
            .putString("username", p.username)
            .putString("avatar", p.avatarPath)
            .putString("banner", p.bannerPath)
            .putString("storyText", p.storyText)
            .putString("storyImage", p.storyImagePath)
            .putLong("storyTime", p.storyTime)
            .apply()
    }

    /** Copies a picked image into app storage (downscaled) and returns its path. */
    fun importImage(uri: Uri, prefix: String, maxSide: Int = 1600): String? {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) {
                null
            } else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                if (bmp == null) {
                    null
                } else {
                    val file = File(context.filesDir, "${prefix}_${System.currentTimeMillis()}.jpg")
                    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    file.absolutePath
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun importAsync(uri: Uri, prefix: String): String? =
        withContext(Dispatchers.IO) { importImage(uri, prefix) }
}

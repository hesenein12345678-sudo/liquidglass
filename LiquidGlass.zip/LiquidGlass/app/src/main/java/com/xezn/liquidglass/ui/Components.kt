package com.xezn.liquidglass.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

val Capsule = RoundedCornerShape(percent = 50)

/** Liquid glass surface built on top of the Backdrop library. */
fun Modifier.glass(
    backdrop: Backdrop,
    shape: Shape,
    tint: Color = Color.White.copy(alpha = 0.14f),
    blurRadius: Dp = 6.dp,
    refraction: Boolean = true
): Modifier = drawBackdrop(
    backdrop = backdrop,
    shape = { shape },
    effects = {
        vibrancy()
        blur(blurRadius.toPx())
        if (refraction) lens(12.dp.toPx(), 24.dp.toPx())
    },
    onDrawSurface = { drawRect(tint) }
)

/** Apple-like springy press animation + click. */
fun Modifier.bouncyClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 420f),
        label = "bounce"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

fun Modifier.noRipple(onClick: () -> Unit): Modifier = composed {
    clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}

@Composable
fun rememberImage(path: String?): ImageBitmap? {
    val state = produceState<ImageBitmap?>(initialValue = null, key1 = path) {
        value = if (path == null) null else withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(path)?.asImageBitmap()
        }
    }
    return state.value
}

@Composable
fun GlassCard(
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .glass(backdrop, shape)
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
            .padding(20.dp),
        content = content
    )
}

@Composable
fun GlassButton(
    text: String,
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    tint: Color = Color.White.copy(alpha = 0.16f),
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .bouncyClick(onClick = onClick)
            .height(52.dp)
            .glass(backdrop, Capsule, tint)
            .border(1.dp, Color.White.copy(alpha = 0.25f), Capsule)
            .padding(horizontal = 22.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
        }
        Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .bouncyClick(onClick = onClick)
            .size(size)
            .glass(backdrop, CircleShape, Color.White.copy(alpha = 0.18f), 4.dp)
            .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(size / 2))
    }
}

@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit, backdrop: Backdrop) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val targetW = if (pressed) 46.dp else 36.dp
    val w by animateDpAsState(targetW, spring(0.6f, 500f), label = "w")
    val x by animateDpAsState(if (checked) 60.dp - targetW else 0.dp, spring(0.55f, 450f), label = "x")
    val track by animateColorAsState(
        if (checked) Color(0xFF34C759) else Color.White.copy(alpha = 0.25f),
        label = "track"
    )
    Box(
        Modifier
            .width(68.dp)
            .height(40.dp)
            .clip(Capsule)
            .background(track)
            .clickable(interactionSource = source, indication = null) { onChange(!checked) }
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .offset(x = x)
                .width(w)
                .height(32.dp)
                .glass(backdrop, Capsule, Color.White.copy(alpha = 0.85f), 2.dp)
                .border(1.dp, Color.White.copy(alpha = 0.6f), Capsule)
        )
    }
}

@Composable
fun GlassSlider(value: Float, onChange: (Float) -> Unit, backdrop: Backdrop) {
    val current by rememberUpdatedState(value)
    var dragging by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (dragging) 1.25f else 1f, spring(0.5f, 450f), label = "thumb"
    )
    BoxWithConstraints(Modifier.fillMaxWidth().height(44.dp)) {
        val thumb = 40.dp
        val trackWpx = with(LocalDensity.current) { (maxWidth - thumb).toPx() }
        Box(
            Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .padding(horizontal = thumb / 2)
                .height(8.dp)
                .clip(Capsule)
                .background(Color.White.copy(alpha = 0.22f))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(value.coerceIn(0.02f, 1f))
                    .background(Color.White.copy(alpha = 0.85f))
            )
        }
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset { IntOffset((trackWpx * value).roundToInt(), 0) }
                .size(thumb)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .glass(backdrop, CircleShape, Color.White.copy(alpha = 0.8f), 2.dp)
                .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                .pointerInput(trackWpx) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false }
                    ) { change, delta ->
                        change.consume()
                        onChange((current + delta / trackWpx).coerceIn(0f, 1f))
                    }
                }
        )
    }
}

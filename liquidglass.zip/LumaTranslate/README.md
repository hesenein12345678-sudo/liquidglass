# Luma Translate

تطبيق Android لترجمة النصوص الموجودة داخل لقطات الشاشة. واجهة التطبيق تستخدم مكتبة Backdrop الفعلية وتأثيرات الزجاج على البطاقات والأزرار والشريط السفلي، مع مكونات محلية لتجنب أخطاء الاستيراد من Catalog.

## البناء من GitHub
1. أنشئ مستودعاً جديداً في GitHub وارفع جميع الملفات، بما فيها `.github/workflows` و`tools/fetch_backdrop_catalog_components.sh`.
2. افتح تبويب **Actions** وشغّل **Build Android APK** أو انتظر تشغيله بعد رفع الملفات.
3. افتح عملية البناء الناجحة ونزّل `LumaTranslate-debug-apk` من قسم **Artifacts**.
4. فك الضغط وثبّت `app-debug.apk`.

## التخصيص
- تغيير الأيقونة من الإعدادات يبدّل Launcher Activity Alias في Android، ولذلك تتغير أيقونة التطبيق الخارجية في الشاشة الرئيسية/قائمة التطبيقات، وليس فقط الأيقونة داخل الواجهة.
- اختصار الترجمة يختفي تلقائياً بعد 6 ثوانٍ من ظهوره، ويختفي كذلك عند الضغط عليه.
- الألوان والخلفيات والوضع الداكن والفاتح محفوظة في إعدادات التطبيق. يمكنك اختيار صورة من المعرض كخلفية، ويُحفظ رابطها لاستخدامها لاحقاً.
- الواجهة تستخدم تأثيرات Backdrop في البطاقات والأزرار والشريط السفلي.

## متطلبات وملاحظات
- يحتاج البناء إلى اتصال بالإنترنت لتنزيل تبعيات Gradle.
- لم يتم التحقق من نجاح بناء النسخة المعدلة في بيئة Android فعلية. إذا فشل GitHub Actions، أرسل سجل الخطأ لتحديد المشكلة بدقة.
- مراقبة الصور تعتمد على صلاحيات Android وطريقة تسمية لقطات الشاشة، وقد تقيد بعض الأجهزة تشغيل الخدمة في الخلفية.
- المشروع يستخدم مكتبة Backdrop من مستودعها الأصلي.

## تحديثات النسخة 1.0.3
- تستخدم المكتبة الفعلية `io.github.kyant0:backdrop:2.0.1`.
- استبدال استيرادات Catalog غير الموجودة بمكونات محلية تعتمد على Backdrop لتجنب أخطاء Kotlin.
- إضافة اختيار صورة خلفية من المعرض وحفظها بعد إعادة فتح التطبيق.
- إصلاح مورد أيقونة Spark الذي كان اسمه غير مطابق للاسم المشار إليه في Manifest.
- تغيير الأيقونة من صفحة الإعدادات يبدّل مكوّن Launcher في Android لتغيير أيقونة التطبيق الخارجية فعلياً.


## GitHub Actions archive handling (v1.0.4)
The included workflow supports either committing the project files directly or placing this project ZIP inside a repository file named `liquidglass.zip`. It extracts nested ZIPs and finds `settings.gradle.kts` before running Gradle. Build output is uploaded as `LumaTranslate-debug-apk`.

package com.xezn.lumatranslate

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBasicPermissions()
        setContent { LumaApp(this) }
    }
    private fun requestBasicPermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            p += Manifest.permission.READ_MEDIA_IMAGES
            p += Manifest.permission.POST_NOTIFICATIONS
        } else p += Manifest.permission.READ_EXTERNAL_STORAGE
        permissionLauncher.launch(p.toTypedArray())
    }
}

private val accentOptions = listOf("أزرق" to "#7C8CFF", "بنفسجي" to "#B28DFF", "وردي" to "#FF82B2", "نعناعي" to "#70E1C1", "برتقالي" to "#FFB86B")
private val iconOptions = listOf("✨" , "🌐", "文", "🔮", "💬", "⚡")
private val languages = listOf("العربية", "English", "فارسی", "Türkçe", "Français", "Español", "Deutsch", "日本語", "한국어", "中文")

@Composable
fun LumaApp(activity: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    var dark by remember { mutableStateOf(Prefs.bool(activity, "dark", true)) }
    var accent by remember { mutableStateOf(Prefs.get(activity, "accent", "#7C8CFF")) }
    var icon by remember { mutableStateOf(Prefs.get(activity, "icon", "✨")) }
    var language by remember { mutableStateOf(Prefs.get(activity, "language", "العربية")) }
    var wallpaper by remember { mutableStateOf(Prefs.get(activity, "wallpaper", "Aurora")) }
    var showLanguage by remember { mutableStateOf(false) }
    val a = Color(android.graphics.Color.parseColor(accent))
    val bg = if (dark) Color(0xFF0B1020) else Color(0xFFF3F5FC)
    val panel = if (dark) Color(0xCC1D2540) else Color(0xCCFFFFFF)
    val ink = if (dark) Color(0xFFF4F5FF) else Color(0xFF172039)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=a, background=bg, surface=panel) else lightColorScheme(primary=a, background=bg, surface=panel)) {
        Box(Modifier.fillMaxSize().background(bg)) {
            // Soft color haze behind translucent cards for a Liquid-Glass-inspired look.
            Box(Modifier.fillMaxSize().background(
                when (wallpaper) {
                    "Ocean" -> Color(0xFF0A3450)
                    "Rose" -> Color(0xFF3A1B35)
                    "Sunset" -> Color(0xFF422A23)
                    else -> if (dark) Color(0xFF121A36) else Color(0xFFE7ECFF)
                }.copy(alpha = if (dark) .55f else .45f)
            ))
            Column(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                    Box(Modifier.size(48.dp).background(a.copy(alpha=.22f), CircleShape), contentAlignment=Alignment.Center) {
                        Text(icon, fontSize=24.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Luma Translate", fontSize=22.sp, fontWeight=FontWeight.Bold, color=ink)
                        Text("ترجم لقطة الشاشة بلمسة واحدة", color=ink.copy(alpha=.65f), fontSize=12.sp)
                    }
                    IconButton(onClick={ tab=2 }) { Icon(Icons.Default.Settings, null, tint=ink) }
                }
                Spacer(Modifier.height(18.dp))
                when(tab) {
                    0 -> HomePage(activity, a, ink, panel)
                    1 -> HistoryPage(ink, panel)
                    else -> SettingsPage(activity, dark, { dark=it; Prefs.setBool(activity,"dark",it) }, accent, {
                        accent=it; Prefs.set(activity,"accent",it)
                    }, icon, { icon=it; Prefs.set(activity,"icon",it) }, language, { language=it; Prefs.set(activity,"language",it) }, wallpaper, { wallpaper=it; Prefs.set(activity,"wallpaper",it) }, a, ink, panel)
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().padding(bottom=14.dp).background(panel, RoundedCornerShape(28.dp)).padding(7.dp), horizontalArrangement=Arrangement.SpaceEvenly) {
                    BottomItem("الرئيسية", Icons.Default.Home, tab==0, a, ink) { tab=0 }
                    BottomItem("الترجمات", Icons.Default.History, tab==1, a, ink) { tab=1 }
                    BottomItem("الإعدادات", Icons.Default.Tune, tab==2, a, ink) { tab=2 }
                }
            }
        }
    }
}

@Composable
private fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, accent: Color, ink: Color, onClick: ()->Unit) {
    Column(Modifier.clipShapeClick(selected, accent, onClick).padding(horizontal=16.dp, vertical=9.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon, null, tint=if(selected) accent else ink.copy(alpha=.65f), modifier=Modifier.size(21.dp))
        Text(label, color=if(selected) accent else ink.copy(alpha=.7f), fontSize=11.sp)
    }
}
private fun Modifier.clipShapeClick(selected:Boolean, accent:Color, onClick:()->Unit) =
    this.background(if(selected) accent.copy(alpha=.16f) else Color.Transparent, RoundedCornerShape(20.dp)).clickable { onClick() }

@Composable
private fun GlassCard(panel: Color, content: @Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(26.dp)).padding(18.dp), content=content)
}

@Composable
private fun HomePage(activity: MainActivity, accent: Color, ink: Color, panel: Color) {
    LazyColumn(verticalArrangement=Arrangement.spacedBy(14.dp), contentPadding=PaddingValues(bottom=10.dp)) {
        item {
            GlassCard(panel) {
                Text("ترجمة ذكية من لقطة الشاشة", color=ink, fontSize=19.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("التقط الشاشة كالمعتاد، ثم اضغط الاختصار العائم لقراءة النص وترجمته.", color=ink.copy(alpha=.7f), fontSize=14.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick={
                    if (!Settings.canDrawOverlays(activity)) {
                        activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
                    } else {
                        activity.startForegroundService(Intent(activity, ScreenshotWatcherService::class.java))
                    }
                }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp)) {
                    Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text("تفعيل اختصار لقطة الشاشة")
                }
                Text("قد تحتاج للسماح بالظهور فوق التطبيقات والإشعارات.", color=ink.copy(alpha=.55f), fontSize=11.sp)
            }
        }
        item {
            GlassCard(panel) {
                Text("وصول سريع", color=ink, fontWeight=FontWeight.Bold, fontSize=17.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick={ activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/xezn9"))) }, modifier=Modifier.weight(1f)) {
                        Icon(Icons.Default.Send, null); Spacer(Modifier.width(5.dp)); Text("تيليجرام")
                    }
                    OutlinedButton(onClick={ activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@xezn99"))) }, modifier=Modifier.weight(1f)) {
                        Icon(Icons.Default.MusicNote, null); Spacer(Modifier.width(5.dp)); Text("تيك توك")
                    }
                }
            }
        }
        item {
            GlassCard(panel) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Translate, null, tint=accent, modifier=Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("لغة الترجمة", color=ink, fontWeight=FontWeight.SemiBold)
                        Text(Prefs.get(activity, "language", "العربية"), color=ink.copy(alpha=.65f), fontSize=13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryPage(ink: Color, panel: Color) {
    GlassCard(panel) {
        Icon(Icons.Default.History, null, tint=ink, modifier=Modifier.size(34.dp))
        Spacer(Modifier.height(12.dp))
        Text("الترجمات", color=ink, fontSize=20.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("ستظهر هنا لاحقاً الترجمات المحفوظة. النسخة الحالية تركز على الاختصار والترجمة الفورية.", color=ink.copy(alpha=.7f))
    }
}

@Composable
private fun SettingsPage(
    activity: MainActivity, dark: Boolean, onDark:(Boolean)->Unit,
    accent: String, onAccent:(String)->Unit, icon:String, onIcon:(String)->Unit,
    language:String, onLanguage:(String)->Unit, wallpaper:String, onWallpaper:(String)->Unit,
    tint:Color, ink:Color, panel:Color
) {
    var showLang by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var round by remember { mutableStateOf(Prefs.bool(activity,"round",true)) }
    var position by remember { mutableStateOf(Prefs.get(activity,"position","يمين")) }
    var shortcutColor by remember { mutableStateOf(Prefs.get(activity,"shortcutColor","#7C8CFF")) }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=12.dp)) {
        item { GlassCard(panel) {
            Text("المظهر والتخصيص", color=ink, fontSize=19.sp, fontWeight=FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("الوضع الداكن", color=ink); Text("تغيير مظهر التطبيق", color=ink.copy(alpha=.6f), fontSize=12.sp) }
                Switch(checked=dark, onCheckedChange=onDark)
            }
            Text("لون الأزرار", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.padding(vertical=10.dp)) {
                accentOptions.forEach { (name, hex) ->
                    Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.clickable { onAccent(hex) }) {
                        Box(Modifier.size(34.dp).background(Color(android.graphics.Color.parseColor(hex)), CircleShape), contentAlignment=Alignment.Center) {
                            if (accent==hex) Icon(Icons.Default.Check, null, tint=Color.White)
                        }
                        Text(name, color=ink.copy(alpha=.75f), fontSize=10.sp)
                    }
                }
            }
            Text("أيقونة التطبيق", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(vertical=8.dp)) {
                iconOptions.forEach { opt ->
                    Box(Modifier.size(43.dp).background(if(icon==opt) tint.copy(alpha=.22f) else ink.copy(alpha=.07f), RoundedCornerShape(14.dp)).clickable { onIcon(opt) }, contentAlignment=Alignment.Center) { Text(opt, fontSize=22.sp) }
                }
            }
            Text("خلفية التطبيق", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(top=8.dp)) {
                listOf("Aurora","Ocean","Rose","Sunset").forEach { w ->
                    FilterChip(selected=wallpaper==w, onClick={ onWallpaper(w) }, label={ Text(w) })
                }
            }
        } }
        item { GlassCard(panel) {
            Text("الترجمة", color=ink, fontSize=18.sp, fontWeight=FontWeight.Bold)
            Row(Modifier.fillMaxWidth().clickable { showLang=true }.padding(vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Language, null, tint=tint); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text("لغة الترجمة", color=ink); Text(language, color=ink.copy(alpha=.65f), fontSize=12.sp) }
                Icon(Icons.Default.ChevronRight, null, tint=ink)
            }
        } }
        item { GlassCard(panel) {
            Text("اختصار لقطة الشاشة", color=ink, fontSize=18.sp, fontWeight=FontWeight.Bold)
            Text("تخصيص شكل الزر العائم الذي يظهر بعد التقاط الشاشة.", color=ink.copy(alpha=.65f), fontSize=12.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("حواف دائرية", color=ink); Text("إيقافها يجعل الاختصار مربعاً", color=ink.copy(alpha=.6f), fontSize=11.sp) }
                Switch(checked=round, onCheckedChange={ round=it; Prefs.setBool(activity,"round",it) })
            }
            Text("لون الاختصار", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.padding(vertical=8.dp)) {
                accentOptions.forEach { (_, hex) ->
                    Box(Modifier.size(30.dp).background(Color(android.graphics.Color.parseColor(hex)), CircleShape).clickable { shortcutColor=hex; Prefs.set(activity,"shortcutColor",hex) }, contentAlignment=Alignment.Center) {
                        if(shortcutColor==hex) Icon(Icons.Default.Check, null, tint=Color.White, modifier=Modifier.size(17.dp))
                    }
                }
            }
            Text("مكان الاختصار", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("يمين","يسار").forEach { p -> FilterChip(selected=position==p, onClick={ position=p; Prefs.set(activity,"position",p) }, label={ Text(p) }) }
            }
            Text("أيقونة الاختصار", color=ink, fontWeight=FontWeight.SemiBold, modifier=Modifier.padding(top=8.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                iconOptions.forEach { opt -> Box(Modifier.size(40.dp).background(if(Prefs.get(activity,"shortcutIcon","✨")==opt) tint.copy(alpha=.2f) else ink.copy(alpha=.07f), RoundedCornerShape(12.dp)).clickable { Prefs.set(activity,"shortcutIcon",opt) }, contentAlignment=Alignment.Center) { Text(opt) } }
            }
        } }
        item { GlassCard(panel) {
            Row(Modifier.fillMaxWidth().clickable { showAbout=true }, verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint=tint); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text("About — حول التطبيق", color=ink, fontWeight=FontWeight.SemiBold); Text("تعرف على Luma Translate", color=ink.copy(alpha=.6f), fontSize=12.sp) }
                Icon(Icons.Default.ChevronRight, null, tint=ink)
            }
        } }
        item { Text("Luma Translate • الإصدار 1.0.0", color=ink.copy(alpha=.45f), fontSize=11.sp, modifier=Modifier.fillMaxWidth(), textAlign=androidx.compose.ui.text.style.TextAlign.Center) }
    }
    if(showLang) AlertDialog(onDismissRequest={showLang=false}, title={Text("لغة الترجمة")}, text={
        LazyColumn { items(languages.size) { i -> Text(languages[i], modifier=Modifier.fillMaxWidth().clickable { onLanguage(languages[i]); showLang=false }.padding(12.dp)) } }
    }, confirmButton={ TextButton(onClick={showLang=false}) { Text("إغلاق") } })
    if(showAbout) AlertDialog(onDismissRequest={showAbout=false}, title={Text("حول Luma Translate")}, text={
        Text("تطبيق يساعدك على فهم النصوص الأجنبية داخل لقطات الشاشة. يراقب الصور الجديدة أثناء تشغيل خدمة الاختصار، ويستخدم التعرف الضوئي على الحروف ثم الترجمة على الجهاز عند توفر نموذج اللغة. يحتاج صلاحية الصور والظهور فوق التطبيقات. قد تختلف إمكانية العمل بالخلفية حسب إصدار Android والشركة المصنّعة.")
    }, confirmButton={ TextButton(onClick={showAbout=false}) { Text("حسناً") } })
}

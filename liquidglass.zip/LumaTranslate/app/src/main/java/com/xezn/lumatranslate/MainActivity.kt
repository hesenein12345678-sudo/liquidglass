package com.xezn.lumatranslate

import android.Manifest
import android.content.Intent
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.catalog.components.LiquidBottomTabs
import com.kyant.backdrop.catalog.components.LiquidBottomTab
import com.kyant.backdrop.catalog.components.LiquidButton
import com.kyant.backdrop.catalog.components.LiquidToggle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBasicPermissions()
        setRealLauncherIcon(Prefs.get(this, "icon", "translate"))
        setContent { LumaApp(this) }
    }
    fun setRealLauncherIcon(key: String) {
        val aliases = mapOf(
            "translate" to ".LauncherTranslate",
            "language" to ".LauncherLanguage",
            "text" to ".LauncherText",
            "auto_awesome" to ".LauncherSpark",
            "chat" to ".LauncherChat",
            "bolt" to ".LauncherBolt"
        )
        val chosen = aliases[key] ?: aliases.getValue("translate")
        aliases.values.forEach { alias ->
            packageManager.setComponentEnabledSetting(
                ComponentName(this, packageName + alias),
                if (alias == chosen) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        Prefs.set(this, "icon", key)
    }

    private fun requestBasicPermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            p += Manifest.permission.READ_MEDIA_IMAGES
            p += Manifest.permission.POST_NOTIFICATIONS
        } else p += Manifest.permission.READ_EXTERNAL_STORAGE
        permissionLauncher.launch(p.toTypedArray())
    }
}

private val accentOptions = listOf("أزرق" to "#7C8CFF", "بنفسجي" to "#B28DFF", "وردي" to "#FF82B2", "نعناعي" to "#70E1C1", "برتقالي" to "#FFB86B")
private val iconOptions = listOf("translate", "language", "text", "auto_awesome", "chat", "bolt")
private fun iconVector(key: String): androidx.compose.ui.graphics.vector.ImageVector = when (key) {
    "language" -> Icons.Default.Language
    "text" -> Icons.Default.TextFields
    "auto_awesome" -> Icons.Default.AutoAwesome
    "chat" -> Icons.Default.ChatBubble
    "bolt" -> Icons.Default.Bolt
    else -> Icons.Default.Translate
}

private val languages = listOf("العربية", "English", "فارسی", "Türkçe", "Français", "Español", "Deutsch", "日本語", "한국어", "中文")

@Composable
fun LumaApp(activity: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    var dark by remember { mutableStateOf(Prefs.bool(activity, "dark", true)) }
    var accent by remember { mutableStateOf(Prefs.get(activity, "accent", "#7C8CFF")) }
    var icon by remember { mutableStateOf(Prefs.get(activity, "icon", "translate")) }
    var language by remember { mutableStateOf(Prefs.get(activity, "language", "العربية")) }
    var wallpaper by remember { mutableStateOf(Prefs.get(activity, "wallpaper", "Aurora")) }
    var showLanguage by remember { mutableStateOf(false) }
    val a = Color(android.graphics.Color.parseColor(accent))
    val bg = if (dark) Color(0xFF0B1020) else Color(0xFFF3F5FC)
    val panel = if (dark) Color(0xCC1D2540) else Color(0xCCFFFFFF)
    val ink = if (dark) Color(0xFFF4F5FF) else Color(0xFF172039)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=a, background=bg, surface=panel) else lightColorScheme(primary=a, background=bg, surface=panel)) {
        val backdrop = rememberLayerBackdrop()
        Box(Modifier.fillMaxSize().background(bg)) {
            // Backdrop source layer: the glass surfaces sample this rendered background.
            Box(
                Modifier.fillMaxSize().layerBackdrop(backdrop)
                    .background(
                        when (wallpaper) {
                            "Ocean" -> Color(0xFF0A3450)
                            "Rose" -> Color(0xFF3A1B35)
                            "Sunset" -> Color(0xFF422A23)
                            else -> if (dark) Color(0xFF121A36) else Color(0xFFE7ECFF)
                        }
                    )
            ) {
                Box(Modifier.fillMaxSize().background(
                    if (dark) Color(0xFF0B1020).copy(alpha=.35f) else Color(0xFFF3F5FC).copy(alpha=.35f)
                ))
            }
            Column(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                    Box(Modifier.size(48.dp).background(a.copy(alpha=.22f), CircleShape), contentAlignment=Alignment.Center) {
                        Icon(iconVector(icon), null, tint=a, modifier=Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Luma Translate", fontSize=22.sp, fontWeight=FontWeight.Bold, color=ink)
                        Text("ترجم لقطة الشاشة بلمسة واحدة", color=ink.copy(alpha=.65f), fontSize=12.sp)
                    }
                    IconButton(onClick={ tab=2 }) { Icon(Icons.Default.Settings, null, tint=ink) }
                }
                Spacer(Modifier.height(18.dp))
                when(tab) {
                    0 -> HomePage(activity, a, ink, panel, backdrop)
                    1 -> HistoryPage(ink, panel, backdrop)
                    else -> SettingsPage(activity, dark, { dark=it; Prefs.setBool(activity,"dark",it) }, accent, {
                        accent=it; Prefs.set(activity,"accent",it)
                    }, icon, { icon=it; activity.setRealLauncherIcon(it) }, language, { language=it; Prefs.set(activity,"language",it) }, wallpaper, { wallpaper=it; Prefs.set(activity,"wallpaper",it) }, a, ink, panel, backdrop)
                }
                Spacer(Modifier.weight(1f))
                LiquidBottomTabs(
                    selectedTabIndex = { tab },
                    onTabSelected = { tab = it },
                    backdrop = backdrop,
                    tabsCount = 3,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                ) {
                    LiquidBottomTab(onClick = { tab = 0 }) {
                        Icon(Icons.Default.Home, null, tint = ink, modifier = Modifier.size(22.dp))
                        Text("الرئيسية", color = ink, fontSize = 11.sp)
                    }
                    LiquidBottomTab(onClick = { tab = 1 }) {
                        Icon(Icons.Default.History, null, tint = ink, modifier = Modifier.size(22.dp))
                        Text("الترجمات", color = ink, fontSize = 11.sp)
                    }
                    LiquidBottomTab(onClick = { tab = 2 }) {
                        Icon(Icons.Default.Tune, null, tint = ink, modifier = Modifier.size(22.dp))
                        Text("الإعدادات", color = ink, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, accent: Color, ink: Color, onClick: ()->Unit) {
    Column(Modifier.clipShapeClick(selected, accent, onClick).padding(horizontal=16.dp, vertical=9.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon, null, tint=if(selected) accent else ink.copy(alpha=.65f), modifier=Modifier.size(21.dp))
        Text(label, color=if(selected) accent else ink.copy(alpha=.7f), fontSize=11.sp)
    }
}
private fun Modifier.clipShapeClick(selected:Boolean, accent:Color, onClick:()->Unit) =
    this.background(if(selected) accent.copy(alpha=.16f) else Color.Transparent, RoundedCornerShape(20.dp)).clickable { onClick() }

@Composable
private fun GlassCard(panel: Color, backdrop: LayerBackdrop, content: @Composable ColumnScope.()->Unit) {
    Column(
        Modifier.fillMaxWidth().drawBackdrop(
            backdrop = backdrop,
            shape = { RoundedCornerShape(26.dp) },
            effects = {
                vibrancy()
                blur(10.dp.toPx())
                lens(22.dp.toPx(), 30.dp.toPx())
            },
            onDrawSurface = { drawRect(panel.copy(alpha = .48f)) }
        ).padding(18.dp),
        content=content
    )
}

@Composable
private fun HomePage(activity: MainActivity, accent: Color, ink: Color, panel: Color, backdrop: LayerBackdrop) {
    LazyColumn(verticalArrangement=Arrangement.spacedBy(14.dp), contentPadding=PaddingValues(bottom=10.dp)) {
        item {
            GlassCard(panel, backdrop) {
                Text("ترجمة ذكية من لقطة الشاشة", color=ink, fontSize=19.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("التقط الشاشة كالمعتاد، ثم اضغط الاختصار العائم لقراءة النص وترجمته.", color=ink.copy(alpha=.7f), fontSize=14.sp)
                Spacer(Modifier.height(18.dp))
                LiquidButton(
                    onClick = {
                        if (!Settings.canDrawOverlays(activity)) {
                            activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}")))
                        } else {
                            activity.startForegroundService(Intent(activity, ScreenshotWatcherService::class.java))
                        }
                    },
                    backdrop = backdrop,
                    modifier = Modifier.fillMaxWidth(),
                    tint = accent.copy(alpha = .12f)
                ) {
                    Icon(Icons.Default.Bolt, null, tint = accent)
                    Text("تفعيل اختصار لقطة الشاشة", color = ink)
                }
                Text("قد تحتاج للسماح بالظهور فوق التطبيقات والإشعارات.", color=ink.copy(alpha=.55f), fontSize=11.sp)
            }
        }
        item {
            GlassCard(panel, backdrop) {
                Text("وصول سريع", color=ink, fontWeight=FontWeight.Bold, fontSize=17.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    LiquidButton(onClick={ activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/xezn9"))) }, backdrop=backdrop, modifier=Modifier.weight(1f), tint=accent.copy(alpha=.10f)) {
                        Icon(Icons.Default.Send, null, tint=accent); Text("تيليجرام", color=ink)
                    }
                    LiquidButton(onClick={ activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@xezn99"))) }, backdrop=backdrop, modifier=Modifier.weight(1f), tint=accent.copy(alpha=.10f)) {
                        Icon(Icons.Default.MusicNote, null, tint=accent); Text("تيك توك", color=ink)
                    }
                }
            }
        }
        item {
            GlassCard(panel, backdrop) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Translate, null, tint=accent, modifier=Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("لغة الترجمة", color=ink, fontWeight=FontWeight.SemiBold)
                        Text(Prefs.get(activity, "language", "العربية"), color=ink.copy(alpha=.65f), fontSize=13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryPage(ink: Color, panel: Color, backdrop: LayerBackdrop) {
    GlassCard(panel, backdrop) {
        Icon(Icons.Default.History, null, tint=ink, modifier=Modifier.size(34.dp))
        Spacer(Modifier.height(12.dp))
        Text("الترجمات", color=ink, fontSize=20.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("ستظهر هنا لاحقاً الترجمات المحفوظة. النسخة الحالية تركز على الاختصار والترجمة الفورية.", color=ink.copy(alpha=.7f))
    }
}

@Composable
private fun SettingsPage(
    activity: MainActivity, dark: Boolean, onDark:(Boolean)->Unit,
    accent: String, onAccent:(String)->Unit, icon:String, onIcon:(String)->Unit,
    language:String, onLanguage:(String)->Unit, wallpaper:String, onWallpaper:(String)->Unit,
    tint:Color, ink:Color, panel:Color, backdrop: LayerBackdrop
) {
    var showLang by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var round by remember { mutableStateOf(Prefs.bool(activity,"round",true)) }
    var position by remember { mutableStateOf(Prefs.get(activity,"position","يمين")) }
    var shortcutColor by remember { mutableStateOf(Prefs.get(activity,"shortcutColor","#7C8CFF")) }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=12.dp)) {
        item { GlassCard(panel, backdrop) {
            Text("المظهر والتخصيص", color=ink, fontSize=19.sp, fontWeight=FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("الوضع الداكن", color=ink); Text("تغيير مظهر التطبيق", color=ink.copy(alpha=.6f), fontSize=12.sp) }
                LiquidToggle(
                    selected = { dark },
                    onSelect = onDark,
                    backdrop = backdrop,
                    modifier = Modifier.width(64.dp)
                )
            }
            Text("لون الأزرار", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.padding(vertical=10.dp)) {
                accentOptions.forEach { (name, hex) ->
                    Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.clickable { onAccent(hex) }) {
                        Box(
                            Modifier.size(34.dp).drawBackdrop(
                                backdrop = backdrop,
                                shape = { CircleShape },
                                effects = { vibrancy(); blur(3.dp.toPx()); lens(7.dp.toPx(), 9.dp.toPx()) },
                                onDrawSurface = { drawRect(Color(android.graphics.Color.parseColor(hex))) }
                            ),
                            contentAlignment=Alignment.Center
                        ) {
                            if (accent==hex) Icon(Icons.Default.Check, null, tint=Color.White)
                        }
                        Text(name, color=ink.copy(alpha=.75f), fontSize=10.sp)
                    }
                }
            }
            Text("أيقونة التطبيق", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(vertical=8.dp)) {
                iconOptions.forEach { opt ->
                    Box(
                        Modifier.size(43.dp).drawBackdrop(
                            backdrop = backdrop,
                            shape = { RoundedCornerShape(14.dp) },
                            effects = { vibrancy(); blur(5.dp.toPx()); lens(8.dp.toPx(), 12.dp.toPx()) },
                            onDrawSurface = { drawRect(if(icon==opt) tint.copy(alpha=.24f) else panel.copy(alpha=.38f)) }
                        ).clickable { onIcon(opt) },
                        contentAlignment=Alignment.Center
                    ) { Icon(iconVector(opt), null, tint=if(icon==opt) tint else ink, modifier=Modifier.size(22.dp)) }
                }
            }
            Text("خلفية التطبيق", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(top=8.dp)) {
                listOf("Aurora","Ocean","Rose","Sunset").forEach { w ->
                    LiquidButton(
                        onClick = { onWallpaper(w) },
                        backdrop = backdrop,
                        tint = if (wallpaper == w) tint.copy(alpha=.22f) else Color.Unspecified
                    ) { Text(w, color=ink, fontSize=12.sp) }
                }
            }
        } }
        item { GlassCard(panel, backdrop) {
            Text("الترجمة", color=ink, fontSize=18.sp, fontWeight=FontWeight.Bold)
            Row(Modifier.fillMaxWidth().clickable { showLang=true }.padding(vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Language, null, tint=tint); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text("لغة الترجمة", color=ink); Text(language, color=ink.copy(alpha=.65f), fontSize=12.sp) }
                Icon(Icons.Default.ChevronRight, null, tint=ink)
            }
        } }
        item { GlassCard(panel, backdrop) {
            Text("اختصار لقطة الشاشة", color=ink, fontSize=18.sp, fontWeight=FontWeight.Bold)
            Text("تخصيص شكل الزر العائم الذي يظهر بعد التقاط الشاشة.", color=ink.copy(alpha=.65f), fontSize=12.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("حواف دائرية", color=ink); Text("إيقافها يجعل الاختصار مربعاً", color=ink.copy(alpha=.6f), fontSize=11.sp) }
                LiquidToggle(
                    selected = { round },
                    onSelect = { round=it; Prefs.setBool(activity,"round",it) },
                    backdrop = backdrop,
                    modifier = Modifier.width(64.dp)
                )
            }
            Text("لون الاختصار", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp), modifier=Modifier.padding(vertical=8.dp)) {
                accentOptions.forEach { (_, hex) ->
                    Box(
                        Modifier.size(30.dp).drawBackdrop(
                            backdrop = backdrop,
                            shape = { CircleShape },
                            effects = { vibrancy(); blur(3.dp.toPx()); lens(7.dp.toPx(), 9.dp.toPx()) },
                            onDrawSurface = { drawRect(Color(android.graphics.Color.parseColor(hex))) }
                        ).clickable { shortcutColor=hex; Prefs.set(activity,"shortcutColor",hex) },
                        contentAlignment=Alignment.Center
                    ) {
                        if(shortcutColor==hex) Icon(Icons.Default.Check, null, tint=Color.White, modifier=Modifier.size(17.dp))
                    }
                }
            }
            Text("مكان الاختصار", color=ink, fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("يمين","يسار").forEach { p ->
                    LiquidButton(
                        onClick = { position=p; Prefs.set(activity,"position",p) },
                        backdrop = backdrop,
                        tint = if (position == p) tint.copy(alpha=.22f) else Color.Unspecified
                    ) { Text(p, color=ink, fontSize=12.sp) }
                }
            }
            Text("أيقونة الاختصار", color=ink, fontWeight=FontWeight.SemiBold, modifier=Modifier.padding(top=8.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                iconOptions.forEach { opt -> Box(
                    Modifier.size(40.dp).drawBackdrop(
                        backdrop = backdrop,
                        shape = { RoundedCornerShape(12.dp) },
                        effects = { vibrancy(); blur(5.dp.toPx()); lens(8.dp.toPx(), 12.dp.toPx()) },
                        onDrawSurface = { drawRect(if(Prefs.get(activity,"shortcutIcon","translate")==opt) tint.copy(alpha=.24f) else panel.copy(alpha=.38f)) }
                    ).clickable { Prefs.set(activity,"shortcutIcon",opt) },
                    contentAlignment=Alignment.Center
                ) { Icon(iconVector(opt), null, tint=if(Prefs.get(activity,"shortcutIcon","translate")==opt) tint else ink, modifier=Modifier.size(20.dp)) } }
            }
        } }
        item { GlassCard(panel, backdrop) {
            Row(Modifier.fillMaxWidth().clickable { showAbout=true }, verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint=tint); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text("About — حول التطبيق", color=ink, fontWeight=FontWeight.SemiBold); Text("تعرف على Luma Translate", color=ink.copy(alpha=.6f), fontSize=12.sp) }
                Icon(Icons.Default.ChevronRight, null, tint=ink)
            }
        } }
        item { Text("Luma Translate • الإصدار 1.0.0", color=ink.copy(alpha=.45f), fontSize=11.sp, modifier=Modifier.fillMaxWidth(), textAlign=androidx.compose.ui.text.style.TextAlign.Center) }
    }
    if(showLang) AlertDialog(onDismissRequest={showLang=false}, title={Text("لغة الترجمة")}, text={
        LazyColumn { items(languages.size) { i -> Text(languages[i], modifier=Modifier.fillMaxWidth().clickable { onLanguage(languages[i]); showLang=false }.padding(12.dp)) } }
    }, confirmButton={ TextButton(onClick={showLang=false}) { Text("إغلاق") } })
    if(showAbout) AlertDialog(onDismissRequest={showAbout=false}, title={Text("حول Luma Translate")}, text={
        Text("تطبيق يساعدك على فهم النصوص الأجنبية داخل لقطات الشاشة. يراقب الصور الجديدة أثناء تشغيل خدمة الاختصار، ويستخدم التعرف الضوئي على الحروف ثم الترجمة على الجهاز عند توفر نموذج اللغة. يحتاج صلاحية الصور والظهور فوق التطبيقات. قد تختلف إمكانية العمل بالخلفية حسب إصدار Android والشركة المصنّعة.")
    }, confirmButton={ TextButton(onClick={showAbout=false}) { Text("حسناً") } })
}

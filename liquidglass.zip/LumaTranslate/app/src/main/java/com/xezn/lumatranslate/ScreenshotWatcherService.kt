package com.xezn.lumatranslate

import android.app.*
import android.content.*
import android.database.ContentObserver
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.ImageView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class ScreenshotWatcherService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var lastSeen = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            super.onChange(selfChange, uri)
            handler.postDelayed({ checkLatestScreenshot() }, 900)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "watcher")
            .setContentTitle("Luma Translate")
            .setContentText("اختصار الترجمة جاهز عند التقاط لقطة شاشة")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build() else Notification()
        startForeground(10, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
    }

    private fun checkLatestScreenshot() {
        try {
            val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DISPLAY_NAME)
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                if (c.moveToFirst()) {
                    val id = c.getLong(0)
                    val date = c.getLong(1)
                    val name = c.getString(2) ?: ""
                    if (date > lastSeen && (name.contains("screenshot", true) || name.contains("screen_shot", true) || name.contains("لقطة", true))) {
                        lastSeen = date
                        val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                        Prefs.set(this, "latestUri", uri.toString())
                        showBubble()
                    }
                }
            }
        } catch (_: SecurityException) { }
    }

    private fun showBubble() {
        if (!SettingsCanOverlay()) return
        handler.post {
            try {
                bubble?.let { wm.removeView(it) }
                val bgColor = try { Color.parseColor(Prefs.get(this, "shortcutColor", "#7C8CFF")) } catch (_: Exception) { 0xFF7C8CFF.toInt() }
                val view = TextView(this).apply {
                    text = "ترجمة"
                    textSize = 14f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(20, 12, 20, 12)
                    background = GradientDrawable().apply {
                        setColor(bgColor)
                        cornerRadius = if (Prefs.bool(this@ScreenshotWatcherService, "round", true)) 100f else 12f
                    }
                    val iconRes = when (Prefs.get(this@ScreenshotWatcherService, "shortcutIcon", "translate")) {
                        "language" -> android.R.drawable.ic_menu_set_as
                        "text" -> android.R.drawable.ic_menu_edit
                        "auto_awesome" -> android.R.drawable.ic_menu_view
                        "chat" -> android.R.drawable.ic_dialog_email
                        "bolt" -> android.R.drawable.ic_menu_manage
                        else -> android.R.drawable.ic_menu_search
                    }
                    setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0)
                    compoundDrawablePadding = 8
                    elevation = 12f
                    setOnClickListener {
                        try { handler.removeCallbacksAndMessages("bubble_hide"); wm.removeView(this); bubble = null } catch (_: Exception) { }
                        val intent = Intent(this@ScreenshotWatcherService, TranslateActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            .putExtra("image_uri", Prefs.get(this@ScreenshotWatcherService, "latestUri", ""))
                        startActivity(intent)
                    }
                }
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or if (Prefs.get(this@ScreenshotWatcherService, "position", "يمين") == "يسار") Gravity.LEFT else Gravity.RIGHT
                    x = 14; y = 220
                }
                wm.addView(view, params)
                bubble = view
                handler.removeCallbacksAndMessages("bubble_hide")
                handler.postAtTime({
                    try {
                        bubble?.let { wm.removeView(it) }
                        bubble = null
                    } catch (_: Exception) { }
                }, "bubble_hide", SystemClock.uptimeMillis() + 6000L)
            } catch (_: Exception) { }
        }
    }

    private fun SettingsCanOverlay() = android.provider.Settings.canDrawOverlays(this)
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("watcher", "Screenshot translator", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        try { handler.removeCallbacksAndMessages("bubble_hide"); contentResolver.unregisterContentObserver(observer); bubble?.let { wm.removeView(it) } } catch (_: Exception) { }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}

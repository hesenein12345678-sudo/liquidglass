package com.xezn.lumatranslate

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.languageid.LanguageIdentification

class TranslateActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.getStringExtra("image_uri").orEmpty()
        setContent {
            var original by remember { mutableStateOf("جارٍ قراءة النص من الصورة…") }
            var translated by remember { mutableStateOf("") }
            var status by remember { mutableStateOf("يتم تحليل الصورة") }
            LaunchedEffect(uri) {
                try {
                    val image = InputImage.fromFilePath(this@TranslateActivity, Uri.parse(uri))
                    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                        .addOnSuccessListener { result ->
                            original = result.text.ifBlank { "لم أتمكن من العثور على نص واضح في لقطة الشاشة." }
                            if (result.text.isBlank()) status = "جرّب لقطة شاشة أوضح"
                            else translateText(result.text, { translated = it; status = "اكتملت الترجمة" }, { status = it })
                        }
                        .addOnFailureListener { original = "تعذر قراءة الصورة."; status = "حدث خطأ أثناء قراءة النص" }
                } catch (e: Exception) {
                    original = "تعذر فتح لقطة الشاشة. تأكد من منح إذن الصور."; status = e.localizedMessage ?: "خطأ"
                }
            }
            val dark = Prefs.bool(this, "dark", true)
            val bg = if(dark) Color(0xFF0B1020) else Color(0xFFF3F5FC)
            val ink = if(dark) Color(0xFFF4F5FF) else Color(0xFF172039)
            MaterialTheme {
                Column(Modifier.fillMaxSize().background(bg).padding(18.dp)) {
                    TextButton(onClick={ finish() }) { Text("← رجوع") }
                    Text("ترجمة لقطة الشاشة", color=ink, style=MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    Text(status, color=ink.copy(alpha=.65f))
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).background(ink.copy(alpha=.06f), RoundedCornerShape(22.dp)).padding(16.dp)) {
                        Text("النص الأصلي", color=ink.copy(alpha=.6f), style=MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(8.dp)); Text(original, color=ink)
                        Spacer(Modifier.height(22.dp))
                        Text("الترجمة", color=ink.copy(alpha=.6f), style=MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(8.dp)); Text(translated.ifBlank { "ستظهر الترجمة هنا…" }, color=ink)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick={ if(translated.isNotBlank()) { val clipboard=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager; clipboard.setPrimaryClip(android.content.ClipData.newPlainText("translation", translated)) } }, modifier=Modifier.fillMaxWidth()) { Text("نسخ الترجمة") }
                }
            }
        }
    }

    private fun translateText(text: String, onSuccess:(String)->Unit, onStatus:(String)->Unit) {
        val languageName = Prefs.get(this, "language", "العربية")
        val target = when(languageName) {
            "العربية" -> TranslateLanguage.ARABIC
            "English" -> TranslateLanguage.ENGLISH
            "فارسی" -> TranslateLanguage.PERSIAN
            "Türkçe" -> TranslateLanguage.TURKISH
            "Français" -> TranslateLanguage.FRENCH
            "Español" -> TranslateLanguage.SPANISH
            "Deutsch" -> TranslateLanguage.GERMAN
            "日本語" -> TranslateLanguage.JAPANESE
            "한국어" -> TranslateLanguage.KOREAN
            "中文" -> TranslateLanguage.CHINESE
            else -> TranslateLanguage.ARABIC
        }
        onStatus("يتم تحديد لغة النص…")
        LanguageIdentification.getClient().identifyLanguage(text)
            .addOnSuccessListener { detected ->
                val source = when (detected) {
                    "ar" -> TranslateLanguage.ARABIC
                    "en" -> TranslateLanguage.ENGLISH
                    "fa" -> TranslateLanguage.PERSIAN
                    "tr" -> TranslateLanguage.TURKISH
                    "fr" -> TranslateLanguage.FRENCH
                    "es" -> TranslateLanguage.SPANISH
                    "de" -> TranslateLanguage.GERMAN
                    "ja" -> TranslateLanguage.JAPANESE
                    "ko" -> TranslateLanguage.KOREAN
                    "zh" -> TranslateLanguage.CHINESE
                    "ru" -> TranslateLanguage.RUSSIAN
                    "it" -> TranslateLanguage.ITALIAN
                    "pt" -> TranslateLanguage.PORTUGUESE
                    "hi" -> TranslateLanguage.HINDI
                    else -> TranslateLanguage.ENGLISH
                }
                if (source == target) {
                    onSuccess(text)
                    onStatus("النص بالفعل باللغة المختارة")
                    return@addOnSuccessListener
                }
                val options = TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
                val translator = Translation.getClient(options)
                onStatus("يتم تجهيز نموذج الترجمة…")
                translator.downloadModelIfNeeded().addOnSuccessListener {
                    onStatus("تتم الترجمة…")
                    translator.translate(text).addOnSuccessListener {
                        onSuccess(it)
                        translator.close()
                    }.addOnFailureListener {
                        onStatus("تعذرت الترجمة. قد لا تكون هذه اللغة مدعومة.")
                        translator.close()
                    }
                }.addOnFailureListener {
                    onStatus("تعذر تنزيل نموذج اللغة. تحقق من الإنترنت.")
                    translator.close()
                }
            }
            .addOnFailureListener { onStatus("تعذر تحديد لغة النص تلقائياً.") }
    }
}

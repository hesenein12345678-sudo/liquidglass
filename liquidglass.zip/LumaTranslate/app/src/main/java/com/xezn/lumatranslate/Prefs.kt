package com.xezn.lumatranslate

import android.content.Context

object Prefs {
    private const val FILE = "luma_prefs"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean = false) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
}

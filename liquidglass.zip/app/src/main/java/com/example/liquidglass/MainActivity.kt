package com.example.liquidglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LiquidGlassScreen() }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Home", Icons.Filled.Home),
    TabItem("Search", Icons.Filled.Search),
    TabItem("Likes", Icons.Filled.Favorite),
    TabItem("Profile", Icons.Filled.Person),
)

@Composable
fun LiquidGlassScreen() {
    // الـ backdrop هو الطبقة اللي الزجاج "يشوفها" ويكسر الضوء عليها
    val backdrop = rememberLayerBackdrop()
    var selected by remember { mutableIntStateOf(0) }

    Box(Modifier.fillMaxSize()) {

        // 1) خلفية الواجهة (هذي اللي تنلتقط). لازم تكون فيها ألوان حتى يبين التأثير
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
        ) {
            ColorfulBackground()
        }

        // 2) الشريط السفلي - خارج layerBackdrop حتى ما يلتقط نفسه
        LiquidBottomBar(
            backdrop = backdrop,
            selected = selected,
            onSelect = { selected = it },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun ColorfulBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(
                listOf(Color(0xFF1B1464), Color(0xFF6A11CB), Color(0xFFFF5F6D))
            )
        )
        drawCircle(Color(0xFF00E5FF), size.width * 0.35f, Offset(size.width * 0.20f, size.height * 0.25f))
        drawCircle(Color(0xFFFFD54F), size.width * 0.30f, Offset(size.width * 0.85f, size.height * 0.55f))
        drawCircle(Color(0xFF69F0AE), size.width * 0.25f, Offset(size.width * 0.40f, size.height * 0.88f))
        drawCircle(Color(0xFFFF4081), size.width * 0.18f, Offset(size.width * 0.10f, size.height * 0.78f))
    }
}

@Composable
private fun LiquidBottomBar(
    backdrop: com.kyant.backdrop.Backdrop,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .fillMaxWidth()
            .height(68.dp)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { CircleShape },
                effects = {
                    vibrancy()                              // ألوان أحلى (Android 13+)
                    blur(4.dp.toPx())                       // blur خفيف
                    lens(16.dp.toPx(), 32.dp.toPx())        // الانكسار الحقيقي عند الحواف (Android 13+)
                },
                onDrawSurface = {
                    drawRect(Color.White.copy(alpha = 0.10f)) // طبقة تint خفيفة
                }
            )
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEachIndexed { index, tab ->
            val isSelected = index == selected
            Column(
                Modifier
                    .weight(1f)
                    .height(52.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) Color.White.copy(alpha = 0.22f) else Color.Transparent
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onSelect(index) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = tab.icon,
                    contentDescription = tab.label,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Text(tab.label, color = Color.White, fontSize = 11.sp)
            }
        }
    }
}

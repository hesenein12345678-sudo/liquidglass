package com.xezn.shottranslate.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.xezn.shottranslate.ui.BodyText
import com.xezn.shottranslate.ui.GlassCard
import com.xezn.shottranslate.ui.Heading
import com.xezn.shottranslate.ui.components.LiquidButton
import com.xezn.shottranslate.ui.secondaryColor

private const val TELEGRAM_URL = "https://t.me/xezn9"
private const val TIKTOK_URL = "https://www.tiktok.com/@xezn99"

@Composable
fun LinksScreen(backdrop: Backdrop, bottomInset: Dp) {
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20f.dp)
            .padding(top = 16f.dp, bottom = bottomInset),
        verticalArrangement = Arrangement.spacedBy(16f.dp)
    ) {
        Heading("حساباتي")
        BodyText("تابعني أو تواصل معي من هنا:", secondaryColor())

        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            LiquidButton(
                onClick = { openLink(context, TELEGRAM_URL) },
                backdrop = backdrop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56f.dp),
                tint = Color(0xFF2AABEE)
            ) {
                BasicText(
                    "Telegram",
                    style = TextStyle(Color.White, 18f.sp, FontWeight.SemiBold)
                )
            }
            BodyText("@xezn9", secondaryColor())

            LiquidButton(
                onClick = { openLink(context, TIKTOK_URL) },
                backdrop = backdrop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56f.dp),
                tint = Color(0xFF1C1C1E)
            ) {
                BasicText(
                    "TikTok",
                    style = TextStyle(Color.White, 18f.sp, FontWeight.SemiBold)
                )
            }
            BodyText("@xezn99", secondaryColor())
        }
    }
}

private fun openLink(context: Context, url: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: ActivityNotFoundException) {
        // No browser or app available to open the link.
    }
}

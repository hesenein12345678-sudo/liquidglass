package com.xezn.shottranslate.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.xezn.shottranslate.ui.components.LiquidBottomTab
import com.xezn.shottranslate.ui.components.LiquidBottomTabs
import com.xezn.shottranslate.ui.screens.HomeScreen
import com.xezn.shottranslate.ui.screens.LinksScreen
import com.xezn.shottranslate.ui.screens.ResultScreen

@Composable
fun App(resumeTick: Int) {
    val color = contentColor()
    val iconColorFilter = ColorFilter.tint(color)

    val homePainter = rememberVectorPainter(HomeIcon)
    val translatePainter = rememberVectorPainter(TranslateIcon)
    val linkPainter = rememberVectorPainter(LinkIcon)
    val painters = listOf(homePainter, translatePainter, linkPainter)
    val labels = listOf("الرئيسية", "الترجمات", "حساباتي")

    // The UI is Arabic, so lay it out right-to-left (LiquidBottomTabs supports RTL).
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val backdrop = rememberLayerBackdrop()
        var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }

        Box(Modifier.fillMaxSize()) {
            GlassBackground(
                Modifier
                    .layerBackdrop(backdrop)
                    .fillMaxSize()
            )

            // Room for the floating tab bar: nav bar + 64dp bar + 16dp gap + breathing space.
            val navBarHeight = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            val bottomInset = navBarHeight + 64f.dp + 16f.dp + 24f.dp

            Box(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                when (selectedTabIndex) {
                    0 -> HomeScreen(backdrop, resumeTick, bottomInset)
                    1 -> ResultScreen(backdrop, bottomInset)
                    else -> LinksScreen(backdrop, bottomInset)
                }
            }

            // Same bottom tabs as the Backdrop catalog app.
            LiquidBottomTabs(
                selectedTabIndex = { selectedTabIndex },
                onTabSelected = { selectedTabIndex = it },
                backdrop = backdrop,
                tabsCount = 3,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(horizontal = 36f.dp)
                    .padding(bottom = 16f.dp)
            ) {
                repeat(3) { index ->
                    LiquidBottomTab({ selectedTabIndex = index }) {
                        Box(
                            Modifier
                                .size(28f.dp)
                                .paint(painters[index], colorFilter = iconColorFilter)
                        )
                        BasicText(
                            labels[index],
                            style = TextStyle(color, 12f.sp)
                        )
                    }
                }
            }
        }
    }
}

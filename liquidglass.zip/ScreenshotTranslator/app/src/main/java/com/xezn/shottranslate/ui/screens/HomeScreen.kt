package com.xezn.shottranslate.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.xezn.shottranslate.data.Prefs
import com.xezn.shottranslate.data.TargetLanguages
import com.xezn.shottranslate.service.ScreenshotService
import com.xezn.shottranslate.ui.BodyText
import com.xezn.shottranslate.ui.GlassCard
import com.xezn.shottranslate.ui.Heading
import com.xezn.shottranslate.ui.Permissions
import com.xezn.shottranslate.ui.SectionTitle
import com.xezn.shottranslate.ui.components.LiquidButton
import com.xezn.shottranslate.ui.contentColor
import com.xezn.shottranslate.ui.secondaryColor

private val Blue = Color(0xFF0088FF)
private val Red = Color(0xFFFF3B30)
private val Green = Color(0xFF34C759)

@Composable
fun HomeScreen(backdrop: Backdrop, resumeTick: Int, bottomInset: Dp) {
    val context = LocalContext.current

    var refresh by remember { mutableIntStateOf(0) }
    var enabled by remember { mutableStateOf(Prefs.isEnabled(context)) }
    var startAfterGrant by remember { mutableStateOf(false) }

    val hasMedia = remember(resumeTick, refresh) { Permissions.hasMedia(context) }
    val hasNotifications = remember(resumeTick, refresh) { Permissions.hasNotifications(context) }
    val hasOverlay = remember(resumeTick, refresh) { Permissions.hasOverlay(context) }
    val target by Prefs.target.collectAsState()

    fun startService() {
        Prefs.setEnabled(context, true)
        enabled = true
        ScreenshotService.start(context)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refresh++
        if (startAfterGrant && Permissions.hasMedia(context)) startService()
        startAfterGrant = false
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20f.dp)
            .padding(top = 16f.dp, bottom = bottomInset),
        verticalArrangement = Arrangement.spacedBy(16f.dp)
    ) {
        Heading("مترجم اللقطات")
        BodyText(
            "خذ لقطة شاشة لأي نص، وسيظهر لك زر «ترجمة» تلقائياً. " +
                    "يتعرف التطبيق على النص ويترجمه مباشرة على جهازك.",
            secondaryColor()
        )

        // ---- Main switch ---------------------------------------------------
        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            SectionTitle(if (enabled) "المترجم يعمل ✓" else "المترجم متوقف")
            BodyText(
                if (enabled) "بانتظار لقطة الشاشة القادمة…"
                else "شغّل المترجم ليراقب لقطات الشاشة في الخلفية.",
                secondaryColor()
            )
            LiquidButton(
                onClick = {
                    if (enabled) {
                        Prefs.setEnabled(context, false)
                        enabled = false
                        ScreenshotService.stop(context)
                    } else if (!Permissions.hasMedia(context)) {
                        startAfterGrant = true
                        permissionLauncher.launch(Permissions.runtimePermissions())
                    } else {
                        startService()
                    }
                },
                backdrop = backdrop,
                modifier = Modifier.fillMaxWidth(),
                tint = if (enabled) Red else Blue
            ) {
                BasicText(
                    if (enabled) "إيقاف المترجم" else "تشغيل المترجم",
                    style = TextStyle(Color.White, 17f.sp, FontWeight.SemiBold)
                )
            }
        }

        // ---- Permissions ---------------------------------------------------
        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            SectionTitle("الأذونات")
            PermissionRow(
                label = "الوصول إلى الصور (لقراءة اللقطة)",
                granted = hasMedia,
                backdrop = backdrop
            ) {
                permissionLauncher.launch(Permissions.runtimePermissions())
            }
            PermissionRow(
                label = "الإشعارات",
                granted = hasNotifications,
                backdrop = backdrop
            ) {
                permissionLauncher.launch(Permissions.notificationPermissions())
            }
            PermissionRow(
                label = "الظهور فوق التطبيقات (لزر الترجمة العائم)",
                granted = hasOverlay,
                backdrop = backdrop
            ) {
                context.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            BodyText(
                "بدون إذن «الظهور فوق التطبيقات» سيظهر إشعار فيه زر ترجمة بدل الزر العائم.",
                secondaryColor()
            )
        }

        // ---- Target language ----------------------------------------------
        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            SectionTitle("الترجمة إلى")
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8f.dp)
            ) {
                TargetLanguages.forEach { language ->
                    val selected = language.code == target
                    LiquidButton(
                        onClick = { Prefs.setTargetLang(context, language.code) },
                        backdrop = backdrop,
                        tint = if (selected) Blue else Color.Unspecified
                    ) {
                        BasicText(
                            language.label,
                            style = TextStyle(
                                if (selected) Color.White else contentColor(),
                                15f.sp
                            )
                        )
                    }
                }
            }
            BodyText(
                "أول مرة تستخدم فيها لغة يحتاج التطبيق إنترنت لتنزيل نموذج الترجمة (مرة واحدة فقط).",
                secondaryColor()
            )
        }

        // ---- Reliability tip ----------------------------------------------
        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            SectionTitle("لضمان عمله دائماً")
            BodyText(
                "بعض الأجهزة توقف التطبيقات في الخلفية. اسمح للتطبيق بالعمل بدون قيود البطارية.",
                secondaryColor()
            )
            LiquidButton(
                onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                backdrop = backdrop,
                modifier = Modifier.fillMaxWidth()
            ) {
                BasicText("إعدادات البطارية", style = TextStyle(contentColor(), 16f.sp))
            }
        }

        Spacer(Modifier.height(8f.dp))
    }
}

@Composable
private fun PermissionRow(
    label: String,
    granted: Boolean,
    backdrop: Backdrop,
    onGrant: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12f.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            BodyText(label)
        }
        if (granted) {
            BasicText("مفعّل ✓", style = TextStyle(Green, 15f.sp, FontWeight.SemiBold))
        } else {
            LiquidButton(onClick = onGrant, backdrop = backdrop, tint = Blue) {
                BasicText("منح", style = TextStyle(Color.White, 15f.sp, FontWeight.SemiBold))
            }
        }
    }
}

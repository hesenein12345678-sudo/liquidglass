package com.xezn.shottranslate.data

import com.google.mlkit.nl.translate.TranslateLanguage

/** Target languages offered in the UI (all supported by ML Kit on-device translation). */
data class TargetLanguage(val code: String, val label: String)

val TargetLanguages: List<TargetLanguage> = listOf(
    TargetLanguage(TranslateLanguage.ARABIC, "العربية"),
    TargetLanguage(TranslateLanguage.ENGLISH, "English"),
    TargetLanguage(TranslateLanguage.TURKISH, "Türkçe"),
    TargetLanguage(TranslateLanguage.PERSIAN, "فارسی"),
    TargetLanguage(TranslateLanguage.URDU, "اردو"),
    TargetLanguage(TranslateLanguage.FRENCH, "Français"),
    TargetLanguage(TranslateLanguage.GERMAN, "Deutsch"),
    TargetLanguage(TranslateLanguage.SPANISH, "Español"),
    TargetLanguage(TranslateLanguage.RUSSIAN, "Русский"),
)

fun languageLabel(code: String): String =
    TargetLanguages.firstOrNull { it.code == code }?.label ?: code

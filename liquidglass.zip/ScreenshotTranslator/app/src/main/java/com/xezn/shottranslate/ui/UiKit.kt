package com.xezn.shottranslate.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.shapes.RoundedRectangle

@Composable
fun contentColor(): Color = if (isSystemInDarkTheme()) Color.White else Color.Black

@Composable
fun secondaryColor(): Color = contentColor().copy(alpha = 0.6f)

/** Colourful backdrop so the liquid glass has something to refract. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier) {
    val light = !isSystemInDarkTheme()
    Canvas(modifier) {
        drawRect(
            Brush.verticalGradient(
                if (light) listOf(Color(0xFFEAF3FF), Color(0xFFF6ECFF))
                else listOf(Color(0xFF0A0F1F), Color(0xFF1B1235))
            )
        )

        fun blob(cx: Float, cy: Float, radius: Float, color: Color) {
            val center = Offset(cx, cy)
            drawCircle(
                brush = Brush.radialGradient(listOf(color, Color.Transparent), center, radius),
                radius = radius,
                center = center
            )
        }

        val w = size.width
        val h = size.height
        val strength = if (light) 0.55f else 0.5f
        blob(w * 0.10f, h * 0.10f, w * 0.80f, Color(0xFF0088FF).copy(alpha = strength))
        blob(w * 0.95f, h * 0.35f, w * 0.70f, Color(0xFFB04DFF).copy(alpha = strength))
        blob(w * 0.20f, h * 0.65f, w * 0.75f, Color(0xFF00D4B8).copy(alpha = strength * 0.9f))
        blob(w * 0.90f, h * 0.92f, w * 0.80f, Color(0xFFFF7A59).copy(alpha = strength * 0.8f))
    }
}

/** A large liquid-glass panel (same effect stack as the catalog's dialog/tab bar). */
@Composable
fun GlassCard(
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val container =
        if (isSystemInDarkTheme()) Color(0xFF121212).copy(alpha = 0.4f)
        else Color(0xFFFAFAFA).copy(alpha = 0.4f)

    Column(
        modifier
            .drawBackdrop(
                backdrop = backdrop,
                shape = { RoundedRectangle(32f.dp) },
                effects = {
                    vibrancy()
                    blur(12f.dp.toPx())
                    lens(16f.dp.toPx(), 32f.dp.toPx())
                },
                onDrawSurface = { drawRect(container) }
            )
            .padding(20f.dp),
        verticalArrangement = Arrangement.spacedBy(14f.dp),
        content = content
    )
}

@Composable
fun Heading(text: String) {
    BasicText(text, style = TextStyle(contentColor(), 28f.sp, FontWeight.Bold))
}

@Composable
fun SectionTitle(text: String) {
    BasicText(text, style = TextStyle(contentColor(), 18f.sp, FontWeight.SemiBold))
}

@Composable
fun BodyText(text: String, color: Color = contentColor()) {
    BasicText(text, style = TextStyle(color, 15f.sp, lineHeight = 22f.sp))
}

package com.xezn.shottranslate.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.xezn.shottranslate.MainActivity
import com.xezn.shottranslate.R
import com.xezn.shottranslate.data.Prefs
import com.xezn.shottranslate.data.TranslationRecord
import com.xezn.shottranslate.data.languageLabel
import com.xezn.shottranslate.ocr.NoTextFoundException
import com.xezn.shottranslate.ocr.TranslationPipeline
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service that watches MediaStore for new screenshots.
 * When one appears it shows a floating "ترجمة" shortcut (or a notification action when the
 * overlay permission is missing). Nothing is shown unless a screenshot was just taken.
 */
class ScreenshotService : Service() {

    companion object {
        private const val CHANNEL_ONGOING = "ongoing"
        private const val CHANNEL_ALERT = "alerts"
        private const val NOTIFICATION_ONGOING = 1
        private const val NOTIFICATION_RESULT = 2

        const val ACTION_TRANSLATE = "com.xezn.shottranslate.action.TRANSLATE"
        const val EXTRA_URI = "uri"

        private val SCREENSHOT_KEYWORDS = listOf(
            "screenshot", "screen_shot", "screen shot", "screencap",
            "لقطة", "截屏", "截图", "屏幕截图", "스크린샷", "スクリーンショット"
        )

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context, Intent(context, ScreenshotService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenshotService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var overlay: OverlayManager

    private var observer: ContentObserver? = null
    private val handledIds = LinkedHashSet<Long>()
    private val checkRunnable = Runnable { checkForNewScreenshot() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.load(this)
        overlay = OverlayManager(applicationContext)
        createChannels()

        val notification = buildOngoingNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ONGOING, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ONGOING, notification)
        }

        val obs = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                scheduleCheck()
            }

            override fun onChange(selfChange: Boolean, uri: Uri?) {
                scheduleCheck()
            }
        }
        contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs
        )
        observer = obs
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TRANSLATE) {
            intent.getStringExtra(EXTRA_URI)?.let { translate(Uri.parse(it)) }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        observer?.let { contentResolver.unregisterContentObserver(it) }
        handler.removeCallbacksAndMessages(null)
        overlay.removeAll()
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- detection

    /** MediaStore fires several change events per screenshot, so debounce them. */
    private fun scheduleCheck() {
        handler.removeCallbacks(checkRunnable)
        handler.postDelayed(checkRunnable, 700L)
    }

    private fun checkForNewScreenshot() {
        val projection = buildList {
            add(MediaStore.Images.Media._ID)
            add(MediaStore.Images.Media.DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= 29) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            } else {
                @Suppress("DEPRECATION")
                add(MediaStore.Images.Media.DATA)
            }
        }.toTypedArray()

        val since = System.currentTimeMillis() / 1000L - 20L
        val cursor = try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Images.Media.DATE_ADDED} >= ?",
                arrayOf(since.toString()),
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )
        } catch (_: SecurityException) {
            null // media permission was revoked
        } ?: return

        var found: Uri? = null
        cursor.use { c ->
            var rows = 0
            while (c.moveToNext() && rows++ < 10) {
                val id = c.getLong(0)
                if (id in handledIds) continue
                val name = c.getString(1).orEmpty()
                val path = c.getString(2).orEmpty()
                if (looksLikeScreenshot(name, path)) {
                    handledIds += id
                    while (handledIds.size > 50) handledIds.remove(handledIds.first())
                    found = Uri.withAppendedPath(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString()
                    )
                    break
                }
            }
        }
        found?.let { onScreenshotDetected(it) }
    }

    private fun looksLikeScreenshot(name: String, path: String): Boolean {
        val haystack = "$path/$name".lowercase()
        return SCREENSHOT_KEYWORDS.any { haystack.contains(it) }
    }

    private fun onScreenshotDetected(uri: Uri) {
        if (overlay.canShow()) {
            overlay.showTranslateButton { translate(uri) }
        } else {
            postTranslateNotification(uri)
        }
    }

    // -------------------------------------------------------------- translation

    private fun translate(uri: Uri) {
        val target = Prefs.targetLang(this)
        if (overlay.canShow()) overlay.showStatus("جاري الترجمة…")

        scope.launch {
            try {
                val record = TranslationPipeline.run(applicationContext, uri, target)
                Prefs.addRecord(applicationContext, record)
                overlay.hideStatus()
                if (overlay.canShow()) overlay.showResult(record) else postResultNotification(record)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                overlay.hideStatus()
                val message = when (e) {
                    is NoTextFoundException -> e.message.orEmpty()
                    else -> "حدث خطأ أثناء الترجمة: ${e.localizedMessage ?: e.javaClass.simpleName}\n\n" +
                            "ملاحظة: أول مرة لكل لغة يحتاج التطبيق إنترنت لتنزيل نموذج الترجمة (مرة واحدة فقط)."
                }
                if (overlay.canShow()) overlay.showError(message) else postErrorNotification(message)
            }
        }
    }

    // ------------------------------------------------------------ notifications

    private fun createChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ONGOING, "مراقبة اللقطات", NotificationManager.IMPORTANCE_LOW
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ALERT, "ترجمة اللقطات", NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildOngoingNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ONGOING)
            .setSmallIcon(R.drawable.ic_stat_translate)
            .setContentTitle("مترجم اللقطات يعمل")
            .setContentText("خذ لقطة شاشة وسيظهر زر الترجمة")
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun postTranslateNotification(uri: Uri) {
        val translateIntent = PendingIntent.getService(
            this, uri.hashCode(),
            Intent(this, ScreenshotService::class.java)
                .setAction(ACTION_TRANSLATE)
                .putExtra(EXTRA_URI, uri.toString()),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_stat_translate)
            .setContentTitle("لقطة شاشة جديدة")
            .setContentText("اضغط لترجمة النص الموجود فيها")
            .setAutoCancel(true)
            .setTimeoutAfter(15_000L)
            .setContentIntent(translateIntent)
            .addAction(0, "ترجمة", translateIntent)
            .build()
        notify(NOTIFICATION_RESULT, notification)
    }

    private fun postResultNotification(record: TranslationRecord) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_stat_translate)
            .setContentTitle("${languageLabel(record.sourceLang)} ← ${languageLabel(record.targetLang)}")
            .setContentText(record.translated.lineSequence().firstOrNull().orEmpty())
            .setStyle(NotificationCompat.BigTextStyle().bigText(record.translated))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        notify(NOTIFICATION_RESULT, notification)
    }

    private fun postErrorNotification(message: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_stat_translate)
            .setContentTitle("تعذرت الترجمة")
            .setContentText(message.lineSequence().firstOrNull().orEmpty())
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        notify(NOTIFICATION_RESULT, notification)
    }

    private fun notify(id: Int, notification: Notification) {
        try {
            getSystemService(NotificationManager::class.java).notify(id, notification)
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted
        }
    }
}

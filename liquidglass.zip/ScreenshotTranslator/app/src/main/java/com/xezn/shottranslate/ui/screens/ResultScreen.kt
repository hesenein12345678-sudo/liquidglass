package com.xezn.shottranslate.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.xezn.shottranslate.data.Prefs
import com.xezn.shottranslate.data.TranslationRecord
import com.xezn.shottranslate.data.languageLabel
import com.xezn.shottranslate.ui.BodyText
import com.xezn.shottranslate.ui.GlassCard
import com.xezn.shottranslate.ui.Heading
import com.xezn.shottranslate.ui.components.LiquidButton
import com.xezn.shottranslate.ui.contentColor
import com.xezn.shottranslate.ui.secondaryColor
import java.text.DateFormat
import java.util.Date

@Composable
fun ResultScreen(backdrop: Backdrop, bottomInset: Dp) {
    val context = LocalContext.current
    val history by Prefs.history.collectAsState()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20f.dp, end = 20f.dp, top = 16f.dp, bottom = bottomInset
        ),
        verticalArrangement = Arrangement.spacedBy(16f.dp)
    ) {
        item { Heading("آخر الترجمات") }

        if (history.isEmpty()) {
            item {
                GlassCard(backdrop, Modifier.fillMaxWidth()) {
                    BodyText("لا توجد ترجمات بعد. شغّل المترجم من الرئيسية ثم خذ لقطة شاشة لنص.")
                }
            }
        } else {
            items(history, key = { it.timestamp }) { record ->
                RecordCard(record, backdrop)
            }
            item {
                LiquidButton(
                    onClick = { Prefs.clearHistory(context) },
                    backdrop = backdrop,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicText("مسح السجل", style = TextStyle(contentColor(), 16f.sp))
                }
            }
        }
    }
}

@Composable
private fun RecordCard(record: TranslationRecord, backdrop: Backdrop) {
    val context = LocalContext.current
    var showOriginal by remember { mutableStateOf(false) }
    val text = if (showOriginal) record.original else record.translated

    GlassCard(backdrop, Modifier.fillMaxWidth()) {
        BasicText(
            "${languageLabel(record.sourceLang)}  ←  ${languageLabel(record.targetLang)}",
            style = TextStyle(Color(0xFF0088FF), 14f.sp, FontWeight.SemiBold)
        )
        BodyText(
            DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(Date(record.timestamp)),
            secondaryColor()
        )
        SelectionContainer {
            BasicText(text, style = TextStyle(contentColor(), 17f.sp, lineHeight = 26f.sp))
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10f.dp)
        ) {
            LiquidButton(
                onClick = { copyToClipboard(context, text) },
                backdrop = backdrop,
                tint = Color(0xFF0088FF)
            ) {
                BasicText("نسخ", style = TextStyle(Color.White, 15f.sp, FontWeight.SemiBold))
            }
            LiquidButton(
                onClick = { showOriginal = !showOriginal },
                backdrop = backdrop
            ) {
                BasicText(
                    if (showOriginal) "الترجمة" else "النص الأصلي",
                    style = TextStyle(contentColor(), 15f.sp)
                )
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("translation", text))
    Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show()
}

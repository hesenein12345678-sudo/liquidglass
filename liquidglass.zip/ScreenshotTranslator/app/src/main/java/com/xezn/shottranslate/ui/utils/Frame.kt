package com.xezn.shottranslate.ui.utils

import androidx.compose.runtime.withFrameNanos

/** Replacement for the catalog's expect/actual awaitFrame(): waits for the next Compose frame. */
suspend fun awaitFrame() {
    withFrameNanos { }
}

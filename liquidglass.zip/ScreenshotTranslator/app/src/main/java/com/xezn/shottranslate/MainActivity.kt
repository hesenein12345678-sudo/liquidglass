package com.xezn.shottranslate

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import com.xezn.shottranslate.data.Prefs
import com.xezn.shottranslate.service.ScreenshotService
import com.xezn.shottranslate.ui.App
import com.xezn.shottranslate.ui.Permissions

class MainActivity : ComponentActivity() {

    /** Bumped on every resume so permission states are re-read after the user returns from Settings. */
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val isDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !isDark
            isAppearanceLightNavigationBars = !isDark
        }
        Prefs.load(this)

        // Make sure the watcher is running if the user left it switched on.
        if (Prefs.isEnabled(this) && Permissions.hasMedia(this)) {
            try {
                ScreenshotService.start(this)
            } catch (_: Exception) {
            }
        }

        setContent {
            App(resumeTick)
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

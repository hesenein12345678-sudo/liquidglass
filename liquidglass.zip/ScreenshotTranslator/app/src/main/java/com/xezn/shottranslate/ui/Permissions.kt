package com.xezn.shottranslate.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

object Permissions {

    private fun mediaPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun runtimePermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(mediaPermission(), Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(mediaPermission())
        }

    fun notificationPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()

    fun hasMedia(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, mediaPermission()) == PackageManager.PERMISSION_GRANTED

    fun hasNotifications(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED

    fun hasOverlay(context: Context): Boolean = Settings.canDrawOverlays(context)
}

package com.xezn.shottranslate.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.xezn.shottranslate.data.TranslationRecord
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NoTextFoundException : Exception("لم أجد أي نص في هذه اللقطة")

/**
 * Screenshot -> OCR (on-device, several scripts) -> language detection -> on-device translation.
 */
object TranslationPipeline {

    private const val MAX_SIDE = 3000

    private enum class Script(val fallbackLang: String) {
        LATIN(TranslateLanguage.ENGLISH),
        CHINESE(TranslateLanguage.CHINESE),
        JAPANESE(TranslateLanguage.JAPANESE),
        KOREAN(TranslateLanguage.KOREAN),
        DEVANAGARI(TranslateLanguage.HINDI)
    }

    private class Candidate(val blocks: List<String>, val script: Script) {
        val text: String get() = blocks.joinToString("\n\n")
    }

    suspend fun run(context: Context, uri: Uri, target: String): TranslationRecord =
        withContext(Dispatchers.Default) {
            val bitmap = decode(context, uri) ?: throw IllegalStateException("تعذر قراءة صورة اللقطة")
            try {
                val candidate = recognize(bitmap)
                val original = candidate.text
                if (original.isBlank()) throw NoTextFoundException()

                val source = detectSourceLanguage(original, candidate.script)
                if (source == target) {
                    return@withContext TranslationRecord(
                        original, original, source, target, System.currentTimeMillis()
                    )
                }

                val options = TranslatorOptions.Builder()
                    .setSourceLanguage(source)
                    .setTargetLanguage(target)
                    .build()
                val translator = Translation.getClient(options)
                try {
                    translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                    val translatedBlocks = candidate.blocks.map { block ->
                        translator.translate(block.replace('\n', ' ')).await()
                    }
                    TranslationRecord(
                        original = original,
                        translated = translatedBlocks.joinToString("\n\n"),
                        sourceLang = source,
                        targetLang = target,
                        timestamp = System.currentTimeMillis()
                    )
                } finally {
                    translator.close()
                }
            } finally {
                bitmap.recycle()
            }
        }

    // ---------------------------------------------------------------- decoding

    private fun decode(context: Context, uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    // --------------------------------------------------------------------- OCR

    private suspend fun recognize(bitmap: Bitmap): Candidate {
        val image = InputImage.fromBitmap(bitmap, 0)

        val latin = recognizeWith(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS), image, Script.LATIN
        )
        val letters = letterCount(latin.text)
        if (letters >= 3 && scriptCount(latin.text, Script.LATIN) * 100 / letters >= 70) {
            return latin
        }

        // Not clearly Latin: try the other bundled scripts and keep the best match.
        val others = listOfNotNull(
            safely {
                recognizeWith(
                    TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
                    image, Script.CHINESE
                )
            },
            safely {
                recognizeWith(
                    TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
                    image, Script.JAPANESE
                )
            },
            safely {
                recognizeWith(
                    TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
                    image, Script.KOREAN
                )
            },
            safely {
                recognizeWith(
                    TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()),
                    image, Script.DEVANAGARI
                )
            }
        )

        val best = (others + latin)
            .filter { it.text.isNotBlank() }
            .maxByOrNull { scriptCount(it.text, it.script) }
        return best ?: throw NoTextFoundException()
    }

    private suspend fun recognizeWith(
        recognizer: TextRecognizer,
        image: InputImage,
        script: Script
    ): Candidate {
        try {
            val result = recognizer.process(image).await()
            val blocks = result.textBlocks
                .map { it.text.trim() }
                .filter { it.isNotEmpty() }
            return Candidate(blocks, script)
        } finally {
            recognizer.close()
        }
    }

    private suspend fun <T> safely(block: suspend () -> T): T? =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }

    // ------------------------------------------------------ language detection

    private suspend fun detectSourceLanguage(text: String, script: Script): String {
        val sample = text.take(500)
        val identifier = LanguageIdentification.getClient()
        val tag = try {
            identifier.identifyLanguage(sample).await()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            "und"
        } finally {
            identifier.close()
        }
        return TranslateLanguage.fromLanguageTag(tag.substringBefore('-'))
            ?: script.fallbackLang
    }

    // ------------------------------------------------------------- script maths

    private fun letterCount(text: String): Int {
        var count = 0
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            if (Character.isLetter(cp)) count++
        }
        return count
    }

    private fun scriptCount(text: String, script: Script): Int {
        var count = 0
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            if (!Character.isLetter(cp)) continue
            val unicodeScript = Character.UnicodeScript.of(cp)
            val matches = when (script) {
                Script.LATIN -> unicodeScript == Character.UnicodeScript.LATIN
                Script.CHINESE -> unicodeScript == Character.UnicodeScript.HAN
                Script.JAPANESE -> unicodeScript == Character.UnicodeScript.HIRAGANA ||
                        unicodeScript == Character.UnicodeScript.KATAKANA ||
                        unicodeScript == Character.UnicodeScript.HAN
                Script.KOREAN -> unicodeScript == Character.UnicodeScript.HANGUL
                Script.DEVANAGARI -> unicodeScript == Character.UnicodeScript.DEVANAGARI
            }
            if (matches) count++
        }
        return count
    }
}

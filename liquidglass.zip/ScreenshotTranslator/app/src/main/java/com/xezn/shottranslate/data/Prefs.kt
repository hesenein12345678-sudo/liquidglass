package com.xezn.shottranslate.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class TranslationRecord(
    val original: String,
    val translated: String,
    val sourceLang: String,
    val targetLang: String,
    val timestamp: Long
)

/** Small SharedPreferences wrapper shared by the UI and the background service. */
object Prefs {

    private const val FILE = "shot_translate_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_TARGET = "target_lang"
    private const val KEY_HISTORY = "history"
    private const val MAX_HISTORY = 30

    const val DEFAULT_TARGET = "ar"

    private val _history = MutableStateFlow<List<TranslationRecord>>(emptyList())
    val history: StateFlow<List<TranslationRecord>> = _history.asStateFlow()

    private val _target = MutableStateFlow(DEFAULT_TARGET)
    val target: StateFlow<String> = _target.asStateFlow()

    private var loaded = false

    private fun sp(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Synchronized
    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val prefs = sp(context)
        _target.value = prefs.getString(KEY_TARGET, DEFAULT_TARGET) ?: DEFAULT_TARGET
        _history.value = parseHistory(prefs.getString(KEY_HISTORY, null))
    }

    fun isEnabled(context: Context): Boolean = sp(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun targetLang(context: Context): String {
        load(context)
        return _target.value
    }

    fun setTargetLang(context: Context, lang: String) {
        load(context)
        sp(context).edit().putString(KEY_TARGET, lang).apply()
        _target.value = lang
    }

    @Synchronized
    fun addRecord(context: Context, record: TranslationRecord) {
        load(context)
        val updated = (listOf(record) + _history.value).take(MAX_HISTORY)
        _history.value = updated
        sp(context).edit().putString(KEY_HISTORY, serializeHistory(updated)).apply()
    }

    @Synchronized
    fun clearHistory(context: Context) {
        load(context)
        _history.value = emptyList()
        sp(context).edit().remove(KEY_HISTORY).apply()
    }

    private fun serializeHistory(list: List<TranslationRecord>): String {
        val array = JSONArray()
        list.forEach {
            array.put(
                JSONObject()
                    .put("o", it.original)
                    .put("t", it.translated)
                    .put("s", it.sourceLang)
                    .put("d", it.targetLang)
                    .put("ts", it.timestamp)
            )
        }
        return array.toString()
    }

    private fun parseHistory(json: String?): List<TranslationRecord> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(json)
            List(array.length()) { i ->
                val o = array.getJSONObject(i)
                TranslationRecord(
                    original = o.optString("o"),
                    translated = o.optString("t"),
                    sourceLang = o.optString("s"),
                    targetLang = o.optString("d"),
                    timestamp = o.optLong("ts")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

package com.xezn.shottranslate.service

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.xezn.shottranslate.data.TranslationRecord
import com.xezn.shottranslate.data.languageLabel

/**
 * Draws the floating "translate" pill (shown only right after a screenshot is taken)
 * and the result card, using plain Views because they live in a system overlay window.
 */
class OverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val metrics get() = context.resources.displayMetrics

    private var pill: View? = null
    private var card: View? = null
    private val autoHidePill = Runnable { removePill() }

    fun canShow(): Boolean = Settings.canDrawOverlays(context)

    // ------------------------------------------------------------ floating pill

    /** The "ترجمة" shortcut that appears for a few seconds after a screenshot. */
    fun showTranslateButton(onClick: () -> Unit) {
        showPill("ترجمة", 0xE60088FF.toInt(), autoHideMs = 8000L) {
            removePill()
            onClick()
        }
    }

    fun showStatus(text: String) {
        showPill(text, 0xE6333333.toInt(), autoHideMs = 0L, onClick = null)
    }

    fun hideStatus() = removePill()

    private fun showPill(text: String, fill: Int, autoHideMs: Long, onClick: (() -> Unit)?) {
        if (!canShow()) return
        removePill()

        val view = TextView(context).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = rounded(fill, 0x66FFFFFF, dp(40))
            if (onClick != null) setOnClickListener { onClick() }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = dp(12)
        }

        try {
            windowManager.addView(view, params)
            pill = view
            if (autoHideMs > 0) handler.postDelayed(autoHidePill, autoHideMs)
        } catch (_: Exception) {
            pill = null
        }
    }

    private fun removePill() {
        handler.removeCallbacks(autoHidePill)
        pill?.let { runCatching { windowManager.removeView(it) } }
        pill = null
    }

    // -------------------------------------------------------------- result card

    fun showResult(record: TranslationRecord) {
        val title = "${languageLabel(record.sourceLang)}  ←  ${languageLabel(record.targetLang)}"
        showCard(title, record.translated, record.original)
    }

    fun showError(message: String) {
        showCard("تعذرت الترجمة", message, null)
    }

    private fun showCard(title: String, body: String, original: String?) {
        if (!canShow()) return
        removeCard()

        val maxScrollHeight = (metrics.heightPixels * 0.42f).toInt()
        var showingOriginal = false

        val titleView = TextView(context).apply {
            text = title
            setTextColor(0xFF0088FF.toInt())
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }

        val bodyView = TextView(context).apply {
            text = body
            setTextColor(0xFF111111.toInt())
            textSize = 17f
            setLineSpacing(0f, 1.2f)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_TEXT_START
            setPadding(0, dp(10), 0, dp(10))
        }

        val scroll = MaxHeightScrollView(context, maxScrollHeight).apply {
            addView(bodyView)
        }

        val buttons = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }

        fun actionButton(label: String, fill: Int, textColor: Int, onClick: (TextView) -> Unit): TextView =
            TextView(context).apply {
                text = label
                setTextColor(textColor)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(11), dp(8), dp(11))
                background = rounded(fill, 0x00000000, dp(30))
                setOnClickListener { onClick(this) }
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(4), 0, dp(4), 0) }
            }

        val copy = actionButton("نسخ", 0xFF0088FF.toInt(), Color.WHITE) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(
                ClipData.newPlainText("translation", if (showingOriginal && original != null) original else body)
            )
            Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show()
        }
        val toggle = actionButton("النص الأصلي", 0x1A000000, 0xFF111111.toInt()) { self ->
            if (original == null) return@actionButton
            showingOriginal = !showingOriginal
            bodyView.text = if (showingOriginal) original else body
            self.text = if (showingOriginal) "الترجمة" else "النص الأصلي"
        }
        val close = actionButton("إغلاق", 0x1A000000, 0xFF111111.toInt()) { removeCard() }

        if (original == null) {
            toggle.alpha = 0.35f
            toggle.isEnabled = false
        }

        buttons.addView(copy)
        buttons.addView(toggle)
        buttons.addView(close)

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = rounded(0xF5FFFFFF.toInt(), 0x33000000, dp(28))
            addView(titleView)
            addView(scroll)
            addView(buttons)
        }

        val params = WindowManager.LayoutParams(
            metrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(28)
        }

        try {
            windowManager.addView(root, params)
            card = root
        } catch (_: Exception) {
            card = null
        }
    }

    private fun removeCard() {
        card?.let { runCatching { windowManager.removeView(it) } }
        card = null
    }

    fun removeAll() {
        removePill()
        removeCard()
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(value: Int): Int = (value * metrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int, radiusPx: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.toFloat()
        setColor(fill)
        if (Color.alpha(stroke) > 0) setStroke(dp(1), stroke)
    }

    private class MaxHeightScrollView(
        context: Context,
        private val maxHeightPx: Int
    ) : ScrollView(context) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            super.onMeasure(
                widthMeasureSpec,
                MeasureSpec.makeMeasureSpec(maxHeightPx, MeasureSpec.AT_MOST)
            )
        }
    }
}

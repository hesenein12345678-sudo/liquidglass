package com.xezn.shottranslate.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.xezn.shottranslate.data.Prefs

/** Restarts the screenshot watcher after a reboot if the user had it switched on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs.isEnabled(context)) return
        try {
            ScreenshotService.start(context)
        } catch (_: Exception) {
            // Some OEMs block background starts; the user can just reopen the app.
        }
    }
}

# مترجم اللقطات (Screenshot Translator)

تطبيق أندرويد: تاخذ لقطة شاشة → يظهر زر **ترجمة** عائم (فقط بعد اللقطة) → التطبيق يقرأ النص من الصورة ويترجمه، كل شي على الجهاز.

- واجهة **Liquid Glass** بمكتبة [Backdrop](https://github.com/Kyant0/AndroidLiquidGlass)
- نفس **Bottom Tabs** الموجودة في تطبيق *Backdrop Catalog*
- زر **Telegram** → `https://t.me/xezn9`
- زر **TikTok** → `https://www.tiktok.com/@xezn99`

## كيف يشتغل

1. `ScreenshotService` (خدمة أمامية) يراقب `MediaStore` لأي صورة جديدة اسمها/مسارها فيه `Screenshot`.
2. عند اكتشاف لقطة يظهر زر «ترجمة» عائم لمدة 8 ثوانٍ (أو إشعار فيه زر ترجمة إذا ما منحت إذن الظهور فوق التطبيقات).
3. عند الضغط: ML Kit OCR (لاتيني/صيني/ياباني/كوري/ديفاناغاري) → تحديد اللغة → ترجمة بدون إنترنت إلى لغتك.

## رفع المشروع على GitHub وبناء الـ APK

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<USERNAME>/<REPO>.git
git push -u origin main
```

بعدها: تبويب **Actions** → workflow اسمه **Build APK** → بعد ما يخلص افتح التشغيل ونزّل
**ScreenshotTranslator-apk** من قسم *Artifacts*.

(تقدر تشغله يدوياً: Actions → Build APK → **Run workflow**.)

## البناء محلياً

يحتاج JDK 21 و Android SDK (API 37):

```bash
./gradlew assembleDebug
# الناتج: app/build/outputs/apk/debug/app-debug.apk
```

أو افتح المجلد بـ Android Studio (إصدار حديث يدعم AGP 9.3).

## ملاحظات

- أول استخدام لكل لغة يحتاج إنترنت لتنزيل نموذج الترجمة (مرة واحدة).
- OCR الخاص بـ ML Kit لا يدعم العربية/الكيريلية/التايلاندية حالياً — يترجم من اللاتينية (إنجليزي، فرنسي، تركي…) والصينية واليابانية والكورية والهندية.
- أندرويد 13+ (API 33+) يعطي تأثير الزجاج الكامل (AGSL)؛ الأقدم يعرض نسخة مبسطة.
- بعض الشركات (Xiaomi, Huawei, Oppo…) توقف الخدمات بالخلفية — فعّل «تشغيل تلقائي» واستثناء البطارية.

## الترخيص

الكود المستعار من Backdrop Catalog تحت Apache-2.0 (انظر `NOTICE`).

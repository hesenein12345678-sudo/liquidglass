# e4 Watermark — Android project

An Android Jetpack Compose app for placing a customizable Liquid Glass signature over a photo. Uses the original Kyant0 Backdrop library and imports the Backdrop Catalog `LiquidBottomTabs` / `LiquidBottomTab` source during GitHub Actions builds.

## Features
- Select a photo from the Android photo picker.
- Place and drag the glass signature rectangle over the preview.
- Use the detected manufacturer/model as the default device label, or enter a custom label.
- Optionally add a circular avatar image.
- Customize corner radius, glass opacity, width, and position.
- Export a flattened JPEG into `Pictures/e4Watermark`.
- Real Backdrop lens/blur/vibrancy effect for the signature surface, panels, and bottom tabs.

## Build on GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this project (the `settings.gradle.kts` file must be at repository root), or upload this project ZIP as `liquidglass.zip` if using the included archive-extraction workflow.
3. Run **Actions → Build Android APK → Run workflow**.
4. Download the `E4Watermark-debug-apk` artifact after a successful build.

The workflow clones the upstream Apache-2.0 AndroidLiquidGlass repository to import the original Catalog bottom-tab components. The slider is styled in the Catalog's thin luminous style using Compose Material Slider; it is not copied from a separate original Catalog slider source.

## Device name note
Android apps cannot reliably read a user-customized global Bluetooth/device name on every Android version. The default label therefore uses the system manufacturer and model (`Build.MANUFACTURER` + `Build.MODEL`); users can override it in settings.

## Build-fix release 1.0.1
- Added the missing Compose `ContentScale` import.
- Replaced invalid `Alignment(x, y)` usage with a custom Compose alignment function.
- Removed unused LumaTranslate source files that were accidentally bundled and required missing ML Kit dependencies.

package com.e4developer.watermark

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as NativeCanvas
import android.graphics.Paint as NativePaint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.catalog.components.LiquidBottomTabs
import com.kyant.backdrop.catalog.components.LiquidBottomTab
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { E4App() } }
}

private val ink = Color(0xFFF5F7FF)
private val accent = Color(0xFF79D7FF)

@Composable private fun E4App() {
    val context = LocalContext.current
    val backdrop = rememberLayerBackdrop()
    var tab by remember { mutableIntStateOf(0) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var avatarUri by remember { mutableStateOf<Uri?>(null) }
    var deviceName by remember { mutableStateOf("${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}".trim()) }
    var customName by remember { mutableStateOf("") }
    var useDeviceName by remember { mutableStateOf(true) }
    var radius by remember { mutableFloatStateOf(28f) }
    var opacity by remember { mutableFloatStateOf(.86f) }
    var glassWidth by remember { mutableFloatStateOf(.76f) }
    var xPos by remember { mutableFloatStateOf(.5f) }
    var yPos by remember { mutableFloatStateOf(.78f) }
    var showAvatar by remember { mutableStateOf(true) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { imageUri = it; tab = 0 } }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { avatarUri = it } }
    val darkBg = Brush.linearGradient(listOf(Color(0xFF080D20), Color(0xFF101D3B), Color(0xFF241542), Color(0xFF08182D)))
    Box(Modifier.fillMaxSize().background(darkBg)) {
        // Background content is the actual Backdrop sampling layer.
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop).background(darkBg)) {
            repeat(9) { i ->
                val pulse by rememberInfiniteTransition(label = "glow$i").animateFloat(0.10f, 0.27f, infiniteRepeatable(tween(2600 + i * 170, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p$i")
                Box(Modifier.offset(x = (i * 47 - 60).dp, y = (i * 91 + 30).dp).size((80 + i % 4 * 35).dp).blur(34.dp).background(listOf(Color(0xFF2C8FFF), Color(0xFFB64DFF), Color(0xFF32D7D0))[i % 3].copy(alpha = pulse), CircleShape))
            }
        }
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(45.dp).clip(CircleShape).drawBackdrop(backdrop, shape = { CircleShape }, effects = { vibrancy(); blur(7.dp.toPx()); lens(12.dp.toPx(), 16.dp.toPx()) }, onDrawSurface = { drawRect(Color.White.copy(alpha=.12f)) },).border(1.dp, Color.White.copy(alpha=.28f), CircleShape), contentAlignment = Alignment.Center) { Text("e4", color=accent, fontWeight=FontWeight.Black, fontSize=19.sp) }
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("e4 Watermark", color=ink, fontSize=22.sp, fontWeight=FontWeight.Bold); Text("أضف توقيعك الزجاجي على صورك", color=ink.copy(alpha=.7f), fontSize=12.sp) }
                GlassIcon(backdrop, Icons.Default.Settings) { tab = 2 }
            }
            Spacer(Modifier.height(16.dp))
            when(tab) {
                0 -> HomeEditor(imageUri, avatarUri, if (useDeviceName) deviceName else customName.ifBlank { deviceName }, customName, showAvatar, radius, opacity, glassWidth, xPos, yPos, backdrop, { imagePicker.launch("image/*") }, { tab=1 }, { xPos=it.first; yPos=it.second }, { saveWatermarkedImage(context, imageUri, avatarUri, if (useDeviceName) deviceName else customName.ifBlank { deviceName }, showAvatar, radius, opacity, xPos, yPos) { savedUri=it; Toast.makeText(context, if(it!=null) "تم حفظ الصورة في المعرض" else "تعذر حفظ الصورة", Toast.LENGTH_LONG).show() } })
                1 -> CustomizePage(backdrop, radius, { radius=it }, opacity, { opacity=it }, glassWidth, { glassWidth=it }, showAvatar, { showAvatar=it }, avatarUri, { avatarPicker.launch("image/*") }, xPos, yPos, { xPos=it.first; yPos=it.second }, deviceName, if(useDeviceName) deviceName else customName.ifBlank { deviceName })
                else -> SettingsPage(backdrop, deviceName, { deviceName=it }, customName, { customName=it }, useDeviceName, { useDeviceName=it }, avatarUri, { avatarPicker.launch("image/*") }, showAvatar, { showAvatar=it })
            }
            Spacer(Modifier.weight(1f))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                LiquidBottomTabs(selectedTabIndex = { tab }, onTabSelected = { tab=it }, backdrop = backdrop, tabsCount = 3, modifier = Modifier.fillMaxWidth().padding(bottom=14.dp)) {
                    LiquidBottomTab(onClick={tab=0}) { Icon(Icons.Default.Edit, null, tint=if(tab==0) accent else ink.copy(alpha=.85f), modifier=Modifier.size(21.dp)); Text("تحرير", color=ink, fontSize=11.sp) }
                    LiquidBottomTab(onClick={tab=1}) { Icon(Icons.Default.Tune, null, tint=if(tab==1) accent else ink.copy(alpha=.85f), modifier=Modifier.size(21.dp)); Text("التخصيص", color=ink, fontSize=11.sp) }
                    LiquidBottomTab(onClick={tab=2}) { Icon(Icons.Default.Settings, null, tint=if(tab==2) accent else ink.copy(alpha=.85f), modifier=Modifier.size(21.dp)); Text("الإعدادات", color=ink, fontSize=11.sp) }
                }
            }
        }
    }
}

@Composable private fun GlassPanel(backdrop: com.kyant.backdrop.backdrops.LayerBackdrop, modifier: Modifier = Modifier, radius: Dp = 24.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(radius)).drawBackdrop(backdrop, shape={ RoundedCornerShape(radius) }, effects={ vibrancy(); blur(10.dp.toPx()); lens(18.dp.toPx(), 24.dp.toPx()) }, onDrawSurface={ drawRect(Color.White.copy(alpha=.105f)); drawRoundRect(Brush.linearGradient(listOf(Color.White.copy(alpha=.16f), Color.Transparent, Color(0xFF78CFFF).copy(alpha=.06f)))) }).border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha=.52f), Color.White.copy(alpha=.10f), accent.copy(alpha=.25f))), RoundedCornerShape(radius)).padding(15.dp), content=content)
}
@Composable private fun GlassIcon(backdrop: com.kyant.backdrop.backdrops.LayerBackdrop, icon: androidx.compose.ui.graphics.vector.ImageVector, click: ()->Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).drawBackdrop(backdrop, shape={CircleShape}, effects={vibrancy();blur(7.dp.toPx());lens(12.dp.toPx(),16.dp.toPx())}, onDrawSurface={drawRect(Color.White.copy(alpha=.12f))}).border(1.dp, Color.White.copy(alpha=.28f), CircleShape).clickable { click() }, contentAlignment=Alignment.Center) { Icon(icon, null, tint=ink) }
}
@Composable private fun HomeEditor(uri: Uri?, avatar: Uri?, name: String, custom: String, showAvatar: Boolean, radius: Float, opacity: Float, width: Float, x: Float, y: Float, backdrop: com.kyant.backdrop.backdrops.LayerBackdrop, pick:()->Unit, customize:()->Unit, move:(Pair<Float,Float>)->Unit, save:()->Unit) {
    val context = LocalContext.current
    GlassPanel(backdrop, Modifier.fillMaxWidth()) {
        Row(verticalAlignment=Alignment.CenterVertically) { Text("معاينة الصورة", color=ink, fontWeight=FontWeight.Bold, fontSize=17.sp); Spacer(Modifier.weight(1f)); Text("LIVE GLASS", color=accent, fontSize=10.sp, fontWeight=FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(365.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF172642)).border(1.dp, Color.White.copy(alpha=.15f), RoundedCornerShape(22.dp)), contentAlignment=Alignment.Center) {
            if(uri != null) ImageFromUri(uri, Modifier.fillMaxSize(), ContentScale.Fit) else Column(horizontalAlignment=Alignment.CenterHorizontally) { Icon(Icons.Default.AddPhotoAlternate, null, tint=accent, modifier=Modifier.size(58.dp)); Spacer(Modifier.height(10.dp)); Text("اختَر صورة للبدء", color=ink, fontWeight=FontWeight.SemiBold); Text("راح يظهر التوقيع الزجاجي فوقها", color=ink.copy(alpha=.62f), fontSize=12.sp) }
            if(uri != null) {
                val shape = RoundedCornerShape(radius.dp)
                Row(Modifier.align(Alignment(x.coerceIn(.08f,.92f), y.coerceIn(.08f,.92f))).fillMaxWidth(width.coerceIn(.48f,.96f)).clip(shape).drawBackdrop(backdrop, shape={shape}, effects={vibrancy();blur(10.dp.toPx());lens(18.dp.toPx(),24.dp.toPx())}, onDrawSurface={drawRect(Color.White.copy(alpha=opacity*.18f));drawRoundRect(Brush.linearGradient(listOf(Color.White.copy(alpha=.18f), Color.Transparent, accent.copy(alpha=.09f))))}).border(1.dp, Color.White.copy(alpha=.72f), shape).padding(horizontal=10.dp, vertical=9.dp).pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); move(Pair((x+drag.x/420f).coerceIn(.08f,.92f),(y+drag.y/360f).coerceIn(.08f,.92f))) } }, verticalAlignment=Alignment.CenterVertically) {
                    if(showAvatar) { if(avatar!=null) ImageFromUri(avatar, Modifier.size(33.dp).clip(CircleShape).border(1.dp, Color.White.copy(alpha=.75f), CircleShape), ContentScale.Crop) else Box(Modifier.size(33.dp).clip(CircleShape).background(Color.White.copy(alpha=.18f)).border(1.dp, Color.White.copy(alpha=.7f), CircleShape), contentAlignment=Alignment.Center) { Icon(Icons.Default.Person, null, tint=Color.White, modifier=Modifier.size(19.dp)) }; Spacer(Modifier.width(9.dp)) }
                    Column(Modifier.weight(1f)) { Text(name, color=Color.White, fontSize=12.sp, fontWeight=FontWeight.SemiBold, maxLines=1); if(custom.isNotBlank()) Text(custom, color=Color.White.copy(alpha=.78f), fontSize=10.sp, maxLines=1) }
                    Icon(Icons.Default.Verified, null, tint=Color.White.copy(alpha=.8f), modifier=Modifier.size(16.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) { Button(onClick=pick, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF2B74BB)), shape=RoundedCornerShape(15.dp)) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text("اختيار صورة") }; OutlinedButton(onClick=customize, modifier=Modifier.weight(1f), shape=RoundedCornerShape(15.dp), border=BorderStroke(1.dp, Color.White.copy(alpha=.35f)), colors=ButtonDefaults.outlinedButtonColors(contentColor=ink)) { Icon(Icons.Default.Tune, null); Spacer(Modifier.width(6.dp)); Text("تخصيص") } }
        Spacer(Modifier.height(9.dp)); Button(onClick=save, enabled=uri!=null, modifier=Modifier.fillMaxWidth().height(52.dp), shape=RoundedCornerShape(17.dp), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF4C9DE8))) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("حفظ الصورة بالتوقيع", fontWeight=FontWeight.Bold) }
        Text("اسحب المستطيل داخل الصورة لتغيير مكانه", color=ink.copy(alpha=.58f), fontSize=11.sp, modifier=Modifier.fillMaxWidth().padding(top=8.dp), textAlign=TextAlign.Center)
    }
}
@Composable private fun CustomizePage(backdrop: com.kyant.backdrop.backdrops.LayerBackdrop, radius: Float, setRadius:(Float)->Unit, opacity:Float, setOpacity:(Float)->Unit, width:Float,setWidth:(Float)->Unit, showAvatar:Boolean,setAvatar:(Boolean)->Unit, avatar:Uri?,pickAvatar:()->Unit,x:Float,y:Float,move:(Pair<Float,Float>)->Unit,device:String,name:String) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(13.dp)) {
        GlassPanel(backdrop) { Text("تخصيص المستطيل الزجاجي", color=ink, fontSize=18.sp, fontWeight=FontWeight.Bold); Text("عدّل الحواف والشفافية والحجم", color=ink.copy(alpha=.65f), fontSize=12.sp); Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf(0f to "مربع", 18f to "نصف دائري", 40f to "دائري").forEach { (r,label) -> Column(Modifier.weight(1f).clip(RoundedCornerShape(15.dp)).background(if(radius==r) accent.copy(alpha=.2f) else Color.White.copy(alpha=.05f)).border(1.dp, if(radius==r) accent else Color.White.copy(alpha=.15f), RoundedCornerShape(15.dp)).clickable { setRadius(r) }.padding(10.dp), horizontalAlignment=Alignment.CenterHorizontally) { Box(Modifier.size(35.dp,24.dp).clip(RoundedCornerShape(r.dp)).background(Color.White.copy(alpha=.15f)).border(1.dp, accent, RoundedCornerShape(r.dp))); Spacer(Modifier.height(6.dp)); Text(label, color=ink, fontSize=11.sp) } } }
            Spacer(Modifier.height(10.dp)); Text("نصف قطر الحواف: ${radius.roundToInt()} dp", color=ink, fontSize=13.sp); CatalogStyleSlider(radius,0f,44f,setRadius)
            Text("شفافية الزجاج: ${(opacity*100).roundToInt()}%", color=ink, fontSize=13.sp); CatalogStyleSlider(opacity,.25f,1f,setOpacity)
            Text("عرض المستطيل: ${(width*100).roundToInt()}%", color=ink, fontSize=13.sp); CatalogStyleSlider(width,.48f,.96f,setWidth)
            Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("إظهار الصورة الدائرية", color=ink); Text("تظهر بجانب اسم الجهاز", color=ink.copy(alpha=.6f), fontSize=11.sp) }; Switch(checked=showAvatar,onCheckedChange=setAvatar, colors=SwitchDefaults.colors(checkedThumbColor=Color.White,checkedTrackColor=Color(0xFF238DDD))) }
            OutlinedButton(onClick=pickAvatar, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(15.dp), border=BorderStroke(1.dp,Color.White.copy(alpha=.3f)), colors=ButtonDefaults.outlinedButtonColors(contentColor=ink)) { Icon(Icons.Default.AccountCircle,null); Spacer(Modifier.width(8.dp)); Text(if(avatar==null) "اختيار صورة دائرية" else "تغيير الصورة الدائرية") }
        }
        GlassPanel(backdrop) { Text("مكان المستطيل", color=ink, fontSize=16.sp, fontWeight=FontWeight.Bold); Text("الموضع الأفقي ${(x*100).roundToInt()}%", color=ink); CatalogStyleSlider(x,.08f,.92f) { move(Pair(it,y)) }; Text("الموضع العمودي ${(y*100).roundToInt()}%", color=ink); CatalogStyleSlider(y,.08f,.92f) { move(Pair(x,it)) } }
    }
}
@Composable private fun CatalogStyleSlider(value:Float, min:Float, max:Float, onChange:(Float)->Unit) {
    // Compose slider styled to match Backdrop Catalog's thin luminous track and glass thumb.
    Slider(value=value.coerceIn(min,max), onValueChange=onChange, valueRange=min..max, colors=SliderDefaults.colors(thumbColor=Color(0xFFDDF7FF), activeTrackColor=Color(0xFF7AD7FF), inactiveTrackColor=Color.White.copy(alpha=.16f), activeTickColor=Color.Transparent, inactiveTickColor=Color.Transparent))
}
@Composable private fun SettingsPage(backdrop: com.kyant.backdrop.backdrops.LayerBackdrop, device:String,setDevice:(String)->Unit,custom:String,setCustom:(String)->Unit,useDevice:Boolean,setUse:(Boolean)->Unit,avatar:Uri?,pick:()->Unit,showAvatar:Boolean,setAvatar:(Boolean)->Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(13.dp)) {
        GlassPanel(backdrop) { Text("اسم الجهاز", color=ink, fontSize=19.sp, fontWeight=FontWeight.Bold); Text("الاسم المكتشف من نظام أندرويد", color=ink.copy(alpha=.65f), fontSize=12.sp); Spacer(Modifier.height(10.dp)); GlassPanel(backdrop, Modifier.fillMaxWidth(), 16.dp) { Text(device, color=ink, fontWeight=FontWeight.SemiBold); Text("المصنّع: ${Build.MANUFACTURER}  •  الطراز: ${Build.MODEL}", color=ink.copy(alpha=.58f), fontSize=11.sp) }
            Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("استخدام اسم الجهاز تلقائياً", color=ink); Text("يستخدم اسم الشركة والطراز المتاحين للنظام", color=ink.copy(alpha=.58f), fontSize=11.sp) }; Switch(checked=useDevice,onCheckedChange=setUse) }
            OutlinedTextField(value=custom,onValueChange=setCustom,label={Text("اسم مخصص")},placeholder={Text("مثلاً: e4 Developer")},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=ink,unfocusedTextColor=ink,focusedBorderColor=accent,unfocusedBorderColor=Color.White.copy(alpha=.3f),focusedLabelColor=accent,unfocusedLabelColor=ink.copy(alpha=.7f),cursorColor=accent))
            Text("عند إيقاف الخيار، سيظهر الاسم المخصص. أندرويد لا يتيح لكل التطبيقات قراءة اسم الجهاز المخصص الحقيقي في كل الأجهزة.", color=ink.copy(alpha=.55f), fontSize=11.sp)
        }
        GlassPanel(backdrop) { Text("صورة التوقيع", color=ink, fontSize=17.sp, fontWeight=FontWeight.Bold); Row(verticalAlignment=Alignment.CenterVertically) { if(avatar!=null) ImageFromUri(avatar,Modifier.size(50.dp).clip(CircleShape),ContentScale.Crop) else Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(alpha=.12f)),contentAlignment=Alignment.Center){Icon(Icons.Default.Person,null,tint=ink)}; Spacer(Modifier.width(12.dp)); Button(onClick=pick,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF2B74BB))) { Text("اختيار صورة") } }; Row(verticalAlignment=Alignment.CenterVertically) { Text("إظهار الصورة",Modifier.weight(1f),color=ink); Switch(checked=showAvatar,onCheckedChange=setAvatar) } }
        GlassPanel(backdrop) { Text("حول التطبيق", color=ink, fontWeight=FontWeight.Bold, fontSize=17.sp); Text("e4 Developer", color=accent, fontSize=15.sp); Text("Liquid Glass powered by Kyant0 Backdrop", color=ink.copy(alpha=.65f), fontSize=11.sp) }
    }
}
@Composable private fun ImageFromUri(uri:Uri, modifier:Modifier, contentScale:ContentScale) { val context= LocalContext.current; var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }; LaunchedEffect(uri) { bitmap = runCatching { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }.getOrNull() }; bitmap?.let { Image(it.asImageBitmap(), null, modifier, contentScale=contentScale) } }

private fun saveWatermarkedImage(context: android.content.Context, uri:Uri?, avatarUri:Uri?, name:String, showAvatar:Boolean, radius:Float, opacity:Float, x:Float, y:Float, done:(Uri?)->Unit) {
    if(uri==null) { done(null); return }
    try {
        val source=context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: run { done(null); return }
        val bitmap=source.copy(Bitmap.Config.ARGB_8888,true); val canvas=NativeCanvas(bitmap); val scale=bitmap.width/420f
        val textPaint=NativePaint( NativePaint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.WHITE; textSize=13f*scale; typeface=android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL); setShadowLayer(2f*scale,0f,1f*scale,android.graphics.Color.BLACK) }
        val padding=12f*scale; val avatarSize=33f*scale; val textW=textPaint.measureText(name); val w=(textW+padding*2+(if(showAvatar) avatarSize+9f*scale else 0f)).coerceAtMost(bitmap.width*.92f); val h=55f*scale
        val left=(bitmap.width*x-w/2).coerceIn(0f,(bitmap.width-w).coerceAtLeast(0f)); val top=(bitmap.height*y-h/2).coerceIn(0f,(bitmap.height-h).coerceAtLeast(0f)); val rect=RectF(left,top,left+w,top+h)
        val p=NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.argb((opacity*65).roundToInt(),255,255,255); style=NativePaint.Style.FILL; setShadowLayer(10f*scale,0f,3f*scale,0x663A9FFF) }; canvas.drawRoundRect(rect,radius*scale,radius*scale,p)
        val stroke=NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.argb(185,255,255,255); style=NativePaint.Style.STROKE; strokeWidth=1.2f*scale }; canvas.drawRoundRect(rect,radius*scale,radius*scale,stroke)
        var tx=left+padding
        if(showAvatar) { val avatar=avatarUri?.let { runCatching { context.contentResolver.openInputStream(it)?.use { stream -> BitmapFactory.decodeStream(stream) } }.getOrNull() }; if(avatar!=null) { val ap=NativePaint(NativePaint.ANTI_ALIAS_FLAG); val path=android.graphics.Path().apply { addCircle(left+padding+avatarSize/2,top+h/2,avatarSize/2,android.graphics.Path.Direction.CW) }; canvas.save(); canvas.clipPath(path); canvas.drawBitmap(avatar,null,RectF(left+padding,top+(h-avatarSize)/2,left+padding+avatarSize,top+(h+avatarSize)/2),ap); canvas.restore() } else { val ap=NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.WHITE; style=NativePaint.Style.STROKE; strokeWidth=2f*scale }; canvas.drawCircle(left+padding+avatarSize/2,top+h/2,avatarSize/2,ap) }; tx+=avatarSize+9f*scale }
        canvas.drawText(name,tx,top+h/2-textPaint.ascent()/2-textPaint.descent()/2,textPaint)
        val values=ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME,"e4_watermark_${SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())}.jpg"); put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg"); if(Build.VERSION.SDK_INT>=29) put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/e4Watermark") }
        val outUri=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: run { done(null); return }; context.contentResolver.openOutputStream(outUri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG,95,it) }; done(outUri)
    } catch (_:Exception) { done(null) }
}

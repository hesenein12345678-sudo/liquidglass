package com.example.liquidglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LiquidGlassScreen() }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Home", Icons.Filled.Home),
    TabItem("Search", Icons.Filled.Search),
    TabItem("Likes", Icons.Filled.Favorite),
    TabItem("Profile", Icons.Filled.Person),
)

@Composable
fun LiquidGlassScreen() {
    val backdrop = rememberLayerBackdrop()
    var selectedTab by remember { mutableIntStateOf(0) }
    val isDark = isSystemInDarkTheme()
    val contentColor = if (isDark) Color.White else Color.Black

    Box(Modifier.fillMaxSize()) {

        // الخلفية اللي يشوفها الزجاج
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
        ) {
            ColorfulBackground(isDark)
        }

        LiquidBottomTabs(
            selectedTabIndex = { selectedTab },
            onTabSelected = { selectedTab = it },
            backdrop = backdrop,
            tabsCount = tabs.size,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 36.dp, vertical = 32.dp)
        ) {
            tabs.forEachIndexed { index, tab ->
                LiquidBottomTab(onClick = { selectedTab = index }) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.label,
                        tint = contentColor,
                        modifier = Modifier.size(28.dp)
                    )
                    BasicText(
                        tab.label,
                        style = TextStyle(
                            color = contentColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ColorfulBackground(isDark: Boolean) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (isDark) {
            drawRect(
                Brush.linearGradient(
                    listOf(Color(0xFF0B1026), Color(0xFF2B1B6B), Color(0xFF0A4D8C)),
                    start = Offset(0f, 0f),
                    end = Offset(w, h)
                )
            )
        } else {
            drawRect(
                Brush.linearGradient(
                    listOf(Color(0xFF7EE8C8), Color(0xFFDDEFF0), Color(0xFF3B82F6)),
                    start = Offset(0f, 0f),
                    end = Offset(w, h)
                )
            )
        }
        drawCircle(Color(0xFF00E5FF).copy(0.9f), w * 0.38f, Offset(w * 0.15f, h * 0.22f))
        drawCircle(Color(0xFFFFD54F).copy(0.9f), w * 0.30f, Offset(w * 0.90f, h * 0.50f))
        drawCircle(Color(0xFF1E5BFF), w * 0.45f, Offset(w * 0.75f, h * 0.88f))
        drawCircle(Color(0xFF69F0AE), w * 0.28f, Offset(w * 0.25f, h * 0.78f))
        drawCircle(Color(0xFFFF4081).copy(0.85f), w * 0.20f, Offset(w * 0.55f, h * 0.42f))
    }
}

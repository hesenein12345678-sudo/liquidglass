package com.example.liquidglass

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerInputScope

/**
 * Observes a press-and-drag gesture without consuming it.
 * The gesture starts immediately on touch down (no touch slop), like in the Backdrop catalog.
 */
suspend fun PointerInputScope.inspectDragGestures(
    onDragStart: (down: PointerInputChange) -> Unit = {},
    onDragEnd: (change: PointerInputChange) -> Unit = {},
    onDragCancel: () -> Unit = {},
    onDrag: (change: PointerInputChange, dragAmount: Offset) -> Unit
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        onDragStart(down)
        val pointerId = down.id
        var last = down
        var cancelled = false
        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == pointerId }
            if (change == null) {
                cancelled = true
                break
            }
            last = change
            if (!change.pressed) break
            val delta = (change.position - change.previousPosition)
            if (delta != Offset.Zero) onDrag(change, delta)
        }
        if (cancelled) onDragCancel() else onDragEnd(last)
    }
}

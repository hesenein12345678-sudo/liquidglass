# مترجم اللقطات (ShotTranslate)

تطبيق أندرويد: بعد كل لقطة شاشة يظهر اختصار صغير، تضغط عليه فيقرأ النص من اللقطة ويترجمه للعربية (أو أي لغة تختارها).

- واجهة Liquid Glass بمكتبة [backdrop 2.0.1](https://github.com/Kyant0/AndroidLiquidGlass)
- شريط سفلي (Bottom tabs) بتصميم زجاجي
- الحد الأدنى: Android 13 (API 33)

## البناء عن طريق GitHub
1. أنشئ مستودع جديد على GitHub وارفع كل محتويات هذا المجلد (مو الـ zip نفسه).
2. روح لتبويب **Actions** وراح يشتغل **Build APK** تلقائياً (أو شغّله يدوياً).
3. بعد ما يخلص، نزّل `ShotTranslate-debug-apk` من قسم Artifacts، فك الضغط وثبّت الـ APK.

## البناء بـ Android Studio
افتح المجلد واضغط Run.

## ملاحظة
الشريط السفلي منسوخ من تطبيق Backdrop Catalog (LiquidBottomTabs) مع ملفاته المساعدة (Apache-2.0).
الإصدارات: Kotlin 2.4.10 / AGP 8.13.2 / Gradle 8.13 / compileSdk 36.

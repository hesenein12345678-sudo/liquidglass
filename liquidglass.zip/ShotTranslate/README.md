# مترجم اللقطات (ShotTranslate)

تطبيق أندرويد: بعد كل لقطة شاشة يظهر اختصار صغير، تضغط عليه فيقرأ النص من اللقطة ويترجمه للعربية (أو أي لغة تختارها).

- واجهة Liquid Glass بمكتبة [backdrop](https://github.com/Kyant0/AndroidLiquidGlass)
- شريط سفلي (Bottom tabs) بتصميم زجاجي
- الحد الأدنى: Android 13 (API 33)

## البناء عن طريق GitHub
1. أنشئ مستودع جديد على GitHub وارفع كل محتويات هذا المجلد (مو الـ zip نفسه).
2. روح لتبويب **Actions** وراح يشتغل **Build APK** تلقائياً (أو شغّله يدوياً).
3. بعد ما يخلص، نزّل `ShotTranslate-debug-apk` من قسم Artifacts، فك الضغط وثبّت الـ APK.

## البناء بـ Android Studio
افتح المجلد واضغط Run.

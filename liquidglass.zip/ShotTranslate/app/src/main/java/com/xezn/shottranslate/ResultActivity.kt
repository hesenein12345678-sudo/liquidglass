package com.xezn.shottranslate

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.nl.translate.TranslateLanguage
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ResultActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val uri = intent.getParcelableExtra("uri", Uri::class.java)
        setContent { AppTheme { ResultScreen(uri) { finish() } } }
    }
}

private sealed interface UiState {
    data class Loading(val msg: String) : UiState
    data class Error(val msg: String) : UiState
    data class Done(val pairs: List<Pair<String, String>>, val src: String) : UiState
}

@Composable
private fun ResultScreen(uri: Uri?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val backdrop = rememberLayerBackdrop()
    var state by remember { mutableStateOf<UiState>(UiState.Loading("جاري قراءة النص من اللقطة...")) }

    LaunchedEffect(uri) {
        state = try {
            if (uri == null) throw IllegalStateException("ما أكو صورة")
            val bmp = withContext(Dispatchers.IO) {
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            } ?: throw IllegalStateException("تعذر فتح الصورة")
            val blocks = Engine.recognize(bmp)
            if (blocks.isEmpty()) {
                UiState.Error("ما لكيت أي نص بالصورة.")
            } else {
                val src = Engine.detect(blocks.joinToString("\n"))
                val tgt = App.prefs.targetLang.value
                val srcTag = TranslateLanguage.fromLanguageTag(src)
                if (src == "und" || srcTag == null) {
                    UiState.Error("ما كدرت أحدد لغة النص أو اللغة مو مدعومة.")
                } else if (srcTag == tgt) {
                    UiState.Error("النص أصلاً بنفس لغة الترجمة المختارة.")
                } else {
                    state = UiState.Loading("جاري الترجمة... (أول مرة يحتاج إنترنت لتحميل نموذج اللغة)")
                    UiState.Done(blocks.zip(Engine.translate(blocks, srcTag, tgt)), srcTag)
                }
            }
        } catch (e: Exception) {
            UiState.Error("صار خطأ: ${e.localizedMessage ?: "غير معروف"}")
        }
    }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) { AppBackground() }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("الترجمة", Modifier.weight(1f), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onClose) { Text("إغلاق") }
            }
            when (val s = state) {
                is UiState.Loading -> GlassCard(backdrop) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        CircularProgressIndicator(Modifier.padding(4.dp))
                        Text(s.msg)
                    }
                }
                is UiState.Error -> GlassCard(backdrop) { Text(s.msg) }
                is UiState.Done -> {
                    val all = s.pairs.joinToString("\n\n") { it.second }
                    val langName = LANGS.firstOrNull { it.first == s.src }?.second ?: s.src
                    Text("اللغة الأصلية: $langName", Modifier.alpha(0.7f), fontSize = 13.sp)
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        s.pairs.forEach { (orig, tr) ->
                            GlassCard(backdrop) {
                                Text(orig, Modifier.alpha(0.6f), fontSize = 13.sp)
                                Text(tr, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, lineHeight = 26.sp)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("translation", all))
                            Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
                        }) { Text("نسخ الكل") }
                        OutlinedButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, all)
                            ctx.startActivity(Intent.createChooser(send, null))
                        }) { Text("مشاركة") }
                    }
                }
            }
        }
    }
}

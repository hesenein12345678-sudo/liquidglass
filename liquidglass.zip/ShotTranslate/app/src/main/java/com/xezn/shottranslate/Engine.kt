package com.xezn.shottranslate

import android.graphics.Bitmap
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

object Engine {

    private fun count(blocks: List<String>) = blocks.sumOf { b -> b.count { !it.isWhitespace() } }

    private suspend fun run(client: TextRecognizer, img: InputImage): List<String> {
        return try {
            client.process(img).await().textBlocks.map { it.text.trim() }.filter { it.isNotEmpty() }
        } finally {
            client.close()
        }
    }

    /** Reads text blocks from the screenshot. Latin first, then CJK / Devanagari if little was found. */
    suspend fun recognize(bmp: Bitmap): List<String> {
        val img = InputImage.fromBitmap(bmp, 0)
        var best = run(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS), img)
        if (count(best) < 15) {
            val others = listOf<() -> TextRecognizer>(
                { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) },
                { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) },
                { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) },
                { TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()) }
            )
            for (make in others) {
                val r = run(make(), img)
                if (count(r) > count(best)) best = r
            }
        }
        return best
    }

    suspend fun detect(text: String): String {
        val client = LanguageIdentification.getClient()
        return try {
            client.identifyLanguage(text).await()
        } finally {
            client.close()
        }
    }

    suspend fun translate(blocks: List<String>, src: String, tgt: String): List<String> {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(src)
            .setTargetLanguage(tgt)
            .build()
        val tr = Translation.getClient(options)
        return try {
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            blocks.map { tr.translate(it).await() }
        } finally {
            tr.close()
        }
    }
}

package com.xezn.shottranslate

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

/** Liquid-glass surface built on the `backdrop` library. */
@Composable
fun Modifier.glass(
    backdrop: Backdrop,
    shape: Shape,
    tint: Color? = null,
    refraction: Float = 10f
): Modifier {
    val dark = LocalDark.current
    val surface = tint ?: if (dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.42f)
    return this.drawBackdrop(
        backdrop = backdrop,
        shape = { shape },
        effects = {
            vibrancy()
            blur(6.dp.toPx())
            lens(refraction.dp.toPx(), (refraction * 2f).dp.toPx())
        },
        onDrawSurface = { drawRect(surface) }
    )
}

@Composable
fun GlassCard(
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .fillMaxWidth()
            .glass(backdrop, RoundedCornerShape(28.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun GlassButton(backdrop: Backdrop, text: String, icon: Int, onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .glass(backdrop, shape, tint = accent.copy(alpha = 0.30f))
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(painterResource(icon), null, Modifier.size(28.dp), tint = accent)
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

data class TabItem(val label: String, val icon: Int)

/** Bottom tabs in liquid-glass style (floating capsule + animated selection pill). */
@Composable
fun GlassTabBar(
    backdrop: Backdrop,
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = MaterialTheme.colorScheme.primary
    val idle = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
    Box(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 22.dp, vertical = 12.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .glass(backdrop, CircleShape, refraction = 12f)
                .padding(6.dp)
        ) {
            tabs.forEachIndexed { i, t ->
                val sel = i == selected
                val bg by animateColorAsState(if (sel) accent.copy(alpha = 0.28f) else Color.Transparent, label = "tab")
                val fg = if (sel) accent else idle
                Column(
                    Modifier
                        .weight(1f)
                        .clip(CircleShape)
                        .background(bg)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(i) }
                        .padding(vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(painterResource(t.icon), null, Modifier.size(24.dp), tint = fg)
                    Text(t.label, fontSize = 11.sp, color = fg, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

package com.xezn.shottranslate

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

class App : Application() {
    companion object {
        lateinit var prefs: Prefs
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }
}

/** A preference that is also Compose state, so the UI updates instantly. */
class Pref<T : Any>(
    private val sp: SharedPreferences,
    private val key: String,
    private val def: T
) {
    private val state = mutableStateOf(load())

    @Suppress("UNCHECKED_CAST")
    private fun load(): T = when (def) {
        is Int -> sp.getInt(key, def) as T
        is Boolean -> sp.getBoolean(key, def) as T
        is String -> (sp.getString(key, def) ?: def) as T
        else -> def
    }

    var value: T
        get() = state.value
        set(v) {
            state.value = v
            val e = sp.edit()
            when (v) {
                is Int -> e.putInt(key, v)
                is Boolean -> e.putBoolean(key, v)
                is String -> e.putString(key, v)
            }
            e.apply()
        }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // appearance
    val theme = Pref(sp, "theme", 0)                 // 0 system, 1 light, 2 dark
    val accent = Pref(sp, "accent", 0xFF0A84FF.toInt())
    val appIcon = Pref(sp, "appIcon", 0)
    val targetLang = Pref(sp, "targetLang", "ar")

    // background: 0 default, 1 solid colour, 2 image
    val bgMode = Pref(sp, "bgMode", 0)
    val bgColor = Pref(sp, "bgColor", 0xFF101428.toInt())
    val bgStamp = Pref(sp, "bgStamp", 0)

    // service
    val serviceOn = Pref(sp, "serviceOn", false)

    // screenshot shortcut
    val ovColor = Pref(sp, "ovColor", 0xFF0A84FF.toInt())
    val ovShape = Pref(sp, "ovShape", 1)             // 0 circle, 1 rounded, 2 square
    val ovCorner = Pref(sp, "ovCorner", 18)
    val ovSize = Pref(sp, "ovSize", 54)
    val ovSide = Pref(sp, "ovSide", 1)               // 0 left, 1 right
    val ovY = Pref(sp, "ovY", 60)                    // 0..100 %
    val ovAlpha = Pref(sp, "ovAlpha", 100)
    val ovIcon = Pref(sp, "ovIcon", 0)
}

val LANGS = listOf(
    "ar" to "العربية", "en" to "English", "tr" to "Türkçe", "fa" to "فارسی",
    "ur" to "اردو", "fr" to "Français", "de" to "Deutsch", "es" to "Español",
    "it" to "Italiano", "ru" to "Русский", "pt" to "Português", "nl" to "Nederlands",
    "zh" to "中文", "ja" to "日本語", "ko" to "한국어", "hi" to "हिन्दी"
)

val GLYPHS = listOf(R.drawable.ic_glyph_translate, R.drawable.ic_glyph_star, R.drawable.ic_glyph_bolt)

package com.xezn.shottranslate

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import java.io.File

val LocalDark = compositionLocalOf { false }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val p = App.prefs
    val dark = when (p.theme.value) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val accent = Color(p.accent.value)
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent, onPrimary = Color.White,
            surface = Color(0xFF14172B), onSurface = Color.White,
            background = Color(0xFF0E1124), onBackground = Color.White,
            secondaryContainer = accent.copy(alpha = 0.35f), onSecondaryContainer = Color.White
        )
    } else {
        lightColorScheme(
            primary = accent, onPrimary = Color.White,
            surface = Color.White, onSurface = Color(0xFF14172B),
            background = Color(0xFFF1F4FF), onBackground = Color(0xFF14172B),
            secondaryContainer = accent.copy(alpha = 0.25f), onSecondaryContainer = Color(0xFF14172B)
        )
    }
    CompositionLocalProvider(
        LocalDark provides dark,
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = scheme) {
            Surface(color = Color.Transparent, contentColor = scheme.onSurface, content = content)
        }
    }
}

/** Full-screen background (default gradient blobs, solid colour or user image). */
@Composable
fun AppBackground() {
    val p = App.prefs
    val ctx = LocalContext.current
    val dark = LocalDark.current
    val accent = Color(p.accent.value)
    val base = if (dark) Color(0xFF0E1124) else Color(0xFFF1F4FF)
    val mode = p.bgMode.value

    val bmp = if (mode == 2) {
        remember(p.bgStamp.value) {
            BitmapFactory.decodeFile(File(ctx.filesDir, "bg.jpg").path)?.asImageBitmap()
        }
    } else null

    Box(Modifier.fillMaxSize()) {
        when {
            bmp != null -> {
                Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (dark) 0.30f else 0.05f)))
            }
            mode == 1 -> Box(Modifier.fillMaxSize().background(Color(p.bgColor.value)))
            else -> Canvas(Modifier.fillMaxSize()) {
                drawRect(base)
                val w = size.width
                val h = size.height
                fun blob(c: Color, cx: Float, cy: Float, r: Float) = drawCircle(
                    brush = Brush.radialGradient(
                        listOf(c.copy(alpha = if (dark) 0.55f else 0.45f), Color.Transparent),
                        center = Offset(cx, cy), radius = r
                    ),
                    radius = r, center = Offset(cx, cy)
                )
                blob(accent, w * 0.15f, h * 0.12f, w * 0.8f)
                blob(Color(0xFFBF5AF2), w * 0.95f, h * 0.45f, w * 0.7f)
                blob(Color(0xFF64D2FF), w * 0.2f, h * 0.85f, w * 0.75f)
            }
        }
    }
}

package com.xezn.shottranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat

class ScreenshotService : Service() {
    private lateinit var overlay: OverlayManager
    private var lastId = -1L

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            checkLatest()
        }
    }

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayManager(applicationContext)
        startForeground(
            1, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer
        )
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("svc", "خدمة المراقبة", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, "svc")
            .setSmallIcon(R.drawable.ic_glyph_translate)
            .setContentTitle("مترجم اللقطات شغّال")
            .setContentText("ينتظر لقطة شاشة جديدة")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun checkLatest() {
        try {
            val args = Bundle().apply {
                putStringArray(
                    android.content.ContentResolver.QUERY_ARG_SORT_COLUMNS,
                    arrayOf(MediaStore.Images.Media.DATE_ADDED)
                )
                putInt(
                    android.content.ContentResolver.QUERY_ARG_SORT_DIRECTION,
                    android.content.ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
                putInt(android.content.ContentResolver.QUERY_ARG_LIMIT, 1)
            }
            val proj = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.RELATIVE_PATH,
                MediaStore.Images.Media.DATE_ADDED
            )
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, args, null
            )?.use { c ->
                if (!c.moveToFirst()) return
                val id = c.getLong(0)
                val text = (c.getString(1).orEmpty() + " " + c.getString(2).orEmpty()).lowercase()
                val added = c.getLong(3)
                val fresh = System.currentTimeMillis() / 1000 - added < 15
                val isShot = text.contains("screenshot") || text.contains("screen_shot") ||
                    text.contains("لقطة") || text.contains("截屏") || text.contains("スクリーンショット")
                if (isShot && fresh && id != lastId) {
                    lastId = id
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    overlay.show(uri)
                }
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        contentResolver.unregisterContentObserver(observer)
        overlay.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

object ServiceControl {
    fun ready(ctx: Context) =
        Settings.canDrawOverlays(ctx) &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_MEDIA_IMAGES) ==
            PackageManager.PERMISSION_GRANTED

    fun sync(ctx: Context) {
        val i = Intent(ctx, ScreenshotService::class.java)
        if (App.prefs.serviceOn.value && ready(ctx)) ContextCompat.startForegroundService(ctx, i)
        else ctx.stopService(i)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) ServiceControl.sync(context)
    }
}

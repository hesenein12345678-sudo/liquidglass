package com.xezn.shottranslate

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

// ---------------------------------------------------------------- helpers

private val PALETTE = listOf(
    0xFF0A84FF, 0xFF30D158, 0xFFFF9F0A, 0xFFFF375F, 0xFFBF5AF2,
    0xFF64D2FF, 0xFFFFD60A, 0xFF8E8E93, 0xFFFFFFFF, 0xFF000000
).map { it.toInt() }

private val BG_PALETTE = listOf(
    0xFF101428, 0xFF000000, 0xFF1B2A41, 0xFF2D1B4E,
    0xFF0B3D2E, 0xFF4A1C1C, 0xFFF2F2F7, 0xFFFFF4E5
).map { it.toInt() }

private class IconVariant(val bg: Color, val fg: Int)

private val APP_ICONS = listOf(
    IconVariant(Color(0xFF0A84FF), R.drawable.ic_fg_translate),
    IconVariant(Color(0xFF8E44EC), R.drawable.ic_fg_star),
    IconVariant(Color(0xFF1FA45B), R.drawable.ic_fg_bolt),
    IconVariant(Color(0xFF222233), R.drawable.ic_fg_translate)
)

private fun granted(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

private fun openUrl(ctx: Context, vararg urls: String) {
    for (u in urls) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (_: Exception) {
        }
    }
}

private fun setAppIcon(ctx: Context, idx: Int) {
    val pm = ctx.packageManager
    for (i in 0 until 4) {
        pm.setComponentEnabledSetting(
            ComponentName(ctx.packageName, "com.xezn.shottranslate.Alias$i"),
            if (i == idx) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}

private fun saveWallpaper(ctx: Context, uri: Uri) {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var s = 1
    while (bounds.outWidth / s > 2048 || bounds.outHeight / s > 2048) s *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = s }
    val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return
    File(ctx.filesDir, "bg.jpg").outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
    val p = App.prefs
    p.bgStamp.value = p.bgStamp.value + 1
    p.bgMode.value = 2
}

@Composable
private fun Screen(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
        content()
        Spacer(Modifier.height(140.dp))
    }
}

@Composable
private fun Title(text: String) = Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)

@Composable
private fun Sub(text: String) = Text(text, fontSize = 13.sp, modifier = Modifier.alpha(0.7f))

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) =
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })

@Composable
private fun ColorRow(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            val sel = c == selected
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        if (sel) 3.dp else 1.dp,
                        if (sel) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.5f),
                        CircleShape
                    )
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Column {
        Text("$label: $value", fontSize = 14.sp)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat()
        )
    }
}

@Composable
private fun StatusRow(label: String, ok: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✅  $label" else "⚠️  $label", Modifier.weight(1f), fontSize = 15.sp)
        if (!ok) OutlinedButton(onClick = onFix) { Text("منح") }
    }
}

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(backdrop: Backdrop) {
    val ctx = LocalContext.current
    val p = App.prefs
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) { tick++; onPauseOrDispose { } }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val mediaOk = remember(tick) { granted(ctx, Manifest.permission.READ_MEDIA_IMAGES) }
    val notifOk = remember(tick) { granted(ctx, Manifest.permission.POST_NOTIFICATIONS) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    LaunchedEffect(tick, p.serviceOn.value) { ServiceControl.sync(ctx) }

    Screen("مترجم اللقطات") {
        GlassCard(backdrop) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Title("تشغيل الاختصار")
                    Sub("يظهر الاختصار بعد كل لقطة شاشة فقط")
                }
                Switch(checked = p.serviceOn.value, onCheckedChange = {
                    p.serviceOn.value = it
                    if (it && !(overlayOk && mediaOk)) {
                        Toast.makeText(ctx, "امنح الصلاحيات أولاً", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
        GlassCard(backdrop) {
            Title("الصلاحيات")
            StatusRow("الظهور فوق التطبيقات", overlayOk) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            }
            StatusRow("الوصول للصور (لاكتشاف لقطة الشاشة)", mediaOk) {
                permLauncher.launch(arrayOf(Manifest.permission.READ_MEDIA_IMAGES))
            }
            StatusRow("الإشعارات (لإبقاء الخدمة شغّالة)", notifOk) {
                permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            }
            Sub("إذا ظهرت لك خيار \"وصول جزئي\" للصور اختر \"السماح بالكل\".")
        }
        GlassCard(backdrop) {
            Title("طريقة الاستخدام")
            Text("١) فعّل الخدمة وامنح الصلاحيات.\n٢) التقط لقطة شاشة لأي نص.\n٣) اضغط الاختصار اللي يطلع، والتطبيق يقرأ النص ويترجمه.", lineHeight = 24.sp)
        }
    }
}

// ---------------------------------------------------------------- Links

@Composable
fun LinksScreen(backdrop: Backdrop) {
    val ctx = LocalContext.current
    Screen("تواصل معي") {
        GlassButton(backdrop, "تيليجرام  @xezn9", R.drawable.ic_telegram) {
            openUrl(ctx, "tg://resolve?domain=xezn9", "https://t.me/xezn9")
        }
        GlassButton(backdrop, "تيك توك  @xezn99", R.drawable.ic_tiktok) {
            openUrl(ctx, "https://www.tiktok.com/@xezn99")
        }
    }
}

// ---------------------------------------------------------------- About

@Composable
fun AboutScreen(backdrop: Backdrop) {
    Screen("حول التطبيق") {
        GlassCard(backdrop) {
            Title("شنو يسوي التطبيق؟")
            Text(
                "كل ما تلتقط لقطة شاشة، يطلع اختصار صغير على الشاشة. تضغط عليه، والتطبيق يتعرف على النصوص الموجودة باللقطة (إنجليزي أو أي لغة ثانية) ويترجمها للعربية، أو أي لغة تختارها من الإعدادات.\n\nالتعرف على النص والترجمة يشتغلون داخل الجهاز. أول مرة لكل لغة يحتاج إنترنت لتحميل نموذج الترجمة بس.",
                lineHeight = 24.sp
            )
        }
        GlassCard(backdrop) {
            Title("ملاحظات")
            Text(
                "• التعرف على النص يدعم الحروف اللاتينية والصينية واليابانية والكورية والهندية.\n• الإصدار 1.0",
                lineHeight = 24.sp
            )
        }
    }
}

// ---------------------------------------------------------------- Settings

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(backdrop: Backdrop) {
    val ctx = LocalContext.current
    val p = App.prefs
    val scope = rememberCoroutineScope()
    val overlay = remember { OverlayManager(ctx.applicationContext) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) { saveWallpaper(ctx, uri) }
    }

    Screen("الإعدادات") {
        // theme
        GlassCard(backdrop) {
            Title("المظهر")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("تلقائي", p.theme.value == 0) { p.theme.value = 0 }
                Chip("فاتح", p.theme.value == 1) { p.theme.value = 1 }
                Chip("داكن", p.theme.value == 2) { p.theme.value = 2 }
            }
            Sub("لون الأزرار")
            ColorRow(PALETTE, p.accent.value) { p.accent.value = it }
        }

        // app icon
        GlassCard(backdrop) {
            Title("أيقونة التطبيق")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                APP_ICONS.forEachIndexed { i, v ->
                    val sel = p.appIcon.value == i
                    Box(
                        Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(v.bg)
                            .border(
                                if (sel) 3.dp else 0.dp,
                                if (sel) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                p.appIcon.value = i
                                setAppIcon(ctx, i)
                                Toast.makeText(ctx, "تم تغيير الأيقونة، قد تحتاج ثواني حتى تتحدث بالشاشة الرئيسية", Toast.LENGTH_LONG).show()
                            }
                    ) {
                        Image(painterResource(v.fg), null, Modifier.fillMaxSize())
                    }
                }
            }
        }

        // language
        GlassCard(backdrop) {
            Title("لغة الترجمة")
            Sub("النصوص راح تترجم إلى هاي اللغة")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LANGS.forEach { (code, name) ->
                    Chip(name, p.targetLang.value == code) { p.targetLang.value = code }
                }
            }
        }

        // background
        GlassCard(backdrop) {
            Title("خلفية التطبيق")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("افتراضية", p.bgMode.value == 0) { p.bgMode.value = 0 }
                Chip("لون", p.bgMode.value == 1) { p.bgMode.value = 1 }
                Chip("صورة", p.bgMode.value == 2) {
                    if (File(ctx.filesDir, "bg.jpg").exists()) p.bgMode.value = 2
                    else picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }
            if (p.bgMode.value == 1) ColorRow(BG_PALETTE, p.bgColor.value) { p.bgColor.value = it }
            Button(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text("اختيار صورة من المعرض") }
        }

        // shortcut
        GlassCard(backdrop) {
            Title("تخصيص الاختصار")
            Box(Modifier.fillMaxWidth().height(90.dp), contentAlignment = Alignment.Center) {
                val shape = when (p.ovShape.value) {
                    0 -> CircleShape
                    1 -> RoundedCornerShape(p.ovCorner.value.dp)
                    else -> RoundedCornerShape(0.dp)
                }
                Box(
                    Modifier
                        .size(p.ovSize.value.dp)
                        .alpha(p.ovAlpha.value / 100f)
                        .clip(shape)
                        .background(Color(p.ovColor.value)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painterResource(GLYPHS[p.ovIcon.value.coerceIn(0, GLYPHS.size - 1)]), null,
                        Modifier.size((p.ovSize.value * 0.5f).dp)
                    )
                }
            }
            Sub("اللون")
            ColorRow(PALETTE, p.ovColor.value) { p.ovColor.value = it }
            Sub("الشكل")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("دائري", p.ovShape.value == 0) { p.ovShape.value = 0 }
                Chip("حواف دائرية", p.ovShape.value == 1) { p.ovShape.value = 1 }
                Chip("حواف حادة", p.ovShape.value == 2) { p.ovShape.value = 2 }
            }
            if (p.ovShape.value == 1) LabeledSlider("استدارة الحواف", p.ovCorner.value, 4..30) { p.ovCorner.value = it }
            LabeledSlider("الحجم", p.ovSize.value, 40..90) { p.ovSize.value = it }
            LabeledSlider("الشفافية %", p.ovAlpha.value, 30..100) { p.ovAlpha.value = it }
            Sub("المكان")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("يمين", p.ovSide.value == 1) { p.ovSide.value = 1 }
                Chip("يسار", p.ovSide.value == 0) { p.ovSide.value = 0 }
            }
            LabeledSlider("الارتفاع %", p.ovY.value, 0..100) { p.ovY.value = it }
            Sub("الأيقونة الصغيرة")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GLYPHS.forEachIndexed { i, g ->
                    val sel = p.ovIcon.value == i
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(p.ovColor.value))
                            .border(
                                if (sel) 3.dp else 1.dp,
                                if (sel) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.5f),
                                CircleShape
                            )
                            .clickable { p.ovIcon.value = i },
                        contentAlignment = Alignment.Center
                    ) { Image(painterResource(g), null, Modifier.size(24.dp)) }
                }
            }
            Button(onClick = {
                if (Settings.canDrawOverlays(ctx)) overlay.show(null)
                else Toast.makeText(ctx, "امنح صلاحية الظهور فوق التطبيقات من الرئيسية", Toast.LENGTH_SHORT).show()
            }) { Text("معاينة على الشاشة") }
        }
    }
}

package com.xezn.shottranslate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { MainScreen() } }
    }
}

@Composable
fun MainScreen() {
    val backdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        TabItem("الرئيسية", R.drawable.ic_tab_home),
        TabItem("تواصل", R.drawable.ic_tab_link),
        TabItem("الإعدادات", R.drawable.ic_tab_settings),
        TabItem("حول", R.drawable.ic_tab_info)
    )
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) { AppBackground() }
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            when (tab) {
                0 -> HomeScreen(backdrop)
                1 -> LinksScreen(backdrop)
                2 -> SettingsScreen(backdrop)
                else -> AboutScreen(backdrop)
            }
        }
        GlassTabBar(backdrop, tabs, tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
    }
}

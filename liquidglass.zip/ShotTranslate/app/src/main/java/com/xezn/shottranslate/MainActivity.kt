package com.xezn.shottranslate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { MainScreen() } }
    }
}

private class TabData(val label: String, val icon: Int)

@Composable
fun MainScreen() {
    val backdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        TabData("الرئيسية", R.drawable.ic_tab_home),
        TabData("تواصل", R.drawable.ic_tab_link),
        TabData("الإعدادات", R.drawable.ic_tab_settings),
        TabData("حول", R.drawable.ic_tab_info)
    )
    val dark = LocalDark.current
    val accent = MaterialTheme.colorScheme.primary
    val idle = MaterialTheme.colorScheme.onSurface

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) { AppBackground() }
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            when (tab) {
                0 -> HomeScreen(backdrop)
                1 -> LinksScreen(backdrop)
                2 -> SettingsScreen(backdrop)
                else -> AboutScreen(backdrop)
            }
        }
        LiquidBottomTabs(
            selectedTabIndex = { tab },
            onTabSelected = { tab = it },
            backdrop = backdrop,
            tabsCount = tabs.size,
            accentColor = accent,
            isLightTheme = !dark,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            tabs.forEachIndexed { i, t ->
                LiquidBottomTab({ tab = i }) {
                    Icon(painterResource(t.icon), null, Modifier.size(24.dp), tint = idle)
                    Text(t.label, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = idle)
                }
            }
        }
    }
}

package com.xezn.shottranslate

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView

/** Draws the small floating shortcut shown after a screenshot. */
class OverlayManager(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var view: View? = null
    private val autoHide = Runnable { hide() }

    fun show(uri: Uri?) {
        if (!Settings.canDrawOverlays(ctx)) return
        hide()
        val p = App.prefs
        val d = ctx.resources.displayMetrics.density
        val size = (p.ovSize.value * d).toInt()

        val bg = GradientDrawable().apply {
            setColor(p.ovColor.value)
            when (p.ovShape.value) {
                0 -> shape = GradientDrawable.OVAL
                1 -> { shape = GradientDrawable.RECTANGLE; cornerRadius = p.ovCorner.value * d }
                else -> { shape = GradientDrawable.RECTANGLE; cornerRadius = 0f }
            }
            setStroke((1.5f * d).toInt(), 0x66FFFFFF)
        }
        val icon = ImageView(ctx).apply {
            setImageResource(GLYPHS[p.ovIcon.value.coerceIn(0, GLYPHS.size - 1)])
            val pad = (size * 0.25f).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val root = FrameLayout(ctx).apply {
            background = bg
            alpha = p.ovAlpha.value / 100f
            addView(icon, FrameLayout.LayoutParams(-1, -1))
            setOnClickListener {
                if (uri != null) {
                    ctx.startActivity(
                        Intent(ctx, ResultActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            .putExtra("uri", uri)
                    )
                }
                hide()
            }
        }

        val screenH = wm.currentWindowMetrics.bounds.height()
        val left = p.ovSide.value == 0
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (left) Gravity.START else Gravity.END)
            x = (8 * d).toInt()
            y = ((screenH - size) * p.ovY.value / 100f).toInt()
        }
        wm.addView(root, lp)
        view = root

        root.translationX = if (left) -size * 1.6f else size * 1.6f
        root.animate().translationX(0f).setDuration(250).start()
        handler.postDelayed(autoHide, 8000)
    }

    fun hide() {
        handler.removeCallbacks(autoHide)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}

#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends "openjdk-${JV}-jdk-headless"
ls /usr/lib/jvm
echo "DONE"

#!/bin/bash
set -e
SDK=/opt/android-sdk
mkdir -p "$SDK/cmdline-tools" "$SDK/licenses"
cd /tmp
echo "== downloading Android command-line tools =="
curl -fL --retry 3 -o cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
rm -rf "$SDK/cmdline-tools/latest" /tmp/cmdline-tools
unzip -q -o cmdtools.zip -d /tmp
mv /tmp/cmdline-tools "$SDK/cmdline-tools/latest"
rm -f cmdtools.zip
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-arm64
export PATH="$JAVA_HOME/bin:$PATH"
echo "== accepting licenses =="
yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" --licenses || true
test -f "$SDK/licenses/android-sdk-license" || { echo "licenses file is missing"; exit 1; }
echo "DONE"

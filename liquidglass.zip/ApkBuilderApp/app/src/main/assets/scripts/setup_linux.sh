#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/99android
echo 'Acquire::Retries "3";' >> /etc/apt/apt.conf.d/99android
echo 'Dpkg::Options { "--force-unsafe-io"; };' >> /etc/apt/apt.conf.d/99android
echo "== apt update =="
apt-get update
echo "== installing JDK 21, JDK 17 and tools (this takes a while) =="
apt-get install -y --no-install-recommends openjdk-21-jdk-headless openjdk-17-jdk-headless ca-certificates curl unzip zip git
echo "== looking for aapt2 (resource compiler) =="
apt-get install -y --no-install-recommends aapt || true
if ! command -v aapt2 >/dev/null 2>&1; then
  apt-get install -y --no-install-recommends android-sdk-build-tools || true
fi
AAPT2="$(command -v aapt2 || true)"
if [ -z "$AAPT2" ]; then
  AAPT2="$(find /usr -name aapt2 -type f 2>/dev/null | head -1 || true)"
fi
if [ -n "$AAPT2" ]; then
  ln -sf "$AAPT2" /usr/local/bin/aapt2
  echo "aapt2 found: $AAPT2"
else
  echo "WARNING: aapt2 was not found. Builds will stop at the resources step."
fi
echo "== installed JDKs =="
ls /usr/lib/jvm
touch /.ready-linux
echo "DONE"

#!/bin/bash
JV="${JAVA_VERSION:-21}"
JH="/usr/lib/jvm/java-${JV}-openjdk-arm64"
if [ ! -d "$JH" ]; then
  echo "JDK $JV is not installed. Installed JDKs:"
  ls /usr/lib/jvm 2>/dev/null
  exit 2
fi
export JAVA_HOME="$JH"
export ANDROID_HOME=/opt/android-sdk
export PATH="$JH/bin:/opt/tools/gradle-${GRADLE_VERSION}/bin:$PATH"
cd "/work/${PROJECT}" || exit 3
AAPT2="$(command -v aapt2 || true)"
EXTRA=""
if [ -n "$AAPT2" ]; then
  EXTRA="-Pandroid.aapt2FromMavenOverride=$AAPT2"
else
  echo "WARNING: aapt2 not found. Resource steps will fail."
fi
echo "java:   $(java -version 2>&1 | head -1)"
echo "gradle: ${GRADLE_VERSION}"
echo "aapt2:  ${AAPT2:-none}"
echo "=============================="
exec gradle ${GRADLE_ARGS} --no-daemon --console=plain \
  -Dorg.gradle.jvmargs="-Xmx3g -XX:MaxMetaspaceSize=768m -XX:+UseSerialGC" \
  -Dorg.gradle.workers.max=2 \
  -Pkotlin.compiler.execution.strategy=in-process \
  $EXTRA

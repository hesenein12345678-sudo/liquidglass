package com.example.apkbuilder

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

data class ProjectInfo(val name: String, val detectedJava: Int?)

object ProjectStore {
    fun list(ctx: Context): List<ProjectInfo> =
        EnvPaths.projects(ctx).listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith(".") }
            ?.sortedBy { it.name.lowercase() }
            ?.map { ProjectInfo(it.name, detectJava(it)) }
            ?: emptyList()

    fun detectJava(dir: File): Int? {
        val files = listOf("app/build.gradle.kts", "app/build.gradle", "build.gradle.kts", "build.gradle")
            .map { File(dir, it) }.filter { it.isFile }
        val found = mutableListOf<Int>()
        val patterns = listOf(
            Regex("VERSION_1_(\\d+)") to 1,
            Regex("VERSION_(\\d+)") to 1,
            Regex("JVM_1_(\\d+)") to 1,
            Regex("JVM_(\\d+)") to 1,
            Regex("jvmToolchain\\((\\d+)\\)") to 1,
            Regex("jvmTarget\\s*=\\s*\"(?:1\\.)?(\\d+)\"") to 1,
        )
        for (f in files) {
            val text = f.readText()
            for ((rx, g) in patterns) {
                rx.findAll(text).forEach { m -> m.groupValues[g].toIntOrNull()?.let { found += it } }
            }
        }
        return found.filter { it in 8..21 }.maxOrNull()
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return "project.zip"
    }

    /** Extracts a zip and returns the project folder name. Blocking. */
    fun importZip(ctx: Context, uri: Uri): String {
        val projects = EnvPaths.projects(ctx)
        val base = displayName(ctx, uri).removeSuffix(".zip").replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "project" }
        val tmp = File(projects, ".tmp_${System.currentTimeMillis()}")
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { Archives.extractZip(it, tmp) }
            val root = tmp.walkTopDown().maxDepth(4)
                .firstOrNull {
                    it.isFile && (it.name == "settings.gradle" || it.name == "settings.gradle.kts")
                }?.parentFile
                ?: throw IllegalStateException("settings.gradle not found inside the zip")
            var target = File(projects, base)
            var i = 2
            while (target.exists()) target = File(projects, "${base}_${i++}")
            if (!root.renameTo(target)) root.copyRecursively(target, true)
            return target.name
        } finally {
            deleteTree(tmp)
        }
    }
}

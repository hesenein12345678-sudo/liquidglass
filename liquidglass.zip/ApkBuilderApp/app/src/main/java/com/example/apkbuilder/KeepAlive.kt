package com.example.apkbuilder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

/** Keeps the app alive (notification + CPU wake lock) while a long download or build is running. */
class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra("text") ?: "Working..."
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("work", "Background work", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "work")
            .setContentTitle("APK Builder")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        if (wl == null) {
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "apkbuilder:work")
                .apply { acquire(3L * 60 * 60 * 1000) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}

object KeepAlive {
    private var count = 0

    @Synchronized
    fun start(ctx: Context, text: String) {
        count++
        try {
            ctx.startForegroundService(Intent(ctx, KeepAliveService::class.java).putExtra("text", text))
        } catch (e: Exception) {
            // not critical: the work still runs while the app is open
        }
    }

    @Synchronized
    fun stop(ctx: Context) {
        if (count > 0) count--
        if (count == 0) ctx.stopService(Intent(ctx, KeepAliveService::class.java))
    }
}

package com.example.apkbuilder

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.zip.ZipInputStream

object EnvPaths {
    fun root(ctx: Context) = File(ctx.filesDir, "env").apply { mkdirs() }
    fun home(ctx: Context) = File(ctx.filesDir, "home").apply { mkdirs() }
    fun projects(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun downloads(ctx: Context) = File(ctx.filesDir, "downloads").apply { mkdirs() }
}

fun deleteTree(f: File) {
    val p = f.toPath()
    if (!Files.exists(p, java.nio.file.LinkOption.NOFOLLOW_LINKS)) return
    Files.walk(p).use { s ->
        s.sorted(Comparator.reverseOrder<Path>()).forEach { Files.deleteIfExists(it) }
    }
}

object Shell {
    /** Runs a command with /system/bin/sh; returns the exit code. Blocking: call from a background thread. */
    fun run(
        ctx: Context,
        command: String,
        workDir: File?,
        extraEnv: Map<String, String> = emptyMap(),
        onProcess: (Process) -> Unit = {},
        onLine: (String) -> Unit
    ): Int {
        val pb = ProcessBuilder("/system/bin/sh", "-c", command)
        pb.directory(workDir ?: ctx.filesDir)
        pb.redirectErrorStream(true)
        val env = pb.environment()
        val root = EnvPaths.root(ctx)
        env["PATH"] = File(root, "bin").absolutePath + ":/system/bin:/system/xbin"
        env["HOME"] = EnvPaths.home(ctx).absolutePath
        env["TMPDIR"] = ctx.cacheDir.absolutePath
        env["ENV_ROOT"] = root.absolutePath
        env.putAll(extraEnv)
        val p = try {
            pb.start()
        } catch (e: IOException) {
            onLine("ERROR: ${e.message}")
            return -1
        }
        onProcess(p)
        p.inputStream.bufferedReader().forEachLine(onLine)
        return p.waitFor()
    }
}

object Net {
    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ApkBuilder/0.1")
        return c
    }

    fun getText(url: String): String {
        val c = open(url)
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Returns "HTTP code, size in MB" for a HEAD request. */
    fun head(url: String): Pair<Int, Long> {
        val c = open(url)
        c.requestMethod = "HEAD"
        return c.responseCode to c.contentLengthLong
    }

    fun download(url: String, dest: File, onProgress: (done: Long, total: Long) -> Unit) {
        val c = open(url)
        val code = c.responseCode
        if (code !in 200..299) throw IOException("HTTP $code for $url")
        val total = c.contentLengthLong
        dest.parentFile?.mkdirs()
        c.inputStream.use { ins ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = 0L
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - last > 300) {
                        onProgress(done, total)
                        last = now
                    }
                }
                onProgress(done, total)
            }
        }
    }
}

object Archives {
    private fun safeTarget(dest: File, name: String): File? {
        val destPath = dest.toPath().toAbsolutePath().normalize()
        val target = destPath.resolve(name).normalize()
        return if (target.startsWith(destPath) && target != destPath) target.toFile() else null
    }

    fun extractZip(input: InputStream, dest: File, markExec: Boolean = false): Int {
        dest.mkdirs()
        var count = 0
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val name = e.name.replace('\\', '/')
                val out = if (name.startsWith("__MACOSX/")) null else safeTarget(dest, name)
                if (out != null) {
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { zip.copyTo(it) }
                        if (markExec || out.name == "gradlew" || out.name.endsWith(".sh")) {
                            out.setExecutable(true, false)
                        }
                        count++
                    }
                }
                zip.closeEntry()
            }
        }
        return count
    }

    fun extractTar(input: InputStream, dest: File, onProgress: (Int) -> Unit = {}): Int {
        dest.mkdirs()
        var count = 0
        TarArchiveInputStream(input).use { tar ->
            while (true) {
                val e = (tar.nextEntry as TarArchiveEntry?) ?: break
                val name = e.name.removePrefix("./").trimEnd('/')
                if (name.isEmpty() || name == ".") continue
                if (e.isCharacterDevice || e.isBlockDevice || e.isFIFO) continue
                val out = safeTarget(dest, name) ?: continue
                try {
                    when {
                        e.isDirectory -> {
                            out.mkdirs()
                            out.setReadable(true, true)
                            out.setWritable(true, true)
                            out.setExecutable(true, true)
                        }
                        e.isSymbolicLink -> {
                            out.parentFile?.mkdirs()
                            Files.deleteIfExists(out.toPath())
                            Files.createSymbolicLink(out.toPath(), Paths.get(e.linkName))
                        }
                        e.isLink -> {
                            val src = safeTarget(dest, e.linkName.removePrefix("./"))
                            if (src != null && src.exists()) {
                                out.parentFile?.mkdirs()
                                src.copyTo(out, true)
                            }
                        }
                        else -> {
                            out.parentFile?.mkdirs()
                            Files.deleteIfExists(out.toPath())
                            FileOutputStream(out).use { tar.copyTo(it) }
                            out.setReadable(true, false)
                            out.setWritable(true, true)
                            if ((e.mode and 73) != 0) out.setExecutable(true, false)
                        }
                    }
                    count++
                } catch (ex: Exception) {
                    // ignore single-entry failures (device nodes, odd links)
                }
                if (count % 500 == 0) onProgress(count)
            }
        }
        return count
    }
}

package com.example.apkbuilder

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

object Output {
    /** Finds the newest APK produced by the build and copies it to a safe place. */
    fun collectApk(ctx: Context, projectDir: File, name: String): File? {
        val apk = projectDir.walkTopDown().maxDepth(10)
            .filter { it.isFile && it.extension == "apk" && it.path.contains("build/outputs/apk") }
            .maxByOrNull { it.lastModified() } ?: return null
        val outDir = File(ctx.filesDir, "outputs").apply { mkdirs() }
        val variant = apk.parentFile?.name ?: "build"
        val dest = File(outDir, "$name-$variant.apk")
        apk.copyTo(dest, true)
        return dest
    }

    fun install(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Copies the APK to Downloads/ApkBuilder and returns where it is. */
    fun saveToDownloads(ctx: Context, f: File): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/ApkBuilder")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the file in Downloads")
            ctx.contentResolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
            return "Download/ApkBuilder/" + f.name
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ApkBuilder")
        dir.mkdirs()
        f.copyTo(File(dir, f.name), true)
        return "Download/ApkBuilder/" + f.name
    }
}

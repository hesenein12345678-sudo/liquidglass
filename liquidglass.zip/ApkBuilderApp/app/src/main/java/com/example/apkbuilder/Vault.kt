package com.example.apkbuilder

import android.content.Context
import android.net.Uri
import java.io.File
import java.nio.file.Files
import java.nio.file.LinkOption
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class StorageItem(val name: String, val sizeMb: Long)

/**
 * Everything the app downloads (Gradle, Android SDK, Gradle libraries, archives) is stored in the app's
 * private folder and kept for good. The vault additionally lets you save a copy to a file you choose,
 * so it survives even if the app is uninstalled.
 */
object Vault {
    private fun roots(ctx: Context): List<File> = listOf(
        File(ctx.filesDir, "gradle-home/caches/modules-2"),
        File(ctx.filesDir, "android-sdk"),
        File(EnvPaths.root(ctx), "tools"),
        File(ctx.filesDir, "downloads"),
    )

    private fun regularFiles(root: File): List<File> {
        if (!root.exists()) return emptyList()
        return Files.walk(root.toPath()).use { s ->
            s.filter { Files.isRegularFile(it, LinkOption.NOFOLLOW_LINKS) }.map { it.toFile() }.toList()
        }
    }

    private fun sizeMb(f: File): Long = regularFiles(f).sumOf { it.length() } / 1024 / 1024

    fun summary(ctx: Context): List<StorageItem> {
        val items = mutableListOf<StorageItem>()
        Linux.toolsDir(ctx).listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach {
            items += StorageItem("Gradle " + it.name.removePrefix("gradle-"), sizeMb(it))
        }
        File(Linux.sdkDir(ctx), "platforms").listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach {
            items += StorageItem("SDK platform " + it.name, sizeMb(it))
        }
        File(Linux.sdkDir(ctx), "build-tools").listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach {
            items += StorageItem("SDK build-tools " + it.name, sizeMb(it))
        }
        items += StorageItem("Gradle libraries cache", sizeMb(File(Linux.gradleHome(ctx), "caches")))
        items += StorageItem("Saved downloads", sizeMb(EnvPaths.downloads(ctx)))
        return items
    }

    fun backup(ctx: Context, uri: Uri, report: (String) -> Unit): Int {
        var n = 0
        val base = ctx.filesDir.toPath()
        ctx.contentResolver.openOutputStream(uri)!!.use { os ->
            ZipOutputStream(os.buffered(256 * 1024)).use { zip ->
                zip.setLevel(1)
                for (r in roots(ctx)) {
                    for (f in regularFiles(r)) {
                        val rel = base.relativize(f.toPath()).toString().replace(File.separatorChar, '/')
                        zip.putNextEntry(ZipEntry(rel))
                        f.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        n++
                        if (n % 200 == 0) report("Saved $n files...")
                    }
                }
            }
        }
        return n
    }

    fun restore(ctx: Context, uri: Uri): Int {
        val n = ctx.contentResolver.openInputStream(uri)!!.use { Archives.extractZip(it, ctx.filesDir) }
        // programs need the "run" permission again
        regularFiles(File(EnvPaths.root(ctx), "tools")).forEach { it.setExecutable(true, false) }
        regularFiles(File(ctx.filesDir, "android-sdk/cmdline-tools")).forEach { it.setExecutable(true, false) }
        return n
    }
}

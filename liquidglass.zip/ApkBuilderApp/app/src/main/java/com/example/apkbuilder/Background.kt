package com.example.apkbuilder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke

/** Aurora-style background: soft glowing lights + thin rings and beams that the glass bends nicely. */
@Composable
fun AppBackground(isDark: Boolean) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (isDark) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF050816), Color(0xFF0B1B3A), Color(0xFF0F3D5E))))
        } else {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFEAF3FF), Color(0xFFD9ECFF), Color(0xFFF3E8FF))))
        }
        fun glow(color: Color, cx: Float, cy: Float, r: Float, a: Float) {
            val c = Offset(cx * w, cy * h)
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = a), Color.Transparent), center = c, radius = r * w),
                radius = r * w,
                center = c
            )
        }
        val k = if (isDark) 1f else 0.75f
        glow(Color(0xFF7C4DFF), 0.15f, 0.12f, 0.75f, 0.55f * k)
        glow(Color(0xFF00E5FF), 0.92f, 0.32f, 0.60f, 0.42f * k)
        glow(Color(0xFFFF4081), 0.18f, 0.62f, 0.55f, 0.34f * k)
        glow(Color(0xFF1DE9B6), 0.85f, 0.90f, 0.65f, 0.40f * k)
        glow(Color(0xFF2979FF), 0.45f, 0.45f, 0.50f, 0.25f * k)

        val line = (if (isDark) Color.White else Color(0xFF0A2A5E)).copy(alpha = if (isDark) 0.13f else 0.12f)
        drawCircle(line, w * 0.42f, Offset(w * 0.78f, h * 0.20f), style = Stroke(width = 2.5f))
        drawCircle(line, w * 0.28f, Offset(w * 0.78f, h * 0.20f), style = Stroke(width = 2.5f))
        drawCircle(line, w * 0.36f, Offset(w * 0.15f, h * 0.80f), style = Stroke(width = 2.5f))
        drawLine(line, Offset(0f, h * 0.35f), Offset(w, h * 0.05f), strokeWidth = 3f)
        drawLine(line, Offset(0f, h * 0.60f), Offset(w, h * 0.30f), strokeWidth = 3f)
        drawLine(line, Offset(0f, h * 0.95f), Offset(w, h * 0.65f), strokeWidth = 3f)
    }
}

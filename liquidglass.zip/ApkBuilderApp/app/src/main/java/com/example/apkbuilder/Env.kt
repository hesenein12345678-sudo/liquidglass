package com.example.apkbuilder

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.io.IOException
import java.util.zip.GZIPInputStream

data class ProbeResult(val title: String, val ok: Boolean?, val detail: String)

object Probe {
    fun run(ctx: Context): List<ProbeResult> {
        val out = mutableListOf<ProbeResult>()
        out += ProbeResult(
            "Android", null,
            "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) - ${Build.MANUFACTURER} ${Build.MODEL}"
        )
        val arm64 = Build.SUPPORTED_64_BIT_ABIS.contains("arm64-v8a")
        out += ProbeResult("CPU", arm64, Build.SUPPORTED_ABIS.joinToString())

        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val ramGb = mi.totalMem / 1024.0 / 1024.0 / 1024.0
        out += ProbeResult("RAM", ramGb >= 4.0, String.format("%.1f GB (recommended: 6 GB or more)", ramGb))

        val freeGb = ctx.filesDir.usableSpace / 1024.0 / 1024.0 / 1024.0
        out += ProbeResult("Free storage", freeGb >= 4.0, String.format("%.1f GB (need about 4 GB)", freeGb))

        out += ProbeResult("App targetSdk", ctx.applicationInfo.targetSdkVersion <= 28, "${ctx.applicationInfo.targetSdkVersion} (must be 28 to run binaries)")

        // Can we execute a binary stored in the app's private folder?
        try {
            val dir = File(ctx.filesDir, "probe").apply { mkdirs() }
            val copy = File(dir, "sh_copy")
            File("/system/bin/sh").inputStream().use { i -> copy.outputStream().use { o -> i.copyTo(o) } }
            copy.setExecutable(true, false)
            val p = ProcessBuilder(copy.absolutePath, "-c", "echo EXEC_OK; uname -m; uname -r")
                .redirectErrorStream(true).start()
            val txt = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            out += ProbeResult("Run binaries from app folder", txt.contains("EXEC_OK"), txt.replace("\n", " | "))
        } catch (e: IOException) {
            out += ProbeResult("Run binaries from app folder", false, e.message ?: "blocked")
        } catch (e: Exception) {
            out += ProbeResult("Run binaries from app folder", false, e.toString())
        }

        try {
            val (code, size) = Net.head("https://services.gradle.org/distributions/gradle-9.5.0-bin.zip")
            out += ProbeResult("Internet", code in 200..299, "HTTP $code, Gradle zip ${size / 1024 / 1024} MB")
        } catch (e: Exception) {
            out += ProbeResult("Internet", false, e.message ?: e.toString())
        }
        return out
    }
}

enum class Kind { BINARY, ZIP, TAR_GZ }

data class ComponentDef(
    val id: String,
    val name: String,
    val note: String,
    val defaultUrl: String,
    val kind: Kind,
    val dest: String,
)

object Components {
    val all = listOf(
        ComponentDef(
            "proot", "PRoot (aarch64)", "Runs a Linux system inside the app. Small file.",
            "https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static",
            Kind.BINARY, "bin/proot"
        ),
        ComponentDef(
            "rootfs", "Ubuntu 24.04 base (arm64)", "The Linux system (about 30 MB download). Latest version is found automatically.",
            "auto:ubuntu", Kind.TAR_GZ, "rootfs"
        ),
        ComponentDef(
            "gradle", "Gradle 9.5.0", "Build tool (about 140 MB).",
            "https://services.gradle.org/distributions/gradle-9.5.0-bin.zip", Kind.ZIP, "tools"
        ),
    )
}

object Installer {
    fun isInstalled(ctx: Context, d: ComponentDef): Boolean {
        val f = File(EnvPaths.root(ctx), d.dest)
        return when (d.kind) {
            Kind.BINARY -> f.isFile
            Kind.ZIP -> f.list()?.isNotEmpty() == true
            Kind.TAR_GZ -> File(f, "etc").exists()
        }
    }

    private fun resolveUbuntu(): String {
        val base = "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/"
        val html = Net.getText(base)
        val best = Regex("ubuntu-base-24\\.04\\.(\\d+)-base-arm64\\.tar\\.gz")
            .findAll(html)
            .map { it.value to it.groupValues[1].toInt() }
            .maxByOrNull { it.second }
            ?: throw IOException("Ubuntu rootfs file not found in the listing")
        return base + best.first
    }

    private fun mb(n: Long) = n / 1024 / 1024

    fun install(ctx: Context, d: ComponentDef, urlInput: String, report: (String, Float) -> Unit) {
        val url = if (urlInput.startsWith("auto:ubuntu")) {
            report("Looking for the latest version...", -1f)
            resolveUbuntu()
        } else urlInput
        val dl = File(EnvPaths.downloads(ctx), url.substringAfterLast('/'))
        report("Downloading...", 0f)
        Net.download(url, dl) { done, total ->
            val p = if (total > 0) done.toFloat() / total * 0.8f else -1f
            report("Downloading ${mb(done)} / ${if (total > 0) mb(total) else "?"} MB", p)
        }
        val root = EnvPaths.root(ctx)
        val dest = File(root, d.dest)
        when (d.kind) {
            Kind.BINARY -> {
                dest.parentFile?.mkdirs()
                dl.copyTo(dest, true)
                dest.setExecutable(true, false)
            }
            Kind.ZIP -> {
                report("Extracting...", 0.85f)
                deleteTree(dest)
                Archives.extractZip(dl.inputStream(), dest, markExec = true)
            }
            Kind.TAR_GZ -> {
                report("Extracting...", 0.85f)
                deleteTree(dest)
                GZIPInputStream(dl.inputStream().buffered()).use { gz ->
                    Archives.extractTar(gz, dest) { n -> report("Extracting... $n files", 0.9f) }
                }
            }
        }
        dl.delete()
    }
}

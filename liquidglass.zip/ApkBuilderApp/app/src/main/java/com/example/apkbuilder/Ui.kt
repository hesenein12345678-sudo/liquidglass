package com.example.apkbuilder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val LocalFg = compositionLocalOf { Color.White }
val Accent = Color(0xFF0088FF)

@Composable
fun T(
    text: String,
    size: Float = 14f,
    bold: Boolean = false,
    mono: Boolean = false,
    alpha: Float = 1f,
    modifier: Modifier = Modifier
) {
    BasicText(
        text,
        modifier,
        style = TextStyle(
            color = LocalFg.current.copy(alpha = alpha),
            fontSize = size.sp,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default
        )
    )
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(LocalFg.current.copy(alpha = 0.10f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    accent: Boolean = false
) {
    val fg = LocalFg.current
    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (accent) Accent else fg.copy(alpha = 0.14f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        BasicText(
            text,
            style = TextStyle(
                color = (if (accent) Color.White else fg).copy(alpha = if (enabled) 1f else 0.4f),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}

@Composable
fun GlassField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true
) {
    val fg = LocalFg.current
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = singleLine,
        textStyle = TextStyle(color = fg, fontSize = 14.sp, fontFamily = FontFamily.Monospace),
        cursorBrush = SolidColor(fg),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(fg.copy(alpha = 0.10f))
            .padding(12.dp),
        decorationBox = { inner ->
            if (value.isEmpty()) {
                BasicText(hint, style = TextStyle(color = fg.copy(alpha = 0.5f), fontSize = 14.sp))
            }
            inner()
        }
    )
}

@Composable
fun ProgressBar(progress: Float) {
    val fg = LocalFg.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(fg.copy(alpha = 0.15f))
    ) {
        if (progress >= 0f) {
            Box(
                Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .height(6.dp)
                    .background(Accent)
            )
        }
    }
}

@Composable
fun LogView(lines: List<String>, height: Dp = 300.dp) {
    val scroll = rememberScrollState()
    LaunchedEffect(lines.size) {
        delay(50)
        scroll.scrollTo(scroll.maxValue)
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.5f))
            .verticalScroll(scroll)
            .padding(10.dp)
    ) {
        BasicText(
            lines.takeLast(400).joinToString("\n").ifEmpty { "(empty)" },
            style = TextStyle(color = Color(0xFFE6E6E6), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        )
    }
}

@Composable
fun ScreenColumn(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        T(title, 30f, true)
        content()
    }
}

package com.example.apkbuilder

import android.content.Context
import java.io.File
import java.io.IOException
import java.nio.file.Files

/** Runs commands inside the Ubuntu system (via PRoot) and manages saved Gradle/SDK folders. */
object Linux {
    fun rootfs(ctx: Context) = File(EnvPaths.root(ctx), "rootfs")
    fun proot(ctx: Context) = File(EnvPaths.root(ctx), "bin/proot")
    fun linuxReady(ctx: Context) = File(rootfs(ctx), ".ready-linux").exists()
    fun sdkReady(ctx: Context) = File(ctx.filesDir, "android-sdk/licenses/android-sdk-license").exists()

    // These three folders live outside the Ubuntu system, so they are never lost when it is reinstalled.
    fun toolsDir(ctx: Context) = File(EnvPaths.root(ctx), "tools").apply { mkdirs() }
    fun gradleHome(ctx: Context) = File(ctx.filesDir, "gradle-home").apply { mkdirs() }
    fun sdkDir(ctx: Context) = File(ctx.filesDir, "android-sdk").apply { mkdirs() }
    fun gradleDir(ctx: Context, v: String) = File(toolsDir(ctx), "gradle-$v")

    fun asset(ctx: Context, name: String): String =
        ctx.assets.open("scripts/$name").bufferedReader().use { it.readText() }

    fun missingForBuild(ctx: Context): List<String> {
        val m = mutableListOf<String>()
        if (!proot(ctx).isFile) m += "PRoot"
        if (!File(rootfs(ctx), "etc").exists()) m += "Ubuntu system"
        if (!linuxReady(ctx)) m += "JDK + build tools"
        if (!sdkReady(ctx)) m += "Android SDK tools"
        return m
    }

    /** Reads the Gradle version the project asks for (gradle-wrapper.properties). */
    fun gradleVersionFor(projectDir: File): String {
        val f = File(projectDir, "gradle/wrapper/gradle-wrapper.properties")
        if (f.isFile) {
            val m = Regex("gradle-([0-9][0-9A-Za-z.\\-]*)-(?:bin|all)\\.zip").find(f.readText())
            if (m != null) return m.groupValues[1]
        }
        return "9.5.0"
    }

    /** Downloads the Gradle version once and keeps it forever on the phone. */
    fun ensureGradle(ctx: Context, version: String, log: (String) -> Unit) {
        if (File(gradleDir(ctx, version), "bin/gradle").isFile) {
            log("Gradle $version: already saved on this phone")
            return
        }
        val url = "https://services.gradle.org/distributions/gradle-$version-bin.zip"
        val dl = File(EnvPaths.downloads(ctx), "gradle-$version-bin.zip")
        log("Downloading Gradle $version ...")
        var lastStep = -1L
        Installer.fetch(url, dl) { done, total ->
            val mb = done / 1024 / 1024
            if (mb / 10 != lastStep) {
                lastStep = mb / 10
                log("  Gradle $version: $mb / ${if (total > 0) total / 1024 / 1024 else 0} MB")
            }
        }
        log("Extracting Gradle $version ...")
        Archives.extractZip(dl.inputStream(), toolsDir(ctx), markExec = true)
        if (!File(gradleDir(ctx, version), "bin/gradle").isFile) {
            throw IOException("Gradle $version was not extracted correctly")
        }
    }

    /** Runs a bash script inside Ubuntu. Blocking: call from a background thread. */
    fun run(
        ctx: Context,
        script: String,
        env: Map<String, String> = emptyMap(),
        workDir: String = "/root",
        noSeccomp: Boolean = true,
        onProcess: (Process) -> Unit = {},
        onLine: (String) -> Unit
    ): Int {
        val rf = rootfs(ctx)
        if (!proot(ctx).isFile) { onLine("PRoot is not installed."); return -2 }
        if (!File(rf, "etc").exists()) { onLine("The Ubuntu system is not installed."); return -2 }
        val tmpDir = File(ctx.cacheDir, "proot-tmp").apply { mkdirs() }
        try {
            for (d in listOf("tmp", "root/.gradle", "opt/android-sdk", "opt/tools", "work")) File(rf, d).mkdirs()
            File(rf, "tmp/apkb_run.sh").writeText(script.replace("\r\n", "\n"))
            val resolv = File(rf, "etc/resolv.conf")
            Files.deleteIfExists(resolv.toPath())
            resolv.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        } catch (e: Exception) {
            onLine("Could not prepare the Linux system: ${e.message}")
            return -3
        }
        val args = mutableListOf(
            proot(ctx).absolutePath, "--link2symlink", "-0", "-r", rf.absolutePath, "--kill-on-exit",
            "-b", "/dev", "-b", "/proc",
            "-b", gradleHome(ctx).absolutePath + ":/root/.gradle",
            "-b", sdkDir(ctx).absolutePath + ":/opt/android-sdk",
            "-b", toolsDir(ctx).absolutePath + ":/opt/tools",
            "-b", EnvPaths.projects(ctx).absolutePath + ":/work",
            "-w", workDir,
            "/usr/bin/env", "-i",
            "HOME=/root", "LANG=C.UTF-8", "TERM=xterm-256color", "TMPDIR=/tmp",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "ANDROID_HOME=/opt/android-sdk", "GRADLE_USER_HOME=/root/.gradle"
        )
        env.forEach { (k, v) -> args += "$k=$v" }
        args += listOf("/bin/bash", "/tmp/apkb_run.sh")

        val pb = ProcessBuilder(args)
        pb.directory(ctx.filesDir)
        pb.redirectErrorStream(true)
        pb.environment()["PROOT_TMP_DIR"] = tmpDir.absolutePath
        if (noSeccomp) pb.environment()["PROOT_NO_SECCOMP"] = "1"
        val p = try {
            pb.start()
        } catch (e: IOException) {
            onLine("Could not start PRoot: ${e.message}")
            return -1
        }
        onProcess(p)
        p.inputStream.bufferedReader().forEachLine(onLine)
        return p.waitFor()
    }
}

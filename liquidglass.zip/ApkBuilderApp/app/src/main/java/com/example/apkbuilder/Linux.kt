package com.example.apkbuilder

import android.content.Context
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Runs commands inside the Ubuntu system (via PRoot) and manages saved Gradle/SDK folders. */
object Linux {
    fun rootfs(ctx: Context) = File(EnvPaths.root(ctx), "rootfs")
    fun proot(ctx: Context) = File(EnvPaths.root(ctx), "bin/proot")
    fun linuxReady(ctx: Context) = File(rootfs(ctx), ".ready-linux").exists()
    fun sdkReady(ctx: Context) = File(ctx.filesDir, "android-sdk/licenses/android-sdk-license").exists()

    // These three folders live outside the Ubuntu system, so they are never lost when it is reinstalled.
    fun toolsDir(ctx: Context) = File(EnvPaths.root(ctx), "tools").apply { mkdirs() }
    fun gradleHome(ctx: Context) = File(ctx.filesDir, "gradle-home").apply { mkdirs() }
    fun sdkDir(ctx: Context) = File(ctx.filesDir, "android-sdk").apply { mkdirs() }
    fun gradleDir(ctx: Context, v: String) = File(toolsDir(ctx), "gradle-$v")

    fun asset(ctx: Context, name: String): String =
        ctx.assets.open("scripts/$name").bufferedReader().use { it.readText() }

    fun missingForBuild(ctx: Context): List<String> {
        val m = mutableListOf<String>()
        if (!proot(ctx).isFile) m += "PRoot"
        if (!File(rootfs(ctx), "etc").exists()) m += "Ubuntu system"
        if (!linuxReady(ctx)) m += "JDK + build tools"
        if (!sdkReady(ctx)) m += "Android SDK tools"
        return m
    }

    /** Reads the Gradle version the project asks for (gradle-wrapper.properties). */
    fun gradleVersionFor(projectDir: File): String {
        val f = File(projectDir, "gradle/wrapper/gradle-wrapper.properties")
        if (f.isFile) {
            val m = Regex("gradle-([0-9][0-9A-Za-z.\\-]*)-(?:bin|all)\\.zip").find(f.readText())
            if (m != null) return m.groupValues[1]
        }
        return "9.5.0"
    }

    /** Downloads the Gradle version once and keeps it forever on the phone. */
    fun ensureGradle(ctx: Context, version: String, log: (String) -> Unit) {
        if (File(gradleDir(ctx, version), "bin/gradle").isFile) {
            log("Gradle $version: already saved on this phone")
            return
        }
        val url = "https://services.gradle.org/distributions/gradle-$version-bin.zip"
        val dl = File(EnvPaths.downloads(ctx), "gradle-$version-bin.zip")
        log("Downloading Gradle $version ...")
        var lastStep = -1L
        Installer.fetch(url, dl) { done, total ->
            val mb = done / 1024 / 1024
            if (mb / 10 != lastStep) {
                lastStep = mb / 10
                log("  Gradle $version: $mb / ${if (total > 0) total / 1024 / 1024 else 0} MB")
            }
        }
        log("Extracting Gradle $version ...")
        Archives.extractZip(dl.inputStream(), toolsDir(ctx), markExec = true)
        if (!File(gradleDir(ctx, version), "bin/gradle").isFile) {
            throw IOException("Gradle $version was not extracted correctly")
        }
    }

    // PRoot behaves differently on different phones, so several settings are tried automatically
    // and the first one that really starts Linux is remembered.
    data class ProotCfg(
        val id: Int,
        val label: String,
        val link2symlink: Boolean,
        val killOnExit: Boolean,
        val noSeccomp: Boolean
    )

    val configs = listOf(
        ProotCfg(0, "standard", true, true, true),
        ProotCfg(1, "without kill-on-exit", true, false, true),
        ProotCfg(2, "with seccomp", true, true, false),
        ProotCfg(3, "without link2symlink", false, true, true),
        ProotCfg(4, "bare minimum", false, false, true),
        ProotCfg(5, "bare minimum + seccomp", false, false, false),
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("apkbuilder", Context.MODE_PRIVATE)

    fun activeCfg(ctx: Context): ProotCfg {
        val id = prefs(ctx).getInt("linux_cfg", -1)
        return configs.firstOrNull { it.id == id }
            ?: configs[0].copy(noSeccomp = prefs(ctx).getBoolean("no_seccomp", true))
    }

    /** Runs a bash script inside Ubuntu. Blocking: call from a background thread. */
    fun run(
        ctx: Context,
        script: String,
        env: Map<String, String> = emptyMap(),
        workDir: String = "/root",
        noSeccomp: Boolean = true,
        onProcess: (Process) -> Unit = {},
        onLine: (String) -> Unit
    ): Int {
        if (prefs(ctx).getInt("linux_cfg", -1) < 0) {
            onLine("Testing PRoot settings (first time only)...")
            if (!detect(ctx, onLine)) return -5
        }
        return runWith(ctx, activeCfg(ctx), script, env, workDir, onProcess, onLine)
    }

    fun runWith(
        ctx: Context,
        cfg: ProotCfg,
        script: String,
        env: Map<String, String>,
        workDir: String,
        onProcess: (Process) -> Unit,
        onLine: (String) -> Unit,
        timeoutSec: Long = 0
    ): Int {
        val rf = rootfs(ctx)
        if (!proot(ctx).isFile) { onLine("PRoot is not installed."); return -2 }
        if (!File(rf, "etc").exists()) { onLine("The Ubuntu system is not installed."); return -2 }
        val tmpDir = File(ctx.cacheDir, "proot-tmp").apply { mkdirs() }
        try {
            for (d in listOf("tmp", "root/.gradle", "opt/android-sdk", "opt/tools", "work")) File(rf, d).mkdirs()
            File(rf, "tmp/apkb_run.sh").writeText(script.replace("\r\n", "\n"))
            val resolv = File(rf, "etc/resolv.conf")
            Files.deleteIfExists(resolv.toPath())
            resolv.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        } catch (e: Exception) {
            onLine("Could not prepare the Linux system: ${e.message}")
            return -3
        }
        val args = mutableListOf(proot(ctx).absolutePath)
        if (cfg.link2symlink) args += "--link2symlink"
        args += listOf("-0", "-r", rf.absolutePath)
        if (cfg.killOnExit) args += "--kill-on-exit"
        args += listOf(
            "-b", "/dev", "-b", "/proc",
            "-b", gradleHome(ctx).absolutePath + ":/root/.gradle",
            "-b", sdkDir(ctx).absolutePath + ":/opt/android-sdk",
            "-b", toolsDir(ctx).absolutePath + ":/opt/tools",
            "-b", EnvPaths.projects(ctx).absolutePath + ":/work",
            "-w", workDir,
            "/usr/bin/env", "-i",
            "HOME=/root", "LANG=C.UTF-8", "TERM=xterm-256color", "TMPDIR=/tmp",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "ANDROID_HOME=/opt/android-sdk", "GRADLE_USER_HOME=/root/.gradle"
        )
        env.forEach { (k, v) -> args += "$k=$v" }
        args += listOf("/bin/bash", "/tmp/apkb_run.sh")

        val pb = ProcessBuilder(args)
        pb.directory(ctx.filesDir)
        pb.redirectErrorStream(true)
        pb.environment()["PROOT_TMP_DIR"] = tmpDir.absolutePath
        if (cfg.noSeccomp) pb.environment()["PROOT_NO_SECCOMP"] = "1"
        val p = try {
            pb.start()
        } catch (e: IOException) {
            onLine("Could not start PRoot: ${e.message}")
            return -1
        }
        onProcess(p)
        if (timeoutSec > 0) {
            thread(isDaemon = true) {
                if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) p.destroyForcibly()
            }
        }
        p.inputStream.bufferedReader().forEachLine(onLine)
        return p.waitFor()
    }

    /** Tries every PRoot setting with a tiny test; remembers the first one that works. */
    fun detect(ctx: Context, onLine: (String) -> Unit): Boolean {
        for (cfg in configs) {
            val out = StringBuilder()
            val code = runWith(
                ctx, cfg, "echo LINUX_OK; uname -m", emptyMap(), "/root", {},
                { l -> out.appendLine(l) }, 40
            )
            val text = out.toString().trim().replace("\n", " | ").take(300)
            onLine("  [${cfg.id}] ${cfg.label}: exit=$code $text")
            if (code == 0 && out.contains("LINUX_OK")) {
                prefs(ctx).edit().putInt("linux_cfg", cfg.id).apply()
                onLine("  ==> PRoot works with setting ${cfg.id} (${cfg.label})")
                return true
            }
        }
        onLine("  ==> PRoot could not start Linux with any setting. Send me this whole log.")
        return false
    }

    /** Prints everything needed to find out why Linux does not start. */
    fun diagnose(ctx: Context, onLine: (String) -> Unit) {
        val p = proot(ctx)
        onLine("--- files ---")
        onLine("proot: exists=${p.isFile} size=${p.length()} canExecute=${p.canExecute()}")
        try {
            val head = ByteArray(4)
            p.inputStream().use { it.read(head) }
            onLine("proot first bytes: " + head.joinToString(" ") { "%02x".format(it) } + "  (a real program starts with 7f 45 4c 46)")
        } catch (e: Exception) {
            onLine("proot read error: ${e.message}")
        }
        val rf = rootfs(ctx)
        onLine("ubuntu folder: ${rf.absolutePath} exists=${rf.exists()}")
        for (n in listOf(
            "bin", "lib", "usr/bin/env", "bin/bash", "usr/bin/bash", "etc/os-release",
            "lib/ld-linux-aarch64.so.1", "usr/lib/aarch64-linux-gnu/libc.so.6"
        )) {
            val f = File(rf, n)
            val link = try { Files.readSymbolicLink(f.toPath()).toString() } catch (e: Exception) { null }
            onLine("  $n: exists=${f.exists()}" + (if (link != null) "  link -> $link" else "") + (if (f.isFile) "  size=${f.length()}" else ""))
        }
        onLine("--- proot --version ---")
        try {
            val pb = ProcessBuilder(p.absolutePath, "--version").redirectErrorStream(true)
            pb.environment()["PROOT_TMP_DIR"] = File(ctx.cacheDir, "proot-tmp").apply { mkdirs() }.absolutePath
            val pr = pb.start()
            pr.inputStream.bufferedReader().forEachLine { onLine("  $it") }
            onLine("  exit=${pr.waitFor()}")
        } catch (e: Exception) {
            onLine("  could not run: ${e.message}")
        }
        onLine("--- trying PRoot settings ---")
        prefs(ctx).edit().remove("linux_cfg").apply()
        detect(ctx, onLine)
        onLine("--- end of diagnosis ---")
    }
}

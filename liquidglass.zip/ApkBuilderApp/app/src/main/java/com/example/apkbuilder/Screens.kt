package com.example.apkbuilder

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun ProjectsScreen(c: AppController) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.importProject(uri)
    }
    LaunchedEffect(Unit) { c.refreshProjects() }

    ScreenColumn("Projects") {
        GlassButton(
            if (c.importing) "Importing..." else "Import project (.zip)",
            onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
            enabled = !c.importing,
            accent = true
        )
        c.projectMessage?.let { T(it, 13f, alpha = 0.8f) }

        if (c.projects.isEmpty()) {
            GlassCard { T("No projects yet.\nImport a zip that contains settings.gradle(.kts).", alpha = 0.8f) }
        }
        c.projects.forEach { p ->
            val selected = p.name == c.selectedProject
            GlassCard(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .clickable { c.selectedProject = p.name }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        T((if (selected) "● " else "") + p.name, 17f, true)
                        T("Java detected: " + (p.detectedJava?.toString() ?: "unknown") + "   |   chosen: " + c.javaFor(p.name), 12f, alpha = 0.7f)
                    }
                    GlassButton("Delete", onClick = { c.deleteProject(p.name) })
                }
            }
        }
    }
}

@Composable
fun BuildScreen(c: AppController) {
    LaunchedEffect(Unit) { c.refreshProjects() }
    ScreenColumn("Build") {
        val name = c.selectedProject
        if (name == null) {
            GlassCard { T("No project selected. Import one from the Projects tab.", alpha = 0.8f) }
            return@ScreenColumn
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            c.projects.forEach { p ->
                GlassButton(p.name, onClick = { c.selectedProject = p.name }, accent = p.name == name)
            }
        }
        GlassCard {
            T("Java version for this project", 13f, alpha = 0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(8, 11, 17, 21).forEach { v ->
                    GlassButton("Java $v", onClick = { c.setJava(name, v) }, accent = c.javaFor(name) == v)
                }
            }
            T("Build command", 13f, alpha = 0.7f)
            GlassField(c.buildCommand, { c.updateBuildCommand(it) }, "command", singleLine = false)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(if (c.building) "Building..." else "Build", onClick = { c.startBuild() }, enabled = !c.building, accent = true)
                GlassButton("Stop", onClick = { c.stopBuild() }, enabled = c.building)
            }
        }
        LogView(c.buildLog, 340.dp)
    }
}

@Composable
fun EnvironmentScreen(c: AppController) {
    LaunchedEffect(Unit) { c.refreshComponents() }
    ScreenColumn("Environment") {
        GlassCard {
            T("1) Device check", 17f, true)
            T("Checks if your phone can run the build tools.", 12f, alpha = 0.7f)
            GlassButton(if (c.probing) "Checking..." else "Run device check", onClick = { c.runProbe() }, enabled = !c.probing, accent = true)
            c.probe.forEach { r ->
                val icon = when (r.ok) { true -> "✅"; false -> "❌"; null -> "ℹ️" }
                T("$icon ${r.title}", 14f, true)
                T(r.detail, 12f, mono = true, alpha = 0.75f)
            }
        }

        GlassCard {
            T("2) Install components", 17f, true)
            T("Install them in order, top to bottom.", 12f, alpha = 0.7f)
        }
        c.components.forEach { comp ->
            GlassCard {
                T((if (comp.installed) "✅ " else "") + comp.def.name, 16f, true)
                T(comp.def.note, 12f, alpha = 0.7f)
                GlassField(comp.url, { c.setUrl(comp, it) }, "download URL")
                if (comp.busy) ProgressBar(comp.progress)
                if (comp.status.isNotEmpty()) T(comp.status, 12f, mono = true, alpha = 0.8f)
                GlassButton(
                    if (comp.busy) "Working..." else if (comp.installed) "Reinstall" else "Install",
                    onClick = { c.install(comp) },
                    enabled = !comp.busy,
                    accent = !comp.installed
                )
            }
        }

        GlassCard {
            T("3) Test terminal", 17f, true)
            T("Try:  proot --version", 12f, alpha = 0.7f)
            GlassField(c.terminalCmd, { c.terminalCmd = it }, "command")
            GlassButton(if (c.terminalBusy) "Running..." else "Run", onClick = { c.runTerminal() }, enabled = !c.terminalBusy, accent = true)
            LogView(c.terminalLog, 220.dp)
        }
    }
}

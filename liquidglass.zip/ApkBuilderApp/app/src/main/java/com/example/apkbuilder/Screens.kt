package com.example.apkbuilder

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

@Composable
fun ProjectsScreen(c: AppController) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.importProject(uri)
    }
    LaunchedEffect(Unit) { c.refreshProjects() }

    ScreenColumn("Projects") {
        GlassButton(
            if (c.importing) "Importing..." else "Import project (.zip)",
            onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
            enabled = !c.importing,
            accent = true
        )
        c.projectMessage?.let { T(it, 13f, alpha = 0.8f) }

        if (c.projects.isEmpty()) {
            GlassCard { T("No projects yet.\nImport a zip that contains settings.gradle(.kts).", alpha = 0.8f) }
        }
        c.projects.forEach { p ->
            val selected = p.name == c.selectedProject
            GlassCard(
                Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .clickable { c.selectedProject = p.name }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        T((if (selected) "● " else "") + p.name, 17f, true)
                        T("Java detected: " + (p.detectedJava?.toString() ?: "unknown") + "   |   chosen: " + c.javaFor(p.name), 12f, alpha = 0.7f)
                    }
                    GlassButton("Delete", onClick = { c.deleteProject(p.name) })
                }
            }
        }
    }
}

@Composable
fun BuildScreen(c: AppController) {
    LaunchedEffect(Unit) { c.refreshProjects() }
    ScreenColumn("Build") {
        val name = c.selectedProject
        if (name == null) {
            GlassCard { T("No project selected. Import one from the Projects tab.", alpha = 0.8f) }
            return@ScreenColumn
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            c.projects.forEach { p ->
                GlassButton(p.name, onClick = { c.selectedProject = p.name }, accent = p.name == name)
            }
        }
        GlassCard {
            T("Java version (used to run Gradle)", 13f, alpha = 0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(8, 11, 17, 21).forEach { v ->
                    GlassButton("Java $v", onClick = { c.setJava(name, v) }, accent = c.javaFor(name) == v)
                }
            }
            T("Gradle tasks", 13f, alpha = 0.7f)
            GlassField(c.buildArgs, { c.updateBuildArgs(it) }, "assembleDebug")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton(
                    if (c.building) "Building..." else "Build",
                    onClick = { c.startBuild() },
                    enabled = !c.building && !c.working,
                    accent = true
                )
                GlassButton("Stop", onClick = { c.stopBuild() }, enabled = c.building)
            }
        }
        LogView(c.buildLog, 340.dp)
        val apk = c.lastApk
        if (apk != null) {
            GlassCard {
                T("✅ APK ready", 17f, true)
                T(apk.name + "  (" + apk.length() / 1024 + " KB)", 12f, mono = true, alpha = 0.8f)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("Install", onClick = { c.installApk() }, accent = true)
                    GlassButton("Save to Downloads", onClick = { c.saveApk() })
                }
            }
        }
        c.outputMessage?.let { T(it, 13f, alpha = 0.85f) }
    }
}

@Composable
fun EnvironmentScreen(c: AppController) {
    LaunchedEffect(Unit) { c.refreshComponents() }
    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) c.backupLibs(uri)
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.restoreLibs(uri)
    }
    ScreenColumn("Environment") {
        GlassCard {
            T("Setup", 20f, true)
            T("Installs everything needed to build real apps on this phone (needs internet and about 2 GB). Anything downloaded is saved and never downloaded twice.", 12f, alpha = 0.75f)
            GlassButton(
                if (c.working) "Working..." else "Install everything",
                onClick = { c.installAll() },
                enabled = !c.working,
                accent = true
            )
        }
        c.components.forEach { comp ->
            GlassCard {
                T((if (comp.installed) "✅ " else "⬜ ") + comp.def.name, 16f, true)
                T(comp.def.note, 12f, alpha = 0.7f)
                if (comp.def.kind != Kind.SCRIPT) {
                    GlassField(comp.url, { c.setUrl(comp, it) }, "download URL")
                }
                if (comp.busy) ProgressBar(comp.progress)
                if (comp.status.isNotEmpty()) T(comp.status, 12f, mono = true, alpha = 0.8f)
                GlassButton(
                    if (comp.busy) "Working..." else if (comp.installed) "Reinstall" else "Install",
                    onClick = { c.install(comp) },
                    enabled = !comp.busy && !c.working,
                    accent = !comp.installed
                )
            }
        }
        GlassCard {
            T("Extra Java versions", 16f, true)
            T("For old projects. Java 17 and 21 are already included.", 12f, alpha = 0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Add JDK 8", onClick = { c.installJdk(8) }, enabled = !c.working)
                GlassButton("Add JDK 11", onClick = { c.installJdk(11) }, enabled = !c.working)
            }
        }
        T("Setup log", 15f, true)
        LogView(c.setupLog, 260.dp)

        GlassCard {
            T("Saved on this phone", 17f, true)
            T("Gradle versions, Android SDK parts and libraries stay here after every build and every app update.", 12f, alpha = 0.7f)
            if (c.storageItems.isEmpty()) T("(nothing yet)", 12f, alpha = 0.6f)
            c.storageItems.forEach { T(it.name + "  -  " + it.sizeMb + " MB", 12f, mono = true, alpha = 0.85f) }
            T("Make a copy outside the app (it survives uninstalling):", 12f, alpha = 0.7f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Backup", onClick = { backupPicker.launch("apkbuilder-libs.zip") }, enabled = !c.vaultBusy)
                GlassButton("Restore", onClick = { restorePicker.launch(arrayOf("application/zip", "application/octet-stream")) }, enabled = !c.vaultBusy)
            }
            c.vaultMessage?.let { T(it, 12f, mono = true, alpha = 0.85f) }
        }

        GlassCard {
            T("Background work", 17f, true)
            T("Infinix may stop long builds. Allow the app to run in the background:", 12f, alpha = 0.7f)
            GlassButton("Allow background", onClick = { c.requestBatteryExemption() })
            GlassButton(
                "Compatibility mode: " + (if (c.noSeccomp) "ON" else "OFF"),
                onClick = { c.toggleSeccomp() }
            )
            T("ON is safer. OFF can be faster if it works on your phone.", 12f, alpha = 0.6f)
        }

        GlassCard {
            T("Terminal", 17f, true)
            T("Try:  java -version   or   gradle --version", 12f, alpha = 0.7f)
            GlassField(c.terminalCmd, { c.terminalCmd = it }, "command")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Run in Linux", onClick = { c.runTerminal(true) }, enabled = !c.terminalBusy, accent = true)
                GlassButton("Run on phone", onClick = { c.runTerminal(false) }, enabled = !c.terminalBusy)
            }
            LogView(c.terminalLog, 220.dp)
        }

        GlassCard {
            T("Device check", 17f, true)
            GlassButton(if (c.probing) "Checking..." else "Run device check", onClick = { c.runProbe() }, enabled = !c.probing)
            c.probe.forEach { r ->
                val icon = when (r.ok) { true -> "✅"; false -> "❌"; null -> "ℹ️" }
                T("$icon ${r.title}", 14f, true)
                T(r.detail, 12f, mono = true, alpha = 0.75f)
            }
        }
    }
}

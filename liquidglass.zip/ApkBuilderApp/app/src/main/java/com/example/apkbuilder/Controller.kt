package com.example.apkbuilder

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ComponentUi(val def: ComponentDef, initialUrl: String) {
    var url by mutableStateOf(initialUrl)
    var status by mutableStateOf("")
    var progress by mutableFloatStateOf(-1f)
    var busy by mutableStateOf(false)
    var installed by mutableStateOf(false)
}

class AppController(private val ctx: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val prefs = ctx.getSharedPreferences("apkbuilder", Context.MODE_PRIVATE)

    // ---- projects ----
    val projects = mutableStateListOf<ProjectInfo>()
    var selectedProject by mutableStateOf<String?>(null)
    var projectMessage by mutableStateOf<String?>(null)
    var importing by mutableStateOf(false)
    private val javaChoice = mutableStateMapOf<String, Int>()

    fun javaFor(name: String): Int =
        javaChoice[name] ?: prefs.getInt("java_$name", projects.firstOrNull { it.name == name }?.detectedJava ?: 17)

    fun setJava(name: String, v: Int) {
        javaChoice[name] = v
        prefs.edit().putInt("java_$name", v).apply()
    }

    fun refreshProjects() {
        val list = ProjectStore.list(ctx)
        projects.clear()
        projects.addAll(list)
        if (selectedProject == null || list.none { it.name == selectedProject }) {
            selectedProject = list.firstOrNull()?.name
        }
    }

    fun importProject(uri: Uri) {
        scope.launch {
            importing = true
            projectMessage = null
            val r = withContext(Dispatchers.IO) { runCatching { ProjectStore.importZip(ctx, uri) } }
            importing = false
            r.onSuccess {
                projectMessage = "Imported: $it"
                refreshProjects()
                selectedProject = it
            }.onFailure { projectMessage = "Import failed: ${it.message}" }
        }
    }

    fun deleteProject(name: String) {
        scope.launch {
            withContext(Dispatchers.IO) { deleteTree(File(EnvPaths.projects(ctx), name)) }
            refreshProjects()
        }
    }

    // ---- build ----
    val buildLog = mutableStateListOf<String>()
    var building by mutableStateOf(false)
    var buildCommand by mutableStateOf(prefs.getString("build_cmd", DEFAULT_BUILD_CMD) ?: DEFAULT_BUILD_CMD)
    private var currentProcess: Process? = null

    fun updateBuildCommand(v: String) {
        buildCommand = v
        prefs.edit().putString("build_cmd", v).apply()
    }

    private fun append(list: MutableList<String>, line: String) {
        list.add(line)
        if (list.size > 3000) repeat(500) { list.removeAt(0) }
    }

    fun startBuild() {
        val name = selectedProject ?: return
        if (building) return
        buildLog.clear()
        building = true
        val dir = File(EnvPaths.projects(ctx), name)
        val java = javaFor(name)
        scope.launch {
            append(buildLog, "> Project: $name   Java: $java")
            append(buildLog, "> $buildCommand")
            val code = withContext(Dispatchers.IO) {
                Shell.run(
                    ctx, buildCommand, dir,
                    mapOf("PROJECT_DIR" to dir.absolutePath, "JAVA_VERSION" to java.toString()),
                    onProcess = { currentProcess = it }
                ) { line -> scope.launch { append(buildLog, line) } }
            }
            append(buildLog, "> Finished with exit code $code")
            currentProcess = null
            building = false
        }
    }

    fun stopBuild() {
        currentProcess?.destroy()
    }

    // ---- environment ----
    val probe = mutableStateListOf<ProbeResult>()
    var probing by mutableStateOf(false)
    val components = Components.all.map {
        ComponentUi(it, prefs.getString("url_${it.id}", null) ?: it.defaultUrl)
    }
    val terminalLog = mutableStateListOf<String>()
    var terminalBusy by mutableStateOf(false)
    var terminalCmd by mutableStateOf("proot --version")

    fun refreshComponents() {
        components.forEach { it.installed = Installer.isInstalled(ctx, it.def) }
    }

    fun setUrl(c: ComponentUi, v: String) {
        c.url = v
        prefs.edit().putString("url_${c.def.id}", v).apply()
    }

    fun runProbe() {
        if (probing) return
        probing = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { Probe.run(ctx) }
            probe.clear()
            probe.addAll(r)
            probing = false
        }
    }

    fun install(c: ComponentUi) {
        if (c.busy) return
        scope.launch {
            c.busy = true
            c.progress = 0f
            try {
                withContext(Dispatchers.IO) {
                    Installer.install(ctx, c.def, c.url) { s, p ->
                        c.status = s
                        c.progress = p
                    }
                }
                c.status = "Installed"
            } catch (e: Exception) {
                c.status = "Failed: ${e.message}"
            } finally {
                c.busy = false
                c.progress = -1f
                c.installed = Installer.isInstalled(ctx, c.def)
            }
        }
    }

    fun runTerminal() {
        if (terminalBusy || terminalCmd.isBlank()) return
        terminalBusy = true
        val cmd = terminalCmd
        scope.launch {
            append(terminalLog, "$ $cmd")
            val code = withContext(Dispatchers.IO) {
                Shell.run(ctx, cmd, EnvPaths.home(ctx)) { line -> scope.launch { append(terminalLog, line) } }
            }
            append(terminalLog, "[exit $code]")
            terminalBusy = false
        }
    }

    companion object {
        const val DEFAULT_BUILD_CMD = "echo \"Build engine is not installed yet (next step).\"; echo \"Project: \$PROJECT_DIR\"; echo \"Java: \$JAVA_VERSION\""
    }
}

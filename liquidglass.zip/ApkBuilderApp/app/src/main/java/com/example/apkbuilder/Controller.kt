package com.example.apkbuilder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ComponentUi(val def: ComponentDef, initialUrl: String) {
    var url by mutableStateOf(initialUrl)
    var status by mutableStateOf("")
    var progress by mutableFloatStateOf(-1f)
    var busy by mutableStateOf(false)
    var installed by mutableStateOf(false)
}

class AppController(private val ctx: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val prefs = ctx.getSharedPreferences("apkbuilder", Context.MODE_PRIVATE)

    // ---- projects ----
    val projects = mutableStateListOf<ProjectInfo>()
    var selectedProject by mutableStateOf<String?>(null)
    var projectMessage by mutableStateOf<String?>(null)
    var importing by mutableStateOf(false)
    private val javaChoice = mutableStateMapOf<String, Int>()

    fun javaFor(name: String): Int =
        javaChoice[name] ?: prefs.getInt("java_$name", projects.firstOrNull { it.name == name }?.detectedJava ?: 17)

    fun setJava(name: String, v: Int) {
        javaChoice[name] = v
        prefs.edit().putInt("java_$name", v).apply()
    }

    fun refreshProjects() {
        val list = ProjectStore.list(ctx)
        projects.clear()
        projects.addAll(list)
        if (selectedProject == null || list.none { it.name == selectedProject }) {
            selectedProject = list.firstOrNull()?.name
        }
    }

    fun importProject(uri: Uri) {
        scope.launch {
            importing = true
            projectMessage = null
            val r = withContext(Dispatchers.IO) { runCatching { ProjectStore.importZip(ctx, uri) } }
            importing = false
            r.onSuccess {
                projectMessage = "Imported: $it"
                refreshProjects()
                selectedProject = it
            }.onFailure { projectMessage = "Import failed: ${it.message}" }
        }
    }

    fun deleteProject(name: String) {
        scope.launch {
            withContext(Dispatchers.IO) { deleteTree(File(EnvPaths.projects(ctx), name)) }
            refreshProjects()
        }
    }

    // ---- build ----
    val buildLog = mutableStateListOf<String>()
    var building by mutableStateOf(false)
    var buildArgs by mutableStateOf(prefs.getString("build_args", "assembleDebug") ?: "assembleDebug")
    var lastApk by mutableStateOf<File?>(null)
    var outputMessage by mutableStateOf<String?>(null)
    private var currentProcess: Process? = null

    fun updateBuildArgs(v: String) {
        buildArgs = v
        prefs.edit().putString("build_args", v).apply()
    }

    private fun append(list: MutableList<String>, line: String) {
        list.add(line)
        if (list.size > 3000) repeat(500) { list.removeAt(0) }
    }

    /** Real build: Gradle + JDK + Android SDK running inside Ubuntu (PRoot). */
    fun startBuild() {
        val name = selectedProject ?: return
        if (building || working) return
        buildLog.clear()
        building = true
        lastApk = null
        outputMessage = null
        val dir = File(EnvPaths.projects(ctx), name)
        val jv = javaFor(name)
        val args = buildArgs.trim().ifEmpty { "assembleDebug" }
        KeepAlive.start(ctx, "Building $name")
        scope.launch {
            try {
                val log = { s: String -> scope.launch { append(buildLog, s) }; Unit }
                val code = withContext(Dispatchers.IO) {
                    val missing = Linux.missingForBuild(ctx)
                    if (missing.isNotEmpty()) {
                        log("Setup is not finished. Missing: " + missing.joinToString())
                        log("Open the Environment tab and press 'Install everything'.")
                        return@withContext -2
                    }
                    val gv = Linux.gradleVersionFor(dir)
                    try {
                        Linux.ensureGradle(ctx, gv, log)
                    } catch (e: Exception) {
                        log("Could not get Gradle $gv: ${e.message}")
                        return@withContext -4
                    }
                    log("Project: $name | Java $jv | Gradle $gv | tasks: $args")
                    Linux.run(
                        ctx, Linux.asset(ctx, "build.sh"),
                        mapOf(
                            "PROJECT" to name,
                            "JAVA_VERSION" to jv.toString(),
                            "GRADLE_VERSION" to gv,
                            "GRADLE_ARGS" to args
                        ),
                        "/work/$name", noSeccomp,
                        onProcess = { currentProcess = it },
                        onLine = log
                    )
                }
                if (code == 0) {
                    val apk = withContext(Dispatchers.IO) { Output.collectApk(ctx, dir, name) }
                    if (apk != null) {
                        lastApk = apk
                        append(buildLog, "> APK ready: ${apk.name} (${apk.length() / 1024} KB)")
                    } else {
                        append(buildLog, "> The build finished but no APK was found (try the task assembleDebug).")
                    }
                } else {
                    append(buildLog, "> Build failed (exit code $code)")
                    if (code == 137) append(buildLog, "> Android killed the build (not enough memory). Close other apps and try again.")
                }
            } finally {
                currentProcess = null
                building = false
                KeepAlive.stop(ctx)
                refreshStorage()
            }
        }
    }

    fun stopBuild() {
        currentProcess?.destroy()
    }

    fun installApk() {
        val f = lastApk ?: return
        try {
            Output.install(ctx, f)
        } catch (e: Exception) {
            outputMessage = "Install failed: ${e.message}"
        }
    }

    fun saveApk() {
        val f = lastApk ?: return
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Output.saveToDownloads(ctx, f) } }
            outputMessage = r.fold({ "Saved to $it" }, { "Save failed: ${it.message}" })
        }
    }

    // ---- environment ----
    val probe = mutableStateListOf<ProbeResult>()
    var probing by mutableStateOf(false)
    val components = Components.all.map {
        ComponentUi(it, prefs.getString("url_${it.id}", null) ?: it.defaultUrl)
    }
    val terminalLog = mutableStateListOf<String>()
    var terminalBusy by mutableStateOf(false)
    var terminalCmd by mutableStateOf("java -version")
    val setupLog = mutableStateListOf<String>()
    var working by mutableStateOf(false)
    var noSeccomp by mutableStateOf(prefs.getBoolean("no_seccomp", true))
    val storageItems = mutableStateListOf<StorageItem>()
    var vaultBusy by mutableStateOf(false)
    var vaultMessage by mutableStateOf<String?>(null)

    fun toggleSeccomp() {
        noSeccomp = !noSeccomp
        prefs.edit().putBoolean("no_seccomp", noSeccomp).apply()
    }

    fun refreshComponents() {
        components.forEach { it.installed = Installer.isInstalled(ctx, it.def) }
        refreshStorage()
    }

    fun refreshStorage() {
        scope.launch {
            val s = withContext(Dispatchers.IO) { runCatching { Vault.summary(ctx) }.getOrDefault(emptyList()) }
            storageItems.clear()
            storageItems.addAll(s)
        }
    }

    fun setUrl(c: ComponentUi, v: String) {
        c.url = v
        prefs.edit().putString("url_${c.def.id}", v).apply()
    }

    fun runProbe() {
        if (probing) return
        probing = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { Probe.run(ctx) }
            probe.clear()
            probe.addAll(r)
            probing = false
        }
    }

    private suspend fun installOne(c: ComponentUi): Boolean {
        c.busy = true
        c.progress = 0f
        c.status = "Starting..."
        var ok = true
        try {
            withContext(Dispatchers.IO) {
                Installer.install(
                    ctx, c.def, c.url, noSeccomp,
                    { s, p -> c.status = s; c.progress = p },
                    { line -> scope.launch { append(setupLog, line) } }
                )
            }
            c.status = "Installed"
        } catch (e: Exception) {
            c.status = "Failed: ${e.message}"
            ok = false
        } finally {
            c.busy = false
            c.progress = -1f
            c.installed = Installer.isInstalled(ctx, c.def)
        }
        return ok
    }

    fun install(c: ComponentUi) {
        if (working || c.busy) return
        scope.launch {
            working = true
            KeepAlive.start(ctx, "Installing " + c.def.name)
            try {
                installOne(c)
            } finally {
                KeepAlive.stop(ctx)
                working = false
                refreshStorage()
            }
        }
    }

    fun installAll() {
        if (working) return
        scope.launch {
            working = true
            KeepAlive.start(ctx, "Installing build tools")
            try {
                for (c in components) {
                    if (c.installed) continue
                    if (!installOne(c)) break
                }
            } finally {
                KeepAlive.stop(ctx)
                working = false
                refreshStorage()
            }
        }
    }

    fun installJdk(v: Int) {
        if (working) return
        scope.launch {
            working = true
            KeepAlive.start(ctx, "Installing JDK $v")
            try {
                append(setupLog, "===== JDK $v =====")
                val code = withContext(Dispatchers.IO) {
                    Linux.run(
                        ctx, Linux.asset(ctx, "install_jdk.sh"), mapOf("JV" to v.toString()),
                        noSeccomp = noSeccomp,
                        onLine = { line -> scope.launch { append(setupLog, line) } }
                    )
                }
                append(setupLog, "[JDK $v finished with exit code $code]")
            } finally {
                KeepAlive.stop(ctx)
                working = false
            }
        }
    }

    fun runTerminal(inLinux: Boolean) {
        if (terminalBusy || terminalCmd.isBlank()) return
        terminalBusy = true
        val cmd = terminalCmd
        scope.launch {
            append(terminalLog, (if (inLinux) "linux$ " else "$ ") + cmd)
            val code = withContext(Dispatchers.IO) {
                val sink = { line: String -> scope.launch { append(terminalLog, line) }; Unit }
                if (inLinux) Linux.run(ctx, cmd, noSeccomp = noSeccomp, onLine = sink)
                else Shell.run(ctx, cmd, EnvPaths.home(ctx), onLine = sink)
            }
            append(terminalLog, "[exit $code]")
            terminalBusy = false
        }
    }

    fun backupLibs(uri: Uri) {
        if (vaultBusy) return
        scope.launch {
            vaultBusy = true
            vaultMessage = "Saving..."
            val r = withContext(Dispatchers.IO) { runCatching { Vault.backup(ctx, uri) { m -> vaultMessage = m } } }
            vaultMessage = r.fold({ "Saved $it files" }, { "Backup failed: ${it.message}" })
            vaultBusy = false
        }
    }

    fun restoreLibs(uri: Uri) {
        if (vaultBusy) return
        scope.launch {
            vaultBusy = true
            vaultMessage = "Restoring..."
            val r = withContext(Dispatchers.IO) { runCatching { Vault.restore(ctx, uri) } }
            vaultMessage = r.fold({ "Restored $it files" }, { "Restore failed: ${it.message}" })
            vaultBusy = false
            refreshComponents()
        }
    }

    fun requestBatteryExemption() {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e2: Exception) {
            }
        }
    }
}

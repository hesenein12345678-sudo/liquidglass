#!/usr/bin/env bash
set -euo pipefail

# Pull the real Backdrop Catalog implementation (Apache-2.0) into the Android source tree.
# The upstream kmp branch contains the original Catalog component implementations.
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
git clone --depth 1 --branch kmp https://github.com/Kyant0/AndroidLiquidGlass.git "$TMP_DIR/upstream"

DEST="app/src/main/java/com/kyant/backdrop/catalog"
mkdir -p "$DEST/components" "$DEST/utils"

cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/components/LiquidBottomTabs.kt" "$DEST/components/"
cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/components/LiquidBottomTab.kt" "$DEST/components/"
cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/components/LiquidButton.kt" "$DEST/components/"
cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/components/LiquidToggle.kt" "$DEST/components/"
cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/utils/DampedDragAnimation.kt" "$DEST/utils/"
cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/utils/InteractiveHighlight.kt" "$DEST/utils/"
cp "$TMP_DIR/upstream/app/src/commonMain/kotlin/com/kyant/backdrop/catalog/utils/DragGestureInspector.kt" "$DEST/utils/"

# The Catalog source calls awaitFrame(), which is not available in the Android
# Compose runtime used by this app. Use Compose's supported withFrameNanos API.
DAMPED="$DEST/utils/DampedDragAnimation.kt"
if grep -q 'awaitFrame()' "$DAMPED"; then
  sed -i 's/awaitFrame()/withFrameNanos { }/g' "$DAMPED"
fi
if ! grep -q '^import androidx.compose.runtime.withFrameNanos$' "$DAMPED"; then
  sed -i '/^import androidx.compose.runtime.snapshotFlow$/a import androidx.compose.runtime.withFrameNanos' "$DAMPED"
fi
if grep -q 'awaitFrame()' "$DAMPED"; then
  echo "ERROR: awaitFrame compatibility patch did not apply." >&2
  exit 1
fi

# Keep the upstream Apache 2.0 license and attribution alongside the imported code.
mkdir -p third_party
cp "$TMP_DIR/upstream/LICENSE" "third_party/BACKDROP_APACHE_2.0_LICENSE"
echo "Imported original Backdrop Catalog LiquidBottomTabs/LiquidButton source."

# Luma Translate — إصلاح بناء GitHub Actions

## مهم جداً حتى يختفي خطأ `Unresolved reference catalog`
إذا كان مستودع GitHub عندك يحتوي ملفاً اسمه `liquidglass.zip`، فإن GitHub يشغّل ملف الـ workflow الموجود أصلاً في المستودع، وليس ملف workflow الموجود داخل ZIP. لذلك يجب استبدال الملف النشط في المستودع أيضاً.

### الطريقة الموصى بها
1. فك ضغط هذا الملف على هاتفك.
2. ارفع **محتويات مجلد `LumaTranslate` كلها** إلى جذر مستودع GitHub، مع إظهار الملفات المخفية وخصوصاً مجلد `.github`.
3. تأكد أن المسارات التالية موجودة في جذر المستودع:
   - `.github/workflows/android.yml`
   - `tools/fetch_backdrop_catalog_components.sh`
   - `settings.gradle.kts`
   - `app/build.gradle.kts`
4. إذا كنت تستخدم `liquidglass.zip` داخل مستودع منفصل، استبدل أيضاً الملف النشط `.github/workflows/android.yml` الموجود في **جذر المستودع الخارجي** بالنسخة الموجودة في هذا المشروع، ثم احفظ التغييرات.
5. من Actions شغّل `Build Android APK` من جديد. يجب أن تظهر خطوة `Import original Backdrop Catalog components` قبل `Build debug APK`.
6. نزّل `LumaTranslate-debug-apk` من Artifacts بعد نجاح البناء.

## ما الذي تم إصلاحه؟
- يحمّل الـ workflow ملفات `LiquidBottomTabs.kt` و`LiquidBottomTab.kt` الأصلية من Backdrop Catalog قبل البناء.
- يتحقق من وجود الملفين، ويتوقف برسالة واضحة إذا لم يتم استيرادهما، بدلاً من عرض أخطاء Kotlin مضللة.
- الشريط السفلي يستعمل المكوّن الأصلي وليس تقليداً بصرياً.

## ملاحظة
تحذير `Unable to strip the following libraries` الظاهر في السجل تحذير منفصل؛ أخطاء `catalog` و`LiquidBottomTabs` هي التي تشير إلى أن ملفات المكوّن لم تكن موجودة في مسار البناء. لم أتمكن من تشغيل بناء GitHub Actions من هنا، لذلك يجب تأكيد النجاح من سجل البناء الجديد.

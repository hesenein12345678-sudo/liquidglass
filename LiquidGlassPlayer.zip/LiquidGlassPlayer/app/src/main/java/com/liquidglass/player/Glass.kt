package com.liquidglass.player

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

@Composable
fun barTint(): Color {
    val i = AppSettings.barTint
    val base = if (i in AccentPalette.indices) AccentPalette[i].second else Color.White
    return base.copy(alpha = AppSettings.barAlpha)
}

/** Real Backdrop liquid glass (falls back to a simple translucent surface when disabled). */
@Composable
fun Modifier.glass(
    backdrop: LayerBackdrop,
    shape: Shape,
    blurDp: Float = AppSettings.barBlur,
    lensH: Float = AppSettings.barRefH,
    lensA: Float = AppSettings.barRefA,
    tint: Color = barTint(),
): Modifier {
    if (!AppSettings.liquid || Build.VERSION.SDK_INT < 31) {
        return this
            .clip(shape)
            .background(tint.copy(alpha = (tint.alpha + 0.14f).coerceAtMost(0.85f)))
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
    }
    return this.drawBackdrop(
        backdrop = backdrop,
        shape = { shape },
        effects = {
            vibrancy()
            if (Build.VERSION.SDK_INT >= 31 && blurDp > 0.5f) blur(blurDp.dp.toPx())
            if (Build.VERSION.SDK_INT >= 33 && lensH > 1f && lensA > 1f) lens(lensH.dp.toPx(), lensA.dp.toPx())
        },
        onDrawSurface = { drawRect(tint) },
    )
}

/** Cheap frosted card used for long lists (no backdrop sampling). */
@Composable
fun Modifier.frost(shape: Shape = RoundedCornerShape(22.dp)): Modifier {
    val dark = AppSettings.dark
    val fill = if (dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.55f)
    val rim = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = if (dark) 0.40f else 0.90f),
            Color.White.copy(alpha = if (dark) 0.06f else 0.30f),
        )
    )
    return this.clip(shape).background(fill).border(0.8.dp, rim, shape)
}

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

@Composable
fun Modifier.pressScale(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 420f),
        label = "press",
    )
    return this
        .graphicsLayer {
            scaleX = s
            scaleY = s
        }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun GlassButton(
    backdrop: LayerBackdrop,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val lensH = (size.value / 2f - 3f).coerceIn(2f, 14f)
    Box(
        modifier
            .size(size)
            .pressScale(onClick)
            .glass(backdrop, CircleShape, 6f, lensH, 14f, Color.White.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun GlassIconButton(backdrop: LayerBackdrop, icon: ImageVector, onClick: () -> Unit, size: Dp = 48.dp, tint: Color = AppSettings.onBg) {
    GlassButton(backdrop, onClick, size = size) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun GlassPill(
    backdrop: LayerBackdrop,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
) {
    val tint = if (accent) AppSettings.accent.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.14f)
    Box(
        modifier
            .height(46.dp)
            .pressScale(onClick)
            .glass(backdrop, CircleShape, 6f, 14f, 16f, tint),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (accent) Color.White else AppSettings.onBg,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 22.dp),
        )
    }
}

@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val track by animateColorAsState(
        if (checked) Color(0xFF34C759) else Color(0x66808088),
        label = "track",
    )
    val tw by animateDpAsState(if (pressed) 34.dp else 28.dp, label = "tw")
    val tx by animateDpAsState(
        targetValue = if (checked) 58.dp - tw else 0.dp,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "tx",
    )
    Box(
        Modifier
            .size(64.dp, 36.dp)
            .clip(CircleShape)
            .background(track)
            .clickable(interactionSource = src, indication = null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(
            Modifier
                .offset(x = tx)
                .size(tw, 30.dp)
                .clip(CircleShape)
                .background(Color.White)
                .border(0.5.dp, Color.Black.copy(alpha = 0.12f), CircleShape)
        )
    }
}

@Composable
fun GlassSlider(
    value: Float,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    onFinished: () -> Unit = {},
) {
    val cb by rememberUpdatedState(onChange)
    val fin by rememberUpdatedState(onFinished)
    BoxWithConstraints(
        modifier
            .height(30.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    cb((o.x / size.width).coerceIn(0f, 1f))
                    fin()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(onDragEnd = { fin() }) { change, _ ->
                    cb((change.position.x / size.width).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        val f = value.coerceIn(0f, 1f)
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape)
                .background(AppSettings.onBg.copy(alpha = 0.2f))
        )
        Box(
            Modifier
                .fillMaxWidth(f)
                .height(6.dp)
                .clip(CircleShape)
                .background(AppSettings.accent)
        )
        Box(
            Modifier
                .offset(x = (maxWidth - 22.dp) * f)
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White)
                .border(0.5.dp, Color.Black.copy(alpha = 0.15f), CircleShape)
        )
    }
}

@Composable
fun TrackArt(track: Track?, modifier: Modifier = Modifier, corner: Dp = 14.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, track?.key) {
        value = if (track == null) null else ArtLoader.load(ctx, track)
    }
    val shape = RoundedCornerShape(corner)
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(shape),
        )
    } else {
        Box(
            modifier
                .clip(shape)
                .background(Brush.linearGradient(listOf(AppSettings.accent.copy(alpha = 0.9f), AppSettings.accent.copy(alpha = 0.35f)))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Color.White, modifier = Modifier.fillMaxSize(0.45f))
        }
    }
}

@Composable
fun LiquidBottomTabs(
    backdrop: LayerBackdrop,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val tabs = listOf("Home" to Icons.Rounded.Home, "Library" to Icons.Rounded.LibraryMusic, "Settings" to Icons.Rounded.Settings)
    val tabsBackdrop = rememberLayerBackdrop()
    val pad = 6.dp
    val barH = 66.dp
    val select by rememberUpdatedState(onSelect)
    BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal = 22.dp).height(barH)) {
        val tabW = (maxWidth - pad * 2) / tabs.size
        val ix by animateDpAsState(
            targetValue = pad + tabW * selected,
            animationSpec = spring(dampingRatio = 0.62f, stiffness = 380f),
            label = "indicator",
        )
        fun indexAt(x: Float, widthPx: Float, padPx: Float): Int =
            (((x - padPx) / (widthPx - 2 * padPx)) * tabs.size).toInt().coerceIn(0, tabs.size - 1)

        Box(
            Modifier
                .fillMaxSize()
                .glass(backdrop, CircleShape)
                .pointerInput(Unit) {
                    detectTapGestures { o -> select(indexAt(o.x, size.width.toFloat(), pad.toPx())) }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, _ ->
                        select(indexAt(change.position.x, size.width.toFloat(), pad.toPx()))
                    }
                }
        ) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = pad)
                    .layerBackdrop(tabsBackdrop)
            ) {
                tabs.forEachIndexed { i, (label, icon) ->
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .graphicsLayer { alpha = if (i == selected) 0f else 1f },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(icon, null, tint = AppSettings.onBg.copy(alpha = 0.85f), modifier = Modifier.size(26.dp))
                        Text(label, color = AppSettings.onBg.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Box(
                Modifier
                    .offset(x = ix, y = pad)
                    .size(tabW, barH - pad * 2)
                    .glass(tabsBackdrop, CircleShape, 0f, 18f, 30f, AppSettings.accent.copy(alpha = 0.20f)),
                contentAlignment = Alignment.Center,
            ) {
                val (label, icon) = tabs[selected.coerceIn(0, tabs.size - 1)]
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, null, tint = AppSettings.accent, modifier = Modifier.size(26.dp))
                    Text(label, color = AppSettings.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

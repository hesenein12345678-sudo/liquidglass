package com.liquidglass.player

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.kyant.backdrop.backdrops.LayerBackdrop
import kotlinx.coroutines.launch

@Composable
fun ScreenHeader(title: String) {
    Text(
        title,
        color = AppSettings.onBg,
        fontSize = 34.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.statusBarsPadding().padding(top = 12.dp, bottom = 14.dp),
    )
}

@Composable
fun secondary(): Color = AppSettings.onBg.copy(alpha = 0.62f)

// ---------------------------------------------------------------- HOME

@Composable
fun HomeScreen(backdrop: LayerBackdrop, hasPermission: Boolean, requestPermission: () -> Unit) {
    val ctx = LocalContext.current
    val tracks = Library.local
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 210.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ScreenHeader("Home") }
        if (!hasPermission) {
            item {
                Column(
                    Modifier.fillMaxWidth().frost().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Text("Allow access to your music to see the songs on this device.", color = AppSettings.onBg, fontSize = 15.sp)
                    GlassPill(backdrop, "Allow access", requestPermission, accent = true)
                }
            }
        } else if (tracks.isEmpty()) {
            item {
                Text("No songs found on this device yet. Download some from the Library tab.", color = secondary(), fontSize = 15.sp, modifier = Modifier.padding(8.dp))
            }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassPill(backdrop, "Play all", { Playback.playQueue(ctx, tracks.toList(), 0) }, accent = true)
                    GlassPill(backdrop, "Shuffle", { Playback.playQueue(ctx, tracks.toList().shuffled(), 0) })
                }
            }
            itemsIndexed(tracks, key = { _, t -> t.key }) { i, t ->
                SongRow(t, isCurrent = Playback.current?.key == t.key) {
                    Playback.playQueue(ctx, tracks.toList(), i)
                }
            }
        }
    }
}

@Composable
fun SongRow(t: Track, isCurrent: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .pressScale(onClick)
            .frost(RoundedCornerShape(22.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TrackArt(t, Modifier.size(54.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, color = if (isCurrent) AppSettings.accent else AppSettings.onBg,
                fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(t.artist, color = secondary(), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (isCurrent) {
            Icon(if (Playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = AppSettings.accent)
        }
    }
}

// ---------------------------------------------------------------- LIBRARY

private fun runSearch(q: String) {
    val query = q.trim()
    if (query.isEmpty()) return
    LibraryState.loading = true
    LibraryState.error = null
    AppScope.launch {
        try {
            val r = OnlineRepo.search(query)
            LibraryState.results.clear()
            LibraryState.results.addAll(r)
            if (r.isEmpty()) LibraryState.error = "No results"
        } catch (e: Exception) {
            LibraryState.error = "Could not reach the server. Check your connection."
        }
        LibraryState.loading = false
    }
}

@Composable
fun LibraryScreen(backdrop: LayerBackdrop) {
    val ctx = LocalContext.current
    val results = LibraryState.results
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 210.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ScreenHeader("Library") }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(52.dp)
                        .glass(backdrop, CircleShape, 8f, 16f, 18f, Color.White.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    BasicTextField(
                        value = LibraryState.query,
                        onValueChange = { LibraryState.query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = AppSettings.onBg, fontSize = 16.sp),
                        cursorBrush = Brush.verticalGradient(listOf(AppSettings.accent, AppSettings.accent)),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { runSearch(LibraryState.query) }),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                        decorationBox = { inner ->
                            if (LibraryState.query.isEmpty()) {
                                Text("Search songs, nasheeds, poems…", color = secondary(), fontSize = 16.sp)
                            }
                            inner()
                        },
                    )
                }
                GlassButton(backdrop, { runSearch(LibraryState.query) }, size = 52.dp) {
                    Icon(Icons.Rounded.Search, null, tint = AppSettings.accent, modifier = Modifier.size(26.dp))
                }
            }
        }
        item {
            val chips = listOf("حسينية", "لطميات", "قصائد حسينية", "Hussaini nasheed", "Nasheed", "Arabic")
            Row(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    chips.chunked(3).forEach { rowChips ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowChips.forEach { c ->
                                Text(
                                    c, color = AppSettings.onBg, fontSize = 14.sp,
                                    modifier = Modifier
                                        .pressScale {
                                            LibraryState.query = c
                                            runSearch(c)
                                        }
                                        .frost(CircleShape)
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        if (LibraryState.loading) {
            item { Text("Searching…", color = secondary(), fontSize = 15.sp, modifier = Modifier.padding(8.dp)) }
        }
        LibraryState.error?.let { e ->
            item { Text(e, color = secondary(), fontSize = 15.sp, modifier = Modifier.padding(8.dp)) }
        }
        itemsIndexed(results, key = { _, t -> t.key }) { _, t ->
            OnlineRow(backdrop, t)
        }
    }
}

@Composable
fun OnlineRow(backdrop: LayerBackdrop, t: Track) {
    val ctx = LocalContext.current
    val prog = LibraryState.progress[t.key]
    val done = LibraryState.done[t.key] == true
    Row(
        Modifier.fillMaxWidth().frost(RoundedCornerShape(22.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TrackArt(t, Modifier.size(54.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, color = AppSettings.onBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = secondary(), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        GlassIconButton(backdrop, Icons.Rounded.PlayArrow, { Playback.playOnline(ctx, t) }, size = 44.dp, tint = AppSettings.accent)
        if (prog != null) {
            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                Text("${(prog * 100).toInt()}%", color = AppSettings.onBg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        } else if (done) {
            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Check, null, tint = Color(0xFF34C759))
            }
        } else {
            GlassIconButton(backdrop, Icons.Rounded.Download, {
                LibraryState.progress[t.key] = 0f
                AppScope.launch {
                    val ok = OnlineRepo.download(ctx, t) { f -> LibraryState.progress[t.key] = f }
                    LibraryState.progress.remove(t.key)
                    if (ok) {
                        LibraryState.done[t.key] = true
                        Library.refresh(ctx)
                        Toast.makeText(ctx, "Saved to your songs", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(ctx, "Download failed", Toast.LENGTH_SHORT).show()
                    }
                }
            }, size = 44.dp, tint = AppSettings.onBg)
        }
    }
}

// ---------------------------------------------------------------- SETTINGS

@Composable
fun SettingsRoot(backdrop: LayerBackdrop) {
    var page by rememberSaveable { mutableStateOf(0) }
    BackHandler(enabled = page != 0) { page = 0 }
    AnimatedContent(
        targetState = page,
        transitionSpec = {
            (fadeIn(tween(280)) + slideInHorizontally(tween(280), initialOffsetX = { it / 6 })) togetherWith fadeOut(tween(140))
        },
        label = "settingsPage",
    ) { pg ->
        when (pg) {
            0 -> SettingsMenu { page = it }
            1 -> ThemePage(backdrop) { page = 0 }
            2 -> AboutPage(backdrop) { page = 0 }
            else -> MorePage(backdrop) { page = 0 }
        }
    }
}

@Composable
fun SettingsMenu(open: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Settings")
        MenuRow(Icons.Rounded.Palette, "Theme", "Colors, dark / light, app icon") { open(1) }
        MenuRow(Icons.Rounded.Info, "About", "What this app does") { open(2) }
        MenuRow(Icons.Rounded.Tune, "More", "Bottom bar glass, audio fade, lyrics") { open(3) }
    }
}

@Composable
fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().pressScale(onClick).frost(RoundedCornerShape(26.dp)).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Icon(icon, null, tint = AppSettings.accent, modifier = Modifier.size(30.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = AppSettings.onBg, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = secondary(), fontSize = 13.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = secondary())
    }
}

@Composable
fun PageHeader(backdrop: LayerBackdrop, title: String, onBack: () -> Unit) {
    Row(
        Modifier.statusBarsPadding().padding(top = 10.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        GlassIconButton(backdrop, Icons.AutoMirrored.Rounded.ArrowBack, onBack, size = 46.dp)
        Text(title, color = AppSettings.onBg, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = secondary(), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 8.dp))
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().frost(RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = AppSettings.onBg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = secondary(), fontSize = 12.sp)
        }
        GlassSwitch(checked, onChange)
    }
}

private val IconAliases = listOf(".IconDefault", ".IconA", ".IconB", ".IconC")

private fun applyIcon(ctx: Context, idx: Int) {
    val pm = ctx.packageManager
    IconAliases.forEachIndexed { i, n ->
        if (i == idx) {
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, ctx.packageName + n),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP,
            )
        }
    }
    IconAliases.forEachIndexed { i, n ->
        if (i != idx) {
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, ctx.packageName + n),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP,
            )
        }
    }
}

@Composable
fun ThemePage(backdrop: LayerBackdrop, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    val scaled = android.graphics.Bitmap.createScaledBitmap(bmp, 192, 192, true)
                    val sc = ShortcutInfoCompat.Builder(ctx, "custom_" + System.currentTimeMillis())
                        .setShortLabel("Liquid Player")
                        .setIcon(IconCompat.createWithBitmap(scaled))
                        .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                        .build()
                    ShortcutManagerCompat.requestPinShortcut(ctx, sc, null)
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not use this image", Toast.LENGTH_SHORT).show()
            }
        }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 200.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PageHeader(backdrop, "Theme", onBack)

        SectionLabel("BUTTON COLOR")
        Column(Modifier.fillMaxWidth().frost(RoundedCornerShape(26.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            AccentPalette.chunked(6).forEachIndexed { r, rowColors ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    rowColors.forEachIndexed { c, (_, color) ->
                        val idx = r * 6 + c
                        val selected = AppSettings.accentIndex == idx && !AppSettings.adaptive
                        Box(
                            Modifier
                                .size(42.dp)
                                .pressScale { AppSettings.update { accentIndex = idx; adaptive = false } }
                                .clip(CircleShape)
                                .background(color)
                                .border(if (selected) 3.dp else 0.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (selected) Icon(Icons.Rounded.Check, null, tint = Color.Black.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        SwitchRow("Adapt app colors", "Use the playing song's cover colors for the whole app", AppSettings.adaptive) {
            AppSettings.update { adaptive = it }
        }

        SectionLabel("THEME TYPE")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassPill(backdrop, "Dark", { AppSettings.update { dark = true } }, Modifier.weight(1f), accent = AppSettings.dark)
            GlassPill(backdrop, "Light", { AppSettings.update { dark = false } }, Modifier.weight(1f), accent = !AppSettings.dark)
        }

        SectionLabel("APP ICON")
        Column(Modifier.fillMaxWidth().frost(RoundedCornerShape(26.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                IconBgColors.forEachIndexed { i, bg ->
                    Box(
                        Modifier
                            .size(62.dp)
                            .pressScale {
                                AppSettings.update { iconIndex = i }
                                applyIcon(ctx, i)
                            }
                            .clip(RoundedCornerShape(18.dp))
                            .background(bg)
                            .border(if (AppSettings.iconIndex == i) 3.dp else 0.dp, Color.White, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                }
            }
            Text("Changing the icon may take a few seconds to show on your launcher.", color = secondary(), fontSize = 12.sp)
            GlassPill(backdrop, "Choose from gallery", { picker.launch("image/*") }, Modifier.fillMaxWidth())
            Text("A gallery image is added to your home screen as a shortcut with that icon.", color = secondary(), fontSize = 12.sp)
        }
    }
}

@Composable
fun AboutPage(backdrop: LayerBackdrop, onBack: () -> Unit) {
    val ctx = LocalContext.current
    fun open(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 200.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PageHeader(backdrop, "About", onBack)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.fillMaxWidth().frost(RoundedCornerShape(28.dp)).padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Liquid Player", color = AppSettings.accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    "مشغل موسيقى بتصميم Liquid Glass بالكامل، مبني بمكتبة Backdrop. يشغّل الأغاني الموجودة على جهازك ويتيح لك البحث وتنزيل الأغاني والقصائد الحسينية من الإنترنت.",
                    color = AppSettings.onBg, fontSize = 15.sp, lineHeight = 24.sp,
                )
                Text("المميزات", color = AppSettings.onBg, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                listOf(
                    "شريط سفلي زجاجي مع 3 تبويبات: Home وLibrary وSettings",
                    "مشغل صغير ينفتح إلى مشغل كبير بأنيميشن سلس",
                    "بحث وتنزيل من الإنترنت، والأغنية المنزّلة تُضاف لأغاني جهازك",
                    "أكثر من 20 لون للأزرار، وألوان تتكيّف مع غلاف الأغنية",
                    "ثيم داكن أو فاتح، وأيقونات متعددة للتطبيق",
                    "تحكم بضبابية الشريط السفلي وانكساره وشفافيته ولونه",
                    "وضع للأجهزة الضعيفة، وتلاشي سلس للصوت",
                    "كلمات الأغنية مع إمكانية تعديلها",
                ).forEach { Text("•  $it", color = AppSettings.onBg, fontSize = 14.sp, lineHeight = 22.sp) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassPill(backdrop, "Telegram", { open("https://t.me/xezn9") }, Modifier.weight(1f), accent = true)
            GlassPill(backdrop, "TikTok", { open("https://www.tiktok.com/@xezn99") }, Modifier.weight(1f), accent = true)
        }
    }
}

@Composable
fun LabeledSlider(label: String, valueText: String, frac: Float, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().frost(RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = AppSettings.onBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(valueText, color = secondary(), fontSize = 14.sp)
        }
        Spacer(Modifier.height(4.dp))
        GlassSlider(frac, onChange, onFinished = { AppSettings.save() })
    }
}

@Composable
fun MorePage(backdrop: LayerBackdrop, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 200.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PageHeader(backdrop, "More", onBack)

        SectionLabel("BOTTOM BAR")
        LabeledSlider("Blur", "${AppSettings.barBlur.toInt()}", AppSettings.barBlur / 40f) { AppSettings.barBlur = it * 40f }
        LabeledSlider("Refraction height", "${AppSettings.barRefH.toInt()}", AppSettings.barRefH / 24f) { AppSettings.barRefH = it * 24f }
        LabeledSlider("Refraction strength", "${AppSettings.barRefA.toInt()}", AppSettings.barRefA / 40f) { AppSettings.barRefA = it * 40f }
        LabeledSlider("Transparency (tint)", "${(AppSettings.barAlpha * 100).toInt()}%", AppSettings.barAlpha / 0.6f) { AppSettings.barAlpha = it * 0.6f }

        Column(Modifier.fillMaxWidth().frost(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Bar color", color = AppSettings.onBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            val opts = listOf(-1) + (0 until 11)
            opts.chunked(6).forEach { rowOpts ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    rowOpts.forEach { idx ->
                        val sel = AppSettings.barTint == idx
                        Box(
                            Modifier
                                .size(40.dp)
                                .pressScale { AppSettings.update { barTint = idx } }
                                .clip(CircleShape)
                                .background(if (idx < 0) Color.White.copy(alpha = 0.25f) else AccentPalette[idx].second)
                                .border(if (sel) 3.dp else 0.8.dp, if (sel) Color.White else Color.White.copy(alpha = 0.4f), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (idx < 0) Icon(Icons.Rounded.Close, null, tint = AppSettings.onBg, modifier = Modifier.size(18.dp))
                        }
                    }
                    repeat(6 - rowOpts.size) { Spacer(Modifier.size(40.dp)) }
                }
            }
        }

        SectionLabel("SWITCHES")
        SwitchRow("Liquid Glass", "Turn off on weak devices for smoother performance", AppSettings.liquid) { AppSettings.update { liquid = it } }
        SwitchRow("Smooth audio fade", "Fades in and out at the start and end of songs to remove clicks and abrupt cuts", AppSettings.fade) { AppSettings.update { fade = it } }
        SwitchRow("Song lyrics", "Adds a lyrics button to the full player, with an edit option", AppSettings.lyrics) { AppSettings.update { lyrics = it } }
    }
}

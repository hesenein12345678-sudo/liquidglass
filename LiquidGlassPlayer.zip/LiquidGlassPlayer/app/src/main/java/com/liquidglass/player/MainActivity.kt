package com.liquidglass.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.init(applicationContext)
        Playback.attach(applicationContext)
        if (controllerHolder == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerHolder = MediaController.Builder(applicationContext, token).buildAsync()
        }
        enableEdgeToEdge()
        setContent { Root() }
    }

    companion object {
        private var controllerHolder: Any? = null
    }
}

@Composable
fun AppBackground() {
    val cols = AppSettings.bgColors()
    val c1 by animateColorAsState(cols[0], tween(900), label = "c1")
    val c2 by animateColorAsState(cols[1], tween(900), label = "c2")
    val c3 by animateColorAsState(cols[2], tween(900), label = "c3")
    val base = AppSettings.baseBg
    val a = if (AppSettings.dark) 0.55f else 0.45f
    Box(
        Modifier
            .fillMaxSize()
            .background(base)
            .drawBehind {
                val r = size.width * 1.05f
                val p1 = Offset(size.width * 0.10f, size.height * 0.15f)
                val p2 = Offset(size.width * 0.95f, size.height * 0.50f)
                val p3 = Offset(size.width * 0.20f, size.height * 0.95f)
                drawCircle(Brush.radialGradient(listOf(c1.copy(alpha = a), Color.Transparent), center = p1, radius = r), radius = r, center = p1)
                drawCircle(Brush.radialGradient(listOf(c2.copy(alpha = a), Color.Transparent), center = p2, radius = r), radius = r, center = p2)
                drawCircle(Brush.radialGradient(listOf(c3.copy(alpha = a), Color.Transparent), center = p3, radius = r), radius = r, center = p3)
            }
    )
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val backdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableStateOf(0) }
    var expanded by rememberSaveable { mutableStateOf(false) }
    val p by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 230f),
        label = "expand",
    )

    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        granted = res[perm] == true
        if (granted) Library.refresh(ctx)
    }
    fun requestPerms() {
        val list = ArrayList<String>()
        list.add(perm)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        launcher.launch(list.toTypedArray())
    }
    LaunchedEffect(Unit) {
        if (granted) Library.refresh(ctx) else requestPerms()
    }

    LaunchedEffect(AppSettings.dark) {
        val bar = if (AppSettings.dark) SystemBarStyle.dark(0) else SystemBarStyle.light(0, 0)
        activity.enableEdgeToEdge(statusBarStyle = bar, navigationBarStyle = bar)
    }

    // Playback position + audio fade
    LaunchedEffect(Unit) {
        val player = PlayerHolder.get(ctx)
        while (true) {
            val d = player.duration
            val pos = player.currentPosition
            Playback.position = pos
            Playback.duration = if (d > 0) d else 0L
            if (AppSettings.fade && player.isPlaying && d > 0) {
                val fin = (pos / 700f).coerceIn(0f, 1f)
                val fout = ((d - pos) / 1500f).coerceIn(0f, 1f)
                player.volume = minOf(fin, fout).coerceAtLeast(0.02f)
            } else if (player.volume != 1f) {
                player.volume = 1f
            }
            delay(100)
        }
    }

    // Adaptive colors from album art
    val cur = Playback.current
    LaunchedEffect(cur?.key, AppSettings.adaptive) {
        if (!AppSettings.adaptive || cur == null) {
            AppSettings.artColors = null
            return@LaunchedEffect
        }
        val bmp = ArtLoader.load(ctx, cur)
        if (bmp == null) {
            AppSettings.artColors = null
            return@LaunchedEffect
        }
        val cols = withContext(Dispatchers.Default) {
            val pal = Palette.from(bmp).maximumColorCount(16).generate()
            listOfNotNull(pal.vibrantSwatch, pal.lightVibrantSwatch, pal.dominantSwatch, pal.darkVibrantSwatch, pal.mutedSwatch)
                .map { Color(it.rgb) }
        }
        AppSettings.artColors = if (cols.isEmpty()) null else cols
    }

    MaterialTheme(colorScheme = if (AppSettings.dark) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
                    AppBackground()
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(160)) },
                        label = "tabs",
                    ) { t ->
                        when (t) {
                            0 -> HomeScreen(backdrop, granted) { requestPerms() }
                            1 -> LibraryScreen(backdrop)
                            else -> SettingsRoot(backdrop)
                        }
                    }
                }
                LiquidBottomTabs(
                    backdrop = backdrop,
                    selected = tab,
                    onSelect = { tab = it },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 12.dp)
                        .offset(y = (p * 180f).dp),
                )
                PlayerOverlay(backdrop, p, expanded) { expanded = it }
            }
        }
    }
}

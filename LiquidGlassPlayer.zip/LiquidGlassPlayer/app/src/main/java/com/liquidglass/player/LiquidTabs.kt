package com.liquidglass.player

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.fastCoerceIn
import androidx.compose.ui.util.fastRoundToInt
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.shadow.InnerShadow
import com.kyant.backdrop.shadow.Shadow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sign

/** Press / drag animation of the catalog's tab indicator (damped springs, press scale, velocity). */
class DampedDragAnimation(
    private val animationScope: CoroutineScope,
    initialValue: Float,
    private val valueRange: ClosedFloatingPointRange<Float>,
    private val initialScale: Float,
    private val pressedScale: Float,
    private val onDragStarted: DampedDragAnimation.() -> Unit,
    private val onDragStopped: DampedDragAnimation.() -> Unit,
    private val onDrag: DampedDragAnimation.(size: IntSize, dragAmount: Offset) -> Unit,
) {
    private val valueAnimation = Animatable(initialValue)
    private val pressAnimation = Animatable(0f)

    var targetValue by mutableFloatStateOf(initialValue)
        private set

    val value: Float get() = valueAnimation.value
    val pressProgress: Float get() = pressAnimation.value
    val scaleX: Float get() = lerp(initialScale, pressedScale, pressProgress)
    val scaleY: Float get() = lerp(initialScale, pressedScale, pressProgress)
    val velocity: Float get() = valueAnimation.velocity

    fun updateValue(v: Float) {
        val t = v.fastCoerceIn(valueRange.start, valueRange.endInclusive)
        targetValue = t
        animationScope.launch { valueAnimation.animateTo(t, spring(1f, 1000f, 0.01f)) }
    }

    fun animateToValue(v: Float) {
        val t = v.fastCoerceIn(valueRange.start, valueRange.endInclusive)
        targetValue = t
        animationScope.launch {
            launch { pressAnimation.animateTo(0f, spring(1f, 1000f, 0.001f)) }
            launch { valueAnimation.animateTo(t, spring(1f, 1000f, 0.01f)) }
        }
    }

    val modifier: Modifier = Modifier.pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            animationScope.launch { pressAnimation.animateTo(1f, spring(1f, 1000f, 0.001f)) }
            onDragStarted(this@DampedDragAnimation)
            drag(down.id) { change ->
                change.consume()
                onDrag(this@DampedDragAnimation, size, change.positionChange())
            }
            onDragStopped(this@DampedDragAnimation)
        }
    }
}

internal val LocalLiquidBottomTabScale = staticCompositionLocalOf<() -> Float> { { 1f } }

/** A tab that shares its parent's width and height (catalog LiquidBottomTab). */
@Composable
fun RowScope.LiquidBottomTab(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(2.dp, Alignment.CenterVertically),
    horizontalAlignment: Alignment.Horizontal = Alignment.CenterHorizontally,
    content: @Composable ColumnScope.() -> Unit,
) {
    val scale = LocalLiquidBottomTabScale.current
    Column(
        modifier
            .clip(shape)
            .clickable(
                interactionSource = null,
                indication = null,
                role = Role.Tab,
                onClick = onClick,
            )
            .fillMaxHeight()
            .weight(1f)
            .graphicsLayer {
                val s = scale()
                scaleX = s
                scaleY = s
            }
            .padding(contentPadding),
        verticalArrangement = verticalArrangement,
        horizontalAlignment = horizontalAlignment,
        content = content,
    )
}

/** The catalog's LiquidBottomTabs (without the touch-following highlight shader). */
@Composable
fun LiquidGlassTabs(
    selectedTabIndex: () -> Int,
    onTabSelected: (index: Int) -> Unit,
    backdrop: LayerBackdrop,
    tabsCount: Int,
    modifier: Modifier = Modifier,
    height: Dp = 64.dp,
    contentPadding: Dp = 4.dp,
    shape: Shape = CircleShape,
    indicatorShape: Shape = shape,
    accentColor: Color,
    containerColor: Color,
    indicatorColor: Color,
    content: @Composable RowScope.() -> Unit,
) {
    val currentOnTabSelected by rememberUpdatedState(onTabSelected)
    val tabsBackdrop = rememberLayerBackdrop()

    BoxWithConstraints(
        modifier.height(height),
        contentAlignment = Alignment.CenterStart,
    ) {
        val density = LocalDensity.current
        val indicatorHeight = maxHeight - contentPadding * 2
        val tabWidth by rememberUpdatedState(
            with(density) { (constraints.maxWidth.toFloat() - contentPadding.toPx() * 2) / tabsCount }
        )
        val offsetAnimation = remember { Animatable(0f) }
        val panelOffset by remember(density, constraints.maxWidth) {
            derivedStateOf {
                val fraction = (offsetAnimation.value / constraints.maxWidth).fastCoerceIn(-1f, 1f)
                with(density) { 4f.dp.toPx() * fraction.sign * EaseOut.transform(abs(fraction)) }
            }
        }
        val isLtr by rememberUpdatedState(LocalLayoutDirection.current == LayoutDirection.Ltr)
        val animationScope = rememberCoroutineScope()
        var currentIndex by remember(tabsCount) {
            mutableIntStateOf(selectedTabIndex().fastCoerceIn(0, tabsCount - 1))
        }
        val dampedDragAnimation = remember(animationScope, tabsCount) {
            DampedDragAnimation(
                animationScope = animationScope,
                initialValue = selectedTabIndex().fastCoerceIn(0, tabsCount - 1).toFloat(),
                valueRange = 0f..(tabsCount - 1).toFloat(),
                initialScale = 1f,
                pressedScale = 78f / 56f,
                onDragStarted = {},
                onDragStopped = {
                    val targetIndex = targetValue.fastRoundToInt().fastCoerceIn(0, tabsCount - 1)
                    currentIndex = targetIndex
                    animateToValue(targetIndex.toFloat())
                    animationScope.launch {
                        offsetAnimation.animateTo(0f, spring(1f, 300f, 0.5f))
                    }
                },
                onDrag = { _, dragAmount ->
                    updateValue(
                        (targetValue + dragAmount.x / tabWidth * if (isLtr) 1f else -1f)
                            .fastCoerceIn(0f, (tabsCount - 1).toFloat())
                    )
                    animationScope.launch {
                        offsetAnimation.snapTo(offsetAnimation.value + dragAmount.x)
                    }
                },
            )
        }
        LaunchedEffect(selectedTabIndex, tabsCount) {
            snapshotFlow { selectedTabIndex() }
                .collectLatest { index -> currentIndex = index.fastCoerceIn(0, tabsCount - 1) }
        }
        LaunchedEffect(dampedDragAnimation) {
            snapshotFlow { currentIndex }
                .drop(1)
                .collectLatest { index ->
                    dampedDragAnimation.animateToValue(index.toFloat())
                    currentOnTabSelected(index)
                }
        }

        // 1) container glass + visible tabs
        Row(
            Modifier
                .graphicsLayer { translationX = panelOffset }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { shape },
                    effects = {
                        vibrancy()
                        blur(AppSettings.barBlur.dp.toPx())
                        lens(AppSettings.barRefH.dp.toPx(), AppSettings.barRefA.dp.toPx())
                    },
                    layerBlock = {
                        val progress = dampedDragAnimation.pressProgress
                        val scale = lerp(1f, 1f + 16f.dp.toPx() / size.width, progress)
                        scaleX = scale
                        scaleY = scale
                    },
                    onDrawSurface = { drawRect(containerColor) },
                )
                .fillMaxSize()
                .padding(contentPadding),
            verticalAlignment = Alignment.CenterVertically,
            content = content,
        )

        // 2) hidden accent-colored copy of the tabs, recorded for the indicator
        CompositionLocalProvider(
            LocalLiquidBottomTabScale provides { lerp(1f, 1.2f, dampedDragAnimation.pressProgress) }
        ) {
            Row(
                Modifier
                    .clearAndSetSemantics {}
                    .alpha(0f)
                    .layerBackdrop(tabsBackdrop)
                    .graphicsLayer { translationX = panelOffset }
                    .drawBackdrop(
                        backdrop = backdrop,
                        shape = { shape },
                        effects = {
                            val progress = dampedDragAnimation.pressProgress
                            vibrancy()
                            blur(AppSettings.barBlur.dp.toPx())
                            lens(
                                AppSettings.barRefH.dp.toPx() * progress,
                                AppSettings.barRefA.dp.toPx() * progress,
                            )
                        },
                        highlight = {
                            val progress = dampedDragAnimation.pressProgress
                            Highlight.Default.copy(alpha = progress)
                        },
                        onDrawSurface = { drawRect(containerColor) },
                    )
                    .height(indicatorHeight)
                    .fillMaxWidth()
                    .padding(horizontal = contentPadding)
                    .graphicsLayer(colorFilter = ColorFilter.tint(accentColor)),
                verticalAlignment = Alignment.CenterVertically,
                content = content,
            )
        }

        // 3) the draggable lens indicator
        Box(
            Modifier
                .padding(horizontal = contentPadding)
                .graphicsLayer {
                    translationX =
                        if (isLtr) dampedDragAnimation.value * tabWidth + panelOffset
                        else -dampedDragAnimation.value * tabWidth + panelOffset
                }
                .then(dampedDragAnimation.modifier)
                .drawBackdrop(
                    backdrop = rememberCombinedBackdrop(backdrop, tabsBackdrop),
                    shape = { indicatorShape },
                    effects = {
                        val progress = dampedDragAnimation.pressProgress
                        lens(
                            10f.dp.toPx() * progress,
                            14f.dp.toPx() * progress,
                            chromaticAberration = true,
                        )
                    },
                    highlight = {
                        val progress = dampedDragAnimation.pressProgress
                        Highlight.Default.copy(alpha = progress)
                    },
                    shadow = {
                        val progress = dampedDragAnimation.pressProgress
                        Shadow(alpha = progress)
                    },
                    innerShadow = {
                        val progress = dampedDragAnimation.pressProgress
                        InnerShadow(radius = 8f.dp * progress, alpha = progress)
                    },
                    layerBlock = {
                        scaleX = dampedDragAnimation.scaleX
                        scaleY = dampedDragAnimation.scaleY
                        val velocity = dampedDragAnimation.velocity / 10f
                        scaleX /= 1f - (velocity * 0.75f).fastCoerceIn(-0.2f, 0.2f)
                        scaleY *= 1f - (velocity * 0.25f).fastCoerceIn(-0.2f, 0.2f)
                    },
                    onDrawSurface = {
                        val progress = dampedDragAnimation.pressProgress
                        drawRect(indicatorColor, alpha = 1f - progress)
                        drawRect(Color.Black.copy(alpha = 0.03f * progress))
                    },
                )
                .height(indicatorHeight)
                .fillMaxWidth(1f / tabsCount)
        )
    }
}

private val TabItems = listOf(
    "Home" to Icons.Rounded.Home,
    "Library" to Icons.Rounded.LibraryMusic,
    "Settings" to Icons.Rounded.Settings,
)

/** App entry point used by Root: catalog bottom tabs (or a plain bar when glass is off / Android < 12). */
@Composable
fun LiquidBottomTabs(
    backdrop: LayerBackdrop,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val fx = AppSettings.liquid && Build.VERSION.SDK_INT >= 31
    val selState = rememberUpdatedState(selected)
    val onBg = AppSettings.onBg
    val light = !AppSettings.dark
    if (fx) {
        LiquidGlassTabs(
            selectedTabIndex = { selState.value },
            onTabSelected = onSelect,
            backdrop = backdrop,
            tabsCount = TabItems.size,
            modifier = modifier.fillMaxWidth().padding(horizontal = 22.dp),
            accentColor = AppSettings.accent,
            containerColor = barTint(),
            indicatorColor = if (light) Color.Black.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.1f),
        ) {
            TabItems.forEachIndexed { i, (label, icon) ->
                LiquidBottomTab(onClick = { onSelect(i) }) {
                    Icon(icon, null, tint = onBg, modifier = Modifier.size(28.dp))
                    Text(label, color = onBg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    } else {
        Row(
            modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .height(64.dp)
                .clip(CircleShape)
                .background(barTint())
                .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                .padding(4.dp),
        ) {
            TabItems.forEachIndexed { i, (label, icon) ->
                val sel = i == selected
                val c = if (sel) AppSettings.accent else onBg
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(if (sel) AppSettings.accent.copy(alpha = 0.2f) else Color.Transparent)
                        .tap { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(icon, null, tint = c, modifier = Modifier.size(28.dp))
                    Text(label, color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

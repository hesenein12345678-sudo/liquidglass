package com.liquidglass.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as colorLerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp as dpLerp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp as floatLerp
import com.kyant.backdrop.backdrops.LayerBackdrop
import kotlinx.coroutines.launch

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun PlayerOverlay(backdrop: LayerBackdrop, pRaw: Float, expanded: Boolean, setExpanded: (Boolean) -> Unit) {
    val track = Playback.current ?: return
    val p = pRaw.coerceIn(0f, 1f)
    val navPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    BackHandler(enabled = expanded) { setExpanded(false) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val full = maxHeight
        val h = dpLerp(68.dp, full, p)
        val bottom = dpLerp(navPad + 12.dp + 66.dp + 10.dp, 0.dp, p)
        val side = dpLerp(14.dp, 0.dp, p)
        val corner = dpLerp(34.dp, 0.dp, p)
        val tint = colorLerp(barTint(), AppSettings.baseBg.copy(alpha = 0.62f), p)
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(start = side, end = side, bottom = bottom)
                .fillMaxWidth()
                .height(h)
                .glass(
                    backdrop, RoundedCornerShape(corner),
                    blurDp = floatLerp(AppSettings.barBlur, 36f, p),
                    lensH = 18f * (1f - p),
                    lensA = AppSettings.barRefA * (1f - p),
                    tint = tint,
                )
                .pointerInput(expanded) {
                    if (expanded) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total > 220f) setExpanded(false) },
                            onDragCancel = {},
                            onVerticalDrag = { _, d -> total += d },
                        )
                    }
                }
        ) {
            if (p < 0.55f) {
                MiniPlayer(backdrop, track, Modifier.alpha((1f - p * 2f).coerceIn(0f, 1f))) { setExpanded(true) }
            }
            if (p > 0.05f) {
                FullPlayer(
                    backdrop, track,
                    Modifier.graphicsLayer { alpha = ((p - 0.5f) / 0.5f).coerceIn(0f, 1f) },
                ) { setExpanded(false) }
            }
        }
    }
}

@Composable
fun MiniPlayer(backdrop: LayerBackdrop, t: Track, modifier: Modifier, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    Row(
        modifier.fillMaxSize().tap(onOpen).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TrackArt(t, Modifier.size(48.dp), corner = 24.dp)
        Column(Modifier.weight(1f)) {
            Text(t.title, color = AppSettings.onBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = secondary(), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        GlassIconButton(backdrop, if (Playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, { Playback.toggle(ctx) }, size = 44.dp, tint = AppSettings.accent)
        GlassIconButton(backdrop, Icons.Rounded.SkipNext, { Playback.next(ctx) }, size = 44.dp)
    }
}

@Composable
fun FullPlayer(backdrop: LayerBackdrop, t: Track, modifier: Modifier, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var showLyrics by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val artScale by animateFloatAsState(
        targetValue = if (Playback.isPlaying) 1f else 0.86f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 180f),
        label = "artScale",
    )
    val statusPad = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(top = statusPad + 8.dp, bottom = navPad + 16.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton(backdrop, Icons.Rounded.KeyboardArrowDown, onClose, size = 46.dp)
                Text("Now Playing", color = secondary(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                if (AppSettings.lyrics) {
                    GlassPill(backdrop, "Lyrics", { showLyrics = !showLyrics }, accent = showLyrics)
                } else {
                    Spacer(Modifier.size(46.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            TrackArt(
                t,
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .graphicsLayer {
                        scaleX = artScale
                        scaleY = artScale
                    },
                corner = 36.dp,
            )
            Spacer(Modifier.weight(1f))
            Text(t.title, color = AppSettings.onBg, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Text(t.artist, color = secondary(), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))

            val frac = drag ?: if (Playback.duration > 0) Playback.position.toFloat() / Playback.duration else 0f
            GlassSlider(
                value = frac,
                onChange = { drag = it },
                onFinished = {
                    drag?.let { Playback.seekFraction(ctx, it) }
                    drag = null
                },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(if (drag != null) (drag!! * Playback.duration).toLong() else Playback.position), color = secondary(), fontSize = 12.sp)
                Text(fmt(Playback.duration), color = secondary(), fontSize = 12.sp)
            }
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassIconButton(backdrop, Icons.Rounded.SkipPrevious, { Playback.previous(ctx) }, size = 62.dp)
                GlassButton(backdrop, { Playback.toggle(ctx) }, size = 84.dp) {
                    Icon(
                        if (Playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        null, tint = AppSettings.accent, modifier = Modifier.size(44.dp),
                    )
                }
                GlassIconButton(backdrop, Icons.Rounded.SkipNext, { Playback.next(ctx) }, size = 62.dp)
            }
            Spacer(Modifier.height(10.dp))
        }

        AnimatedVisibility(
            visible = showLyrics && AppSettings.lyrics,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 3 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 3 }),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            LyricsPanel(backdrop, t, Modifier.padding(start = 14.dp, end = 14.dp, bottom = navPad + 14.dp, top = statusPad + 70.dp)) { showLyrics = false }
        }
    }
}

@Composable
fun LyricsPanel(backdrop: LayerBackdrop, t: Track, modifier: Modifier, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember(t.key) { mutableStateOf(LyricsRepo.saved(ctx, t.key) ?: "") }
    var loading by remember(t.key) { mutableStateOf(false) }
    var editing by remember(t.key) { mutableStateOf(false) }
    var draft by remember(t.key) { mutableStateOf("") }

    androidx.compose.runtime.LaunchedEffect(t.key) {
        if (text.isBlank()) {
            loading = true
            val r = LyricsRepo.fetch(t)
            if (!r.isNullOrBlank()) {
                text = r
                LyricsRepo.save(ctx, t.key, r)
            }
            loading = false
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .frost(RoundedCornerShape(30.dp))
            .background(AppSettings.baseBg.copy(alpha = 0.55f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Lyrics", color = AppSettings.onBg, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (editing) {
                GlassPill(backdrop, "Save", {
                    text = draft
                    LyricsRepo.save(ctx, t.key, draft)
                    editing = false
                }, accent = true)
            } else {
                GlassPill(backdrop, "Edit", {
                    draft = text
                    editing = true
                })
            }
            GlassPill(backdrop, "Close", onClose)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (editing) {
                BasicTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    textStyle = TextStyle(color = AppSettings.onBg, fontSize = 17.sp, lineHeight = 28.sp),
                    cursorBrush = Brush.verticalGradient(listOf(AppSettings.accent, AppSettings.accent)),
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                )
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    val shown = when {
                        text.isNotBlank() -> text
                        loading -> "Searching for lyrics…"
                        else -> "No lyrics found for this song. Tap Edit to add them yourself."
                    }
                    Text(shown, color = AppSettings.onBg, fontSize = 18.sp, lineHeight = 30.sp)
                }
            }
        }
        if (!editing && !loading) {
            GlassPill(backdrop, "Search again", {
                AppScopeRefetch(ctx, t) { r -> if (!r.isNullOrBlank()) text = r }
            }, Modifier.fillMaxWidth())
        }
    }
}

private fun AppScopeRefetch(ctx: android.content.Context, t: Track, onResult: (String?) -> Unit) {
    AppScope.launch {
        val r = LyricsRepo.fetch(t)
        if (!r.isNullOrBlank()) LyricsRepo.save(ctx, t.key, r)
        onResult(r)
    }
}

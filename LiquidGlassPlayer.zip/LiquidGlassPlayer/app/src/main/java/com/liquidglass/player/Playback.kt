package com.liquidglass.player

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.launch

object PlayerHolder {
    private var player: ExoPlayer? = null

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val p = ExoPlayer.Builder(ctx.applicationContext)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = p
        return p
    }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, PlayerHolder.get(this)).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}

object Playback {
    var current by mutableStateOf<Track?>(null)
    var isPlaying by mutableStateOf(false)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var queue: List<Track> = emptyList()
    private var attached = false

    fun attach(ctx: Context) {
        if (attached) return
        attached = true
        val p = PlayerHolder.get(ctx)
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                Playback.isPlaying = isPlaying
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId
                val found = queue.firstOrNull { it.key == id }
                if (found != null) current = found
            }
        })
    }

    fun playQueue(ctx: Context, tracks: List<Track>, index: Int) {
        if (tracks.isEmpty()) return
        val p = PlayerHolder.get(ctx)
        queue = tracks
        val items = tracks.map {
            MediaItem.Builder()
                .setMediaId(it.key)
                .setUri(it.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).build())
                .build()
        }
        val i = index.coerceIn(0, tracks.size - 1)
        current = tracks[i]
        p.setMediaItems(items, i, 0L)
        p.prepare()
        p.play()
    }

    fun playOnline(ctx: Context, t: Track) {
        val app = ctx.applicationContext
        AppScope.launch {
            val r = OnlineRepo.resolve(t)
            if (r == null) {
                Toast.makeText(app, "No playable audio file found", Toast.LENGTH_SHORT).show()
            } else {
                playQueue(app, listOf(r), 0)
            }
        }
    }

    fun toggle(ctx: Context) {
        val p = PlayerHolder.get(ctx)
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.playbackState == Player.STATE_ENDED) p.seekTo(0)
            p.play()
        }
    }

    fun next(ctx: Context) = PlayerHolder.get(ctx).seekToNext()

    fun previous(ctx: Context) = PlayerHolder.get(ctx).seekToPrevious()

    fun seekFraction(ctx: Context, f: Float) {
        val p = PlayerHolder.get(ctx)
        val d = p.duration
        if (d > 0) p.seekTo((d * f.coerceIn(0f, 1f)).toLong())
    }
}

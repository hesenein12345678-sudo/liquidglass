package com.liquidglass.player

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class Track(
    val key: String,
    val title: String,
    val artist: String,
    val uri: String,
    val artUrl: String? = null,
    val local: Boolean = true,
    val onlineId: String? = null,
    val durationMs: Long = 0L,
)

val AppScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun get(url: String): String? = try {
        val req = Request.Builder().url(url).header("User-Agent", "LiquidPlayer/1.0 (Android)").build()
        client.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
    } catch (e: Exception) {
        null
    }
}

object Library {
    val local = mutableStateListOf<Track>()

    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            val out = ArrayList<Track>()
            try {
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.DURATION,
                )
                val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 20000"
                app.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
                    "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    while (c.moveToNext()) {
                        val id = c.getLong(iId)
                        val artist = c.getString(iA)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                        out.add(Track("l$id", c.getString(iT) ?: "Unknown", artist, uri.toString(), null, true, null, c.getLong(iD)))
                    }
                }
            } catch (_: Exception) {
            }
            withContext(Dispatchers.Main) {
                local.clear()
                local.addAll(out)
            }
        }
    }
}

private fun JSONObject.str(k: String): String {
    val v = opt(k)
    return when (v) {
        null -> ""
        JSONObject.NULL -> ""
        is JSONArray -> v.optString(0, "")
        else -> v.toString()
    }
}

object LibraryState {
    var query by mutableStateOf("")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    val results = mutableStateListOf<Track>()
    val progress = mutableStateMapOf<String, Float>()
    val done = mutableStateMapOf<String, Boolean>()
}

object OnlineRepo {
    suspend fun search(q: String): List<Track> = withContext(Dispatchers.IO) {
        val clean = q.replace("\"", " ").replace("(", " ").replace(")", " ").trim()
        val query = "(title:($clean) OR subject:($clean) OR creator:($clean) OR description:($clean)) AND mediatype:audio"
        val url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(query, "UTF-8") +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&rows=40&page=1&output=json&sort%5B%5D=downloads+desc"
        val body = Net.get(url) ?: throw IllegalStateException("network")
        val docs = JSONObject(body).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Track>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.str("identifier")
            if (id.isBlank()) continue
            val title = d.str("title").ifBlank { id }
            val artist = d.str("creator").ifBlank { "Internet Archive" }
            out.add(Track("ia:$id", title, artist, "", "https://archive.org/services/img/$id", false, id, 0L))
        }
        out
    }

    suspend fun resolve(t: Track): Track? = withContext(Dispatchers.IO) {
        val id = t.onlineId ?: return@withContext null
        val body = Net.get("https://archive.org/metadata/$id") ?: return@withContext null
        try {
            val files = JSONObject(body).optJSONArray("files") ?: return@withContext null
            var best: String? = null
            for (i in 0 until files.length()) {
                val n = files.getJSONObject(i).optString("name")
                val ln = n.lowercase()
                if (ln.endsWith(".mp3")) {
                    best = n
                    break
                }
                if (best == null && (ln.endsWith(".ogg") || ln.endsWith(".m4a"))) best = n
            }
            val chosen = best ?: return@withContext null
            t.copy(uri = "https://archive.org/download/$id/" + Uri.encode(chosen, "/"))
        } catch (e: Exception) {
            null
        }
    }

    suspend fun download(ctx: Context, t: Track, onProgress: (Float) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val resolved = resolve(t) ?: return@withContext false
        val cr = ctx.contentResolver
        val ext = resolved.uri.substringAfterLast('.', "mp3").lowercase().take(4)
        val mime = when (ext) {
            "ogg" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            else -> "audio/mpeg"
        }
        val safe = t.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80).ifBlank { "track" }
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "$safe.$ext")
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/LiquidPlayer")
            put(MediaStore.Audio.Media.TITLE, t.title)
            put(MediaStore.Audio.Media.ARTIST, t.artist)
            put(MediaStore.Audio.Media.IS_MUSIC, 1)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val target = cr.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
        try {
            val req = Request.Builder().url(resolved.uri).header("User-Agent", "LiquidPlayer/1.0 (Android)").build()
            Net.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw IllegalStateException("http ${resp.code}")
                val body = resp.body ?: throw IllegalStateException("empty")
                val total = body.contentLength()
                var read = 0L
                body.byteStream().use { input ->
                    cr.openOutputStream(target)?.use { output ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            read += n
                            if (total > 0) onProgress((read.toFloat() / total).coerceIn(0f, 1f))
                        }
                    } ?: throw IllegalStateException("no output")
                }
            }
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            cr.update(target, done, null, null)
            true
        } catch (e: Exception) {
            try {
                cr.delete(target, null, null)
            } catch (_: Exception) {
            }
            false
        }
    }
}

object LyricsRepo {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("lyrics", Context.MODE_PRIVATE)

    fun saved(ctx: Context, key: String): String? = sp(ctx).getString("l_$key", null)

    fun save(ctx: Context, key: String, text: String) {
        sp(ctx).edit().putString("l_$key", text).apply()
    }

    suspend fun fetch(t: Track): String? = withContext(Dispatchers.IO) {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        val urls = ArrayList<String>()
        val artist = t.artist.takeIf { !it.startsWith("Unknown") && it != "Internet Archive" }
        if (artist != null) urls.add("https://lrclib.net/api/search?track_name=${enc(t.title)}&artist_name=${enc(artist)}")
        urls.add("https://lrclib.net/api/search?q=${enc(t.title)}")
        val stamp = Regex("^\\[[^\\]]*\\]\\s*")
        for (u in urls) {
            val body = Net.get(u) ?: continue
            try {
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val plain = o.str("plainLyrics")
                    if (plain.isNotBlank()) return@withContext plain
                    val synced = o.str("syncedLyrics")
                    if (synced.isNotBlank()) {
                        return@withContext synced.lines().joinToString("\n") { it.replace(stamp, "") }
                    }
                }
            } catch (_: Exception) {
            }
        }
        null
    }
}

object ArtLoader {
    private val cache = LruCache<String, Bitmap>(48)

    suspend fun load(ctx: Context, t: Track): Bitmap? = withContext(Dispatchers.IO) {
        val hit = cache.get(t.key)
        if (hit != null) return@withContext hit
        var bmp: Bitmap? = null
        try {
            if (t.local) {
                bmp = try {
                    ctx.contentResolver.loadThumbnail(Uri.parse(t.uri), Size(512, 512), null)
                } catch (e: Exception) {
                    null
                }
                if (bmp == null) {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(ctx, Uri.parse(t.uri))
                        val pic = r.embeddedPicture
                        if (pic != null) bmp = BitmapFactory.decodeByteArray(pic, 0, pic.size)
                    } finally {
                        r.release()
                    }
                }
            } else if (t.artUrl != null) {
                val req = Request.Builder().url(t.artUrl).build()
                Net.client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) bmp = BitmapFactory.decodeStream(resp.body?.byteStream())
                }
            }
        } catch (_: Exception) {
        }
        val result = bmp
        if (result != null) cache.put(t.key, result)
        result
    }
}

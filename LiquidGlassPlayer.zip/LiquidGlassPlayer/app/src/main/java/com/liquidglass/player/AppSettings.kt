package com.liquidglass.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb

val AccentPalette: List<Pair<String, Color>> = listOf(
    "Ocean" to Color(0xFF0A84FF), "Mint" to Color(0xFF30D5C8), "Green" to Color(0xFF34C759),
    "Lime" to Color(0xFFA3E635), "Yellow" to Color(0xFFFFD60A), "Amber" to Color(0xFFFF9F0A),
    "Orange" to Color(0xFFFF6B1A), "Red" to Color(0xFFFF3B30), "Crimson" to Color(0xFFDC143C),
    "Rose" to Color(0xFFFF5C8A), "Pink" to Color(0xFFFF2D92), "Magenta" to Color(0xFFD946EF),
    "Purple" to Color(0xFFAF52DE), "Violet" to Color(0xFF7C3AED), "Indigo" to Color(0xFF5E5CE6),
    "Blue" to Color(0xFF3B82F6), "Sky" to Color(0xFF64D2FF), "Cyan" to Color(0xFF22D3EE),
    "Teal" to Color(0xFF14B8A6), "Emerald" to Color(0xFF10B981), "Gold" to Color(0xFFD4AF37),
    "Copper" to Color(0xFFB87333), "Slate" to Color(0xFF94A3B8), "Silver" to Color(0xFFE5E5EA),
)

val IconBgColors = listOf(Color(0xFF0A84FF), Color(0xFF15151C), Color(0xFFFF5E3A), Color(0xFF10B981))

object AppSettings {
    private var sp: SharedPreferences? = null

    var accentIndex by mutableIntStateOf(0)
    var dark by mutableStateOf(true)
    var adaptive by mutableStateOf(false)
    var liquid by mutableStateOf(true)
    var fade by mutableStateOf(true)
    var lyrics by mutableStateOf(true)
    var barBlur by mutableFloatStateOf(8f)
    var barRefH by mutableFloatStateOf(24f)
    var barRefA by mutableFloatStateOf(24f)
    var barAlpha by mutableFloatStateOf(0.4f)
    var barTint by mutableIntStateOf(-1)
    var iconIndex by mutableIntStateOf(0)
    var artColors by mutableStateOf<List<Color>?>(null)

    fun init(ctx: Context) {
        val s = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        sp = s
        accentIndex = s.getInt("accent", 0)
        dark = s.getBoolean("dark", true)
        adaptive = s.getBoolean("adaptive", false)
        liquid = s.getBoolean("liquid", true)
        fade = s.getBoolean("fade", true)
        lyrics = s.getBoolean("lyrics", true)
        barBlur = s.getFloat("bBlur2", 8f)
        barRefH = s.getFloat("bRefH2", 24f)
        barRefA = s.getFloat("bRefA2", 24f)
        barAlpha = s.getFloat("bAlpha2", 0.4f)
        barTint = s.getInt("barTint", -1)
        iconIndex = s.getInt("iconIndex", 0)
    }

    fun save() {
        sp?.edit()
            ?.putInt("accent", accentIndex)
            ?.putBoolean("dark", dark)
            ?.putBoolean("adaptive", adaptive)
            ?.putBoolean("liquid", liquid)
            ?.putBoolean("fade", fade)
            ?.putBoolean("lyrics", lyrics)
            ?.putFloat("bBlur2", barBlur)
            ?.putFloat("bRefH2", barRefH)
            ?.putFloat("bRefA2", barRefA)
            ?.putFloat("bAlpha2", barAlpha)
            ?.putInt("barTint", barTint)
            ?.putInt("iconIndex", iconIndex)
            ?.apply()
    }

    fun update(block: AppSettings.() -> Unit) {
        block()
        save()
    }

    private fun brighten(c: Color): Color {
        return if (c.luminance() < 0.18f) lerp(c, Color.White, 0.38f) else c
    }

    private fun Color.luminance(): Float = 0.2126f * red + 0.7152f * green + 0.0722f * blue

    val accent: Color
        get() {
            val art = if (adaptive) artColors?.firstOrNull() else null
            val base = art ?: AccentPalette[accentIndex.coerceIn(0, AccentPalette.size - 1)].second
            return brighten(base)
        }

    val onBg: Color get() = if (dark) Color.White else Color(0xFF111114)
    val baseBg: Color get() = if (dark) Color(0xFF08080C) else Color(0xFFEFF1F6)

    private fun shift(c: Color, deg: Float): Color {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(c.toArgb(), hsv)
        hsv[0] = (hsv[0] + deg + 360f) % 360f
        hsv[1] = hsv[1].coerceIn(0.35f, 1f)
        hsv[2] = hsv[2].coerceIn(0.55f, 1f)
        return Color.hsv(hsv[0], hsv[1], hsv[2])
    }

    fun bgColors(): List<Color> {
        val art = if (adaptive) artColors else null
        if (art != null && art.isNotEmpty()) {
            return listOf(art[0], art.getOrElse(1) { shift(art[0], 40f) }, art.getOrElse(2) { shift(art[0], -50f) })
        }
        val a = accent
        return listOf(a, shift(a, 45f), shift(a, -55f))
    }
}

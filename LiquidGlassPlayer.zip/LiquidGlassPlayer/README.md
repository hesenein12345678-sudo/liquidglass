# Liquid Player

Android music player with Liquid Glass UI (Backdrop library by Kyant0).

Build: put `.github/workflows/build.yml` at the repo root, push to GitHub, run the "Build APK" action.
Local build: open in Android Studio (JDK 17) or run `gradle assembleDebug` (Gradle 8.13).

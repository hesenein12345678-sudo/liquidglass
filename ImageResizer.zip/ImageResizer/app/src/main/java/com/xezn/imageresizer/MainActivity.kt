package com.xezn.imageresizer

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = SettingsStore(this)
        setContent { App(settings) }
    }
}

private fun Modifier.appBackground(dark: Boolean, accent: Color): Modifier = this.drawBehind {
    val top = if (dark) Color(0xFF0B1020) else Color(0xFFF1F4FF)
    val bottom = if (dark) Color(0xFF151C3A) else Color(0xFFE3E9FF)
    drawRect(Brush.verticalGradient(listOf(top, bottom)))

    val a = if (dark) 0.55f else 0.40f
    val blobs = listOf(
        Triple(accent, Offset(size.width * 0.15f, size.height * 0.12f), size.width * 0.75f),
        Triple(Color(0xFFEC4899), Offset(size.width * 0.90f, size.height * 0.35f), size.width * 0.70f),
        Triple(Color(0xFF06B6D4), Offset(size.width * 0.10f, size.height * 0.62f), size.width * 0.70f),
        Triple(Color(0xFFF59E0B), Offset(size.width * 0.85f, size.height * 0.88f), size.width * 0.65f)
    )
    for ((color, center, radius) in blobs) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(color.copy(alpha = a), Color.Transparent),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )
    }
}

@Composable
fun App(settings: SettingsStore) {
    val dark = settings.darkMode
    val accent = AccentColors[settings.accentIndex]
    var tab by rememberSaveable { mutableStateOf(0) }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    val backdropAll = rememberLayerBackdrop()
    val backdropBg = rememberLayerBackdrop()

    val colorScheme = if (dark) {
        darkColorScheme(primary = accent)
    } else {
        lightColorScheme(primary = accent)
    }

    MaterialTheme(colorScheme = colorScheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            // الأزرار والبطاقات تأخذ الخلفية فقط، والشريط السفلي يأخذ كل المحتوى
            val uiForContent = UiCtx(backdropBg, dark, accent)
            val tabs = listOf(
                TabItem("الأبعاد", R.drawable.ic_tab_resize),
                TabItem("الحجم", R.drawable.ic_tab_size),
                TabItem("تواصل", R.drawable.ic_tab_contact),
                TabItem("الإعدادات", R.drawable.ic_tab_settings)
            )

            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .layerBackdrop(backdropAll)
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .layerBackdrop(backdropBg)
                            .appBackground(dark, accent)
                    )
                    Box(Modifier.fillMaxSize()) {
                        when (tab) {
                            0 -> ResizeScreen(uiForContent, settings)
                            1 -> SizeScreen(uiForContent, settings)
                            2 -> ContactScreen(uiForContent)
                            else -> SettingsScreen(uiForContent, settings)
                        }
                    }
                }

                GlassBottomBar(
                    backdrop = backdropAll,
                    tabs = tabs,
                    selected = tab,
                    onSelect = { tab = it },
                    dark = dark,
                    accent = accent,
                    refractionLevel = settings.refraction,
                    blurLevel = settings.blurLevel,
                    iridescenceLevel = settings.iridescence,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(start = 24.dp, end = 24.dp, bottom = 12.dp)
                )
            }
        }
    }
}

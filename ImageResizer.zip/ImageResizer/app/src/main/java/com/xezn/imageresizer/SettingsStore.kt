package com.xezn.imageresizer

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

val AccentColors: List<Color> = listOf(
    Color(0xFF2D6BFF), Color(0xFF7C3AED), Color(0xFFEC4899), Color(0xFFEF4444),
    Color(0xFFF97316), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFF14B8A6),
    Color(0xFF06B6D4), Color(0xFF4F46E5), Color(0xFF84CC16), Color(0xFFF43F5E),
    Color(0xFF64748B), Color(0xFF92400E)
)

val IconBackgrounds: List<Color> = listOf(
    Color(0xFF2D6BFF), Color(0xFF7C3AED), Color(0xFF10B981),
    Color(0xFFF97316), Color(0xFFEC4899), Color(0xFF111827)
)

data class ExportPrefs(
    val format: String,
    val useCustomName: Boolean,
    val customName: String,
    val useCustomFolder: Boolean,
    val folderUri: String
)

class SettingsStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var format by mutableStateOf(prefs.getString("format", "JPG") ?: "JPG")
        private set
    var useCustomName by mutableStateOf(prefs.getBoolean("use_custom_name", false))
        private set
    var customName by mutableStateOf(prefs.getString("custom_name", "") ?: "")
        private set
    var useCustomFolder by mutableStateOf(prefs.getBoolean("use_custom_folder", false))
        private set
    var folderUri by mutableStateOf(prefs.getString("folder_uri", "") ?: "")
        private set
    var darkMode by mutableStateOf(prefs.getBoolean("dark_mode", true))
        private set
    var accentIndex by mutableIntStateOf(prefs.getInt("accent_index", 0).coerceIn(0, AccentColors.size - 1))
        private set
    var iconIndex by mutableIntStateOf(prefs.getInt("icon_index", 0).coerceIn(0, IconBackgrounds.size - 1))
        private set
    var refraction by mutableFloatStateOf(prefs.getFloat("refraction", 0.7f))
        private set
    var blurLevel by mutableFloatStateOf(prefs.getFloat("blur_level", 0.4f))
        private set
    var iridescence by mutableFloatStateOf(prefs.getFloat("iridescence", 0.35f))
        private set

    fun updateFormat(value: String) {
        format = value
        prefs.edit().putString("format", value).apply()
    }

    fun updateUseCustomName(value: Boolean) {
        useCustomName = value
        prefs.edit().putBoolean("use_custom_name", value).apply()
    }

    fun updateCustomName(value: String) {
        customName = value
        prefs.edit().putString("custom_name", value).apply()
    }

    fun updateUseCustomFolder(value: Boolean) {
        useCustomFolder = value
        prefs.edit().putBoolean("use_custom_folder", value).apply()
    }

    fun updateFolderUri(value: String) {
        folderUri = value
        prefs.edit().putString("folder_uri", value).apply()
    }

    fun updateDarkMode(value: Boolean) {
        darkMode = value
        prefs.edit().putBoolean("dark_mode", value).apply()
    }

    fun updateAccent(value: Int) {
        accentIndex = value
        prefs.edit().putInt("accent_index", value).apply()
    }

    fun updateRefraction(value: Float) {
        refraction = value
        prefs.edit().putFloat("refraction", value).apply()
    }

    fun updateBlur(value: Float) {
        blurLevel = value
        prefs.edit().putFloat("blur_level", value).apply()
    }

    fun updateIridescence(value: Float) {
        iridescence = value
        prefs.edit().putFloat("iridescence", value).apply()
    }

    fun resetBarControls() {
        updateRefraction(0.7f)
        updateBlur(0.4f)
        updateIridescence(0.35f)
    }

    fun updateIcon(index: Int) {
        iconIndex = index
        prefs.edit().putInt("icon_index", index).apply()
        val pm = appContext.packageManager
        // فعّل الأيقونة الجديدة أولاً ثم عطّل الباقي
        pm.setComponentEnabledSetting(
            ComponentName(appContext.packageName, "com.xezn.imageresizer.Icon$index"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        for (i in IconBackgrounds.indices) {
            if (i != index) {
                pm.setComponentEnabledSetting(
                    ComponentName(appContext.packageName, "com.xezn.imageresizer.Icon$i"),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        }
    }

    fun exportPrefs(): ExportPrefs = ExportPrefs(
        format = format,
        useCustomName = useCustomName,
        customName = customName,
        useCustomFolder = useCustomFolder,
        folderUri = folderUri
    )
}

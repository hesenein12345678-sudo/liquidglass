package com.xezn.imageresizer

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

class LoadedImage(
    val uri: Uri,
    val name: String,
    val preview: Bitmap,
    val origW: Int,
    val origH: Int,
    val sizeBytes: Long,
    val sizeConventionSwapped: Boolean
)

data class SaveResult(val ok: Boolean, val message: String)

fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "—"
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0))
    }
}

object ImageUtils {

    private fun queryMeta(ctx: Context, uri: Uri): Pair<String, Long> {
        var name = "image"
        var size = -1L
        try {
            ctx.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    if (!c.isNull(0)) name = c.getString(0) ?: "image"
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        } catch (_: Exception) {
        }
        if (size < 0) {
            try {
                ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { size = it.length }
            } catch (_: Exception) {
            }
        }
        return Pair(name.substringBeforeLast('.', name), size)
    }

    fun loadImage(ctx: Context, uri: Uri, maxPreview: Int = 1600): LoadedImage {
        val (name, size) = queryMeta(ctx, uri)
        var srcW = 0
        var srcH = 0
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
            srcW = info.size.width
            srcH = info.size.height
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(srcW, srcH)
            if (m > maxPreview) {
                val s = maxPreview.toFloat() / m
                decoder.setTargetSize(
                    max(1, (srcW * s).roundToInt()),
                    max(1, (srcH * s).roundToInt())
                )
            }
        }
        val swapped = (bmp.width >= bmp.height) != (srcW >= srcH)
        val origW = if (swapped) srcH else srcW
        val origH = if (swapped) srcW else srcH
        return LoadedImage(uri, name, bmp, origW, origH, size, swapped)
    }

    /** يقص من الصورة (center crop) بدل التمديد: يكبّرها/يصغّرها لتغطي w×h ثم يقص الزايد من الأطراف */
    fun decodeAt(ctx: Context, img: LoadedImage, w: Int, h: Int): Bitmap {
        val s = max(w.toDouble() / img.origW, h.toDouble() / img.origH)
        val sw = max(w, ceil(img.origW * s).toInt())
        val sh = max(h, ceil(img.origH * s).toInt())
        val tw = if (img.sizeConventionSwapped) sh else sw
        val th = if (img.sizeConventionSwapped) sw else sh
        var bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, img.uri)) { decoder, _, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.setTargetSize(tw, th)
        }
        if (bmp.width != sw || bmp.height != sh) bmp = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val x = ((sw - w) / 2).coerceAtLeast(0)
        val y = ((sh - h) / 2).coerceAtLeast(0)
        return if (sw == w && sh == h) bmp else Bitmap.createBitmap(bmp, x, y, w, h)
    }

    fun decodeFull(ctx: Context, uri: Uri, maxPixels: Long = 36_000_000L): Bitmap {
        return ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val px = info.size.width.toLong() * info.size.height.toLong()
            if (px > maxPixels) {
                val s = sqrt(maxPixels.toDouble() / px.toDouble())
                decoder.setTargetSize(
                    max(1, (info.size.width * s).toInt()),
                    max(1, (info.size.height * s).toInt())
                )
            }
        }
    }

    private fun flatten(src: Bitmap): Bitmap {
        if (!src.hasAlpha()) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(android.graphics.Color.WHITE)
        canvas.drawBitmap(src, 0f, 0f, null)
        return out
    }

    private fun encode(bmp: Bitmap, format: String, quality: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        val cf = if (format == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        bmp.compress(cf, quality, bos)
        return bos.toByteArray()
    }

    fun exportResized(ctx: Context, img: LoadedImage, w: Int, h: Int, p: ExportPrefs): SaveResult {
        val decoded = decodeAt(ctx, img, w, h)
        val src = if (p.format == "PNG") decoded else flatten(decoded)
        val bytes = encode(src, p.format, 95)
        return save(ctx, bytes, img.name, p)
    }

    fun exportToSize(ctx: Context, img: LoadedImage, targetBytes: Long, p: ExportPrefs): SaveResult {
        var current = decodeFull(ctx, img.uri)
        if (p.format != "PNG") current = flatten(current)

        var best: ByteArray? = null
        var attempts = 0
        while (best == null && attempts < 14) {
            attempts++
            if (p.format == "PNG") {
                val bytes = encode(current, "PNG", 100)
                if (bytes.size.toLong() <= targetBytes) {
                    best = bytes
                } else {
                    current = shrink(current, targetBytes.toDouble() / bytes.size.toDouble()) ?: break
                }
            } else {
                var lo = 5
                var hi = 100
                var found: ByteArray? = null
                var lastSize = 0
                while (lo <= hi) {
                    val mid = (lo + hi) / 2
                    val bytes = encode(current, "JPG", mid)
                    lastSize = bytes.size
                    if (bytes.size.toLong() <= targetBytes) {
                        found = bytes
                        lo = mid + 1
                    } else {
                        hi = mid - 1
                    }
                }
                if (found != null) {
                    best = found
                } else {
                    current = shrink(current, targetBytes.toDouble() / max(1, lastSize).toDouble()) ?: break
                }
            }
        }
        val result = best ?: return SaveResult(false, "تعذر الوصول لهذا الحجم، جرّب حجماً أكبر")
        return save(ctx, result, img.name, p)
    }

    private fun shrink(bmp: Bitmap, sizeRatio: Double): Bitmap? {
        val factor = (sqrt(sizeRatio) * 0.95).coerceIn(0.3, 0.9)
        val nw = (bmp.width * factor).roundToInt()
        val nh = (bmp.height * factor).roundToInt()
        if (nw < 16 || nh < 16) return null
        return Bitmap.createScaledBitmap(bmp, nw, nh, true)
    }

    private fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()

    fun save(ctx: Context, bytes: ByteArray, originalName: String, p: ExportPrefs): SaveResult {
        val ext = if (p.format == "PNG") "png" else "jpg"
        val mime = if (p.format == "PNG") "image/png" else "image/jpeg"
        val rawName = if (p.useCustomName && p.customName.isNotBlank()) p.customName else originalName
        val base = sanitize(rawName).ifBlank { "image" }

        var folderFailed = false
        if (p.useCustomFolder) {
            if (p.folderUri.isNotBlank()) {
                try {
                    val tree = DocumentFile.fromTreeUri(ctx, Uri.parse(p.folderUri))
                    if (tree != null && tree.canWrite()) {
                        val file = tree.createFile(mime, base)
                        if (file != null) {
                            val os = ctx.contentResolver.openOutputStream(file.uri)
                            if (os != null) {
                                os.use { it.write(bytes) }
                                return SaveResult(true, "تم الحفظ في المجلد المخصص (${formatBytes(bytes.size.toLong())})")
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
            folderFailed = true
        }

        return try {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$base.$ext")
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return SaveResult(false, "تعذر إنشاء الملف")
            val os = resolver.openOutputStream(uri) ?: return SaveResult(false, "تعذر الكتابة في الملف")
            os.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            val prefix = if (folderFailed) "تعذر استخدام المجلد المخصص، " else ""
            SaveResult(true, "${prefix}تم الحفظ في التنزيلات (${formatBytes(bytes.size.toLong())})")
        } catch (e: Exception) {
            SaveResult(false, "فشل الحفظ: ${e.message}")
        }
    }
}

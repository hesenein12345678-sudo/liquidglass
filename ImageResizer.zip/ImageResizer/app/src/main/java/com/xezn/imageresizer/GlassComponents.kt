package com.xezn.imageresizer

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.shapes.Capsule
import com.kyant.shapes.RoundedRectangle

class UiCtx(
    val backdrop: Backdrop,
    val dark: Boolean,
    val accent: Color
) {
    val text: Color get() = if (dark) Color.White else Color(0xFF101828)
    val subText: Color get() = if (dark) Color(0xFFB6BFD6) else Color(0xFF475467)
    val fieldBg: Color get() = if (dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.06f)
    val glassSurface: Color get() = if (dark) Color(0xFF121212).copy(0.4f) else Color(0xFFFAFAFA).copy(0.4f)
}

/** بطاقة Liquid Glass حقيقية (blur + lens + highlight + shadow من مكتبة backdrop) */
fun Modifier.glassCard(ui: UiCtx, radius: Dp = 26.dp): Modifier = this
    .drawBackdrop(
        backdrop = ui.backdrop,
        shape = { RoundedRectangle(radius) },
        effects = {
            vibrancy()
            blur(8f.dp.toPx())
            lens(16f.dp.toPx(), 32f.dp.toPx())
        },
        onDrawSurface = { drawRect(ui.glassSurface) }
    )

/** زر Liquid Glass ملوّن (مثل LiquidButton في الـ catalog) */
@Composable
fun GlassButton(
    text: String,
    ui: UiCtx,
    modifier: Modifier = Modifier,
    tint: Color = ui.accent,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "buttonScale"
    )
    Box(
        modifier = modifier
            .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
            .drawBackdrop(
                backdrop = ui.backdrop,
                shape = { Capsule() },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(12f.dp.toPx(), 24f.dp.toPx())
                },
                layerBlock = {
                    scaleX = scale
                    scaleY = scale
                },
                onDrawSurface = { drawRect(tint.copy(alpha = 0.75f)) }
            )
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick
            )
            .height(54.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 18.dp)
        )
    }
}

/** تبديل بين خيارات: مسار زجاجي + مؤشر زجاجي ملوّن */
@Composable
fun Segmented(
    ui: UiCtx,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .drawBackdrop(
                backdrop = ui.backdrop,
                shape = { Capsule() },
                effects = {
                    vibrancy()
                    blur(8f.dp.toPx())
                    lens(10f.dp.toPx(), 20f.dp.toPx())
                },
                onDrawSurface = { drawRect(ui.fieldBg) }
            )
            .padding(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .then(
                        if (sel) Modifier.drawBackdrop(
                            backdrop = ui.backdrop,
                            shape = { Capsule() },
                            effects = {
                                vibrancy()
                                lens(8f.dp.toPx(), 16f.dp.toPx())
                            },
                            onDrawSurface = { drawRect(ui.accent.copy(alpha = 0.85f)) }
                        ) else Modifier
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onSelect(i) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (sel) Color.White else ui.text,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

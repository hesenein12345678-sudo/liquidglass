package com.xezn.imageresizer

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlin.math.roundToInt

class UiCtx(
    val backdrop: Backdrop,
    val dark: Boolean,
    val accent: Color
) {
    val text: Color get() = if (dark) Color.White else Color(0xFF101828)
    val subText: Color get() = if (dark) Color(0xFFB6BFD6) else Color(0xFF475467)
    val fieldBg: Color get() = if (dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.06f)
}

data class TabItem(val label: String, val iconRes: Int)

/** بطاقة زجاجية */
fun Modifier.glassCard(ui: UiCtx, radius: Dp = 26.dp): Modifier = this
    .drawBackdrop(
        backdrop = ui.backdrop,
        shape = { RoundedCornerShape(radius) },
        effects = {
            vibrancy()
            blur(10f.dp.toPx())
        },
        onDrawSurface = {
            drawRect(if (ui.dark) Color.White.copy(alpha = 0.09f) else Color.White.copy(alpha = 0.55f))
        }
    )
    .border(
        1.dp,
        if (ui.dark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.75f),
        RoundedCornerShape(radius)
    )

/** زر زجاجي ملوّن */
@Composable
fun GlassButton(
    text: String,
    ui: UiCtx,
    modifier: Modifier = Modifier,
    tint: Color = ui.accent,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "buttonScale"
    )
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (enabled) 1f else 0.45f
            }
            .height(54.dp)
            .drawBackdrop(
                backdrop = ui.backdrop,
                shape = { CircleShape },
                effects = {
                    vibrancy()
                    blur(4f.dp.toPx())
                    lens(14f.dp.toPx(), 26f.dp.toPx())
                },
                onDrawSurface = { drawRect(tint.copy(alpha = 0.62f)) }
            )
            .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 18.dp)
        )
    }
}

/** تبديل بين خيارات */
@Composable
fun Segmented(
    ui: UiCtx,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(ui.fieldBg)
            .padding(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(if (sel) ui.accent else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (sel) Color.White else ui.text,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** الشريط السفلي الزجاجي (Liquid Bottom Tabs) */
@Composable
fun GlassBottomBar(
    backdrop: Backdrop,
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    dark: Boolean,
    accent: Color,
    refractionLevel: Float,
    blurLevel: Float,
    iridescenceLevel: Float,
    modifier: Modifier = Modifier
) {
    // الشريط دائماً LTR داخلياً، والترتيب معكوس ليبدأ من اليمين مثل العربية
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val density = LocalDensity.current
        val n = tabs.size
        val padPx = with(density) { 6.dp.toPx() }
        var widthPx by remember { mutableIntStateOf(0) }
        val tabWidthPx = if (widthPx > 0) (widthPx - 2 * padPx) / n else 0f
        val selectedPos = n - 1 - selected
        val indicatorX by animateFloatAsState(
            targetValue = selectedPos * tabWidthPx,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
            label = "indicatorX"
        )
        val barHeight = 68.dp
        val iconTint = if (dark) Color.White else Color(0xFF101828)

        fun posToIndex(x: Float): Int {
            if (tabWidthPx <= 0f) return selected
            val pos = ((x - padPx) / tabWidthPx).toInt().coerceIn(0, n - 1)
            return n - 1 - pos
        }

        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(barHeight)
                .onSizeChanged { widthPx = it.width }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { CircleShape },
                    effects = {
                        vibrancy()
                        if (blurLevel > 0.01f) {
                            blur(blurLevel * 14f.dp.toPx())
                        }
                        if (refractionLevel > 0.01f) {
                            lens(
                                refractionLevel * 22f.dp.toPx(),
                                refractionLevel * 44f.dp.toPx(),
                                false,
                                iridescenceLevel > 0.01f
                            )
                        }
                    },
                    onDrawSurface = {
                        drawRect(if (dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.45f))
                        if (iridescenceLevel > 0.01f) {
                            val a = 0.30f * iridescenceLevel
                            drawRect(
                                Brush.horizontalGradient(
                                    listOf(
                                        Color(0xFFFF4D6D).copy(alpha = a),
                                        Color(0xFFFFC857).copy(alpha = a),
                                        Color(0xFF5CE08A).copy(alpha = a),
                                        Color(0xFF4DD6FF).copy(alpha = a),
                                        Color(0xFF7C6CFF).copy(alpha = a),
                                        Color(0xFFFF6BD6).copy(alpha = a)
                                    )
                                )
                            )
                        }
                    }
                )
                .border(
                    1.dp,
                    if (dark) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.8f),
                    CircleShape
                )
                .pointerInput(n, widthPx) {
                    detectTapGestures { offset -> onSelect(posToIndex(offset.x)) }
                }
                .pointerInput(n, widthPx) {
                    detectHorizontalDragGestures { change, _ -> onSelect(posToIndex(change.position.x)) }
                }
        ) {
            // مؤشر التبويب المحدد
            Box(
                modifier = Modifier
                    .offset { IntOffset((padPx + indicatorX).roundToInt(), padPx.roundToInt()) }
                    .size(
                        width = with(density) { tabWidthPx.toDp() },
                        height = barHeight - 12.dp
                    )
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.30f))
                    .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            )
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(6.dp)
            ) {
                for (pos in 0 until n) {
                    val index = n - 1 - pos
                    val tab = tabs[index]
                    val isSel = index == selected
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            painter = painterResource(tab.iconRes),
                            contentDescription = tab.label,
                            tint = if (isSel) accent else iconTint.copy(alpha = 0.75f),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = tab.label,
                            color = if (isSel) accent else iconTint.copy(alpha = 0.75f),
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

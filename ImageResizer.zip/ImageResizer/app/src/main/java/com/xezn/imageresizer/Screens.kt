package com.xezn.imageresizer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content
    )
}

@Composable
private fun Title(ui: UiCtx, title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = ui.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = ui.subText, fontSize = 14.sp)
    }
}

@Composable
private fun SectionLabel(ui: UiCtx, text: String) {
    Text(text, color = ui.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun NumberField(
    ui: UiCtx,
    value: String,
    label: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ui.accent,
            unfocusedBorderColor = ui.subText.copy(alpha = 0.5f),
            focusedLabelColor = ui.accent,
            unfocusedLabelColor = ui.subText,
            cursorColor = ui.accent,
            focusedTextColor = ui.text,
            unfocusedTextColor = ui.text
        ),
        modifier = modifier
    )
}

@Composable
private fun PreviewBox(ui: UiCtx, image: LoadedImage?, ratio: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        contentAlignment = Alignment.Center
    ) {
        if (image == null) {
            Text("لم يتم اختيار صورة بعد", color = ui.subText, fontSize = 14.sp)
        } else {
            Image(
                bitmap = image.preview.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .aspectRatio(ratio.coerceIn(0.05f, 20f))
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, ui.accent.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/*  تبويب 1: تحديد الأبعاد                                              */
/* ------------------------------------------------------------------ */
@Composable
fun ResizeScreen(ui: UiCtx, settings: SettingsStore) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var image by remember { mutableStateOf<LoadedImage?>(null) }
    var wText by remember { mutableStateOf("") }
    var hText by remember { mutableStateOf("") }
    var lockRatio by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val loaded = withContext(Dispatchers.IO) {
                    runCatching { ImageUtils.loadImage(ctx, uri) }.getOrNull()
                }
                busy = false
                if (loaded != null) {
                    image = loaded
                    wText = loaded.origW.toString()
                    hText = loaded.origH.toString()
                } else {
                    toast(ctx, "تعذر فتح الصورة")
                }
            }
        }
    }

    val w = wText.toIntOrNull() ?: 0
    val h = hText.toIntOrNull() ?: 0
    val current = image
    val ratio = if (w > 0 && h > 0) w.toFloat() / h.toFloat()
    else if (current != null) current.origW.toFloat() / current.origH.toFloat() else 1f

    ScreenColumn {
        Title(ui, "تحديد أبعاد الصورة", "اختر صورة وحدّد الطول والعرض وشاهد النتيجة فوراً")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassCard(ui)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PreviewBox(ui, current, ratio)
            if (current != null) {
                Text(
                    text = "الأصلية: ${current.origW} × ${current.origH}   |   الجديدة: ${if (w > 0) w else "-"} × ${if (h > 0) h else "-"}",
                    color = ui.subText,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        GlassButton(
            text = if (busy) "جارٍ التحميل..." else if (current == null) "اختيار صورة" else "تغيير الصورة",
            ui = ui,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassCard(ui)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionLabel(ui, "الأبعاد (بالبكسل)")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField(
                    ui = ui,
                    value = wText,
                    label = "العرض",
                    onChange = { v ->
                        val d = v.filter { it.isDigit() }.take(5)
                        wText = d
                        val img = image
                        val num = d.toIntOrNull()
                        if (lockRatio && img != null && num != null) {
                            hText = max(1, (num.toDouble() * img.origH / img.origW).roundToInt()).toString()
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
                NumberField(
                    ui = ui,
                    value = hText,
                    label = "الطول",
                    onChange = { v ->
                        val d = v.filter { it.isDigit() }.take(5)
                        hText = d
                        val img = image
                        val num = d.toIntOrNull()
                        if (lockRatio && img != null && num != null) {
                            wText = max(1, (num.toDouble() * img.origW / img.origH).roundToInt()).toString()
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("الحفاظ على النسبة", color = ui.text, fontSize = 15.sp)
                Switch(
                    checked = lockRatio,
                    onCheckedChange = { lockRatio = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = ui.accent)
                )
            }
        }

        GlassButton(
            text = if (busy) "جارٍ التصدير..." else "تصدير الصورة",
            ui = ui,
            enabled = !busy && current != null,
            modifier = Modifier.fillMaxWidth()
        ) {
            val img = image
            if (img == null) {
                toast(ctx, "اختر صورة أولاً")
            } else if (w < 1 || h < 1 || w > 12000 || h > 12000 || w.toLong() * h > 50_000_000L) {
                toast(ctx, "أبعاد غير صالحة (الحد الأقصى 12000 بكسل وأقل من 50 مليون بكسل)")
            } else {
                val prefs = settings.exportPrefs()
                scope.launch {
                    busy = true
                    val result = withContext(Dispatchers.Default) {
                        runCatching { ImageUtils.exportResized(ctx, img, w, h, prefs) }
                            .getOrElse { SaveResult(false, "فشل التصدير: ${it.message}") }
                    }
                    busy = false
                    toast(ctx, result.message)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  تبويب 2: تحديد الحجم                                                */
/* ------------------------------------------------------------------ */
@Composable
fun SizeScreen(ui: UiCtx, settings: SettingsStore) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var image by remember { mutableStateOf<LoadedImage?>(null) }
    var sizeText by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(0) } // 0 = KB, 1 = MB
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val loaded = withContext(Dispatchers.IO) {
                    runCatching { ImageUtils.loadImage(ctx, uri) }.getOrNull()
                }
                busy = false
                if (loaded != null) {
                    image = loaded
                } else {
                    toast(ctx, "تعذر فتح الصورة")
                }
            }
        }
    }

    val current = image
    val ratio = if (current != null) current.origW.toFloat() / current.origH.toFloat() else 1f

    ScreenColumn {
        Title(ui, "تحديد حجم الصورة", "اختر صورة وحدّد الحجم المطلوب بالكيلوبايت أو الميجابايت")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassCard(ui)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PreviewBox(ui, current, ratio)
            if (current != null) {
                Text(
                    text = "الحجم الحالي: ${formatBytes(current.sizeBytes)}   |   ${current.origW} × ${current.origH}",
                    color = ui.subText,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        GlassButton(
            text = if (busy) "جارٍ التحميل..." else if (current == null) "اختيار صورة" else "تغيير الصورة",
            ui = ui,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassCard(ui)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionLabel(ui, "الحجم المطلوب")
            NumberField(
                ui = ui,
                value = sizeText,
                label = "الحجم",
                onChange = { v -> sizeText = v.filter { it.isDigit() || it == '.' }.take(8) },
                modifier = Modifier.fillMaxWidth()
            )
            Segmented(ui, listOf("كيلوبايت (KB)", "ميجابايت (MB)"), unit, { unit = it })
            Text(
                text = "ملاحظة: صيغة PNG لا تدعم ضبط الجودة، لذلك يتم تصغير الأبعاد تلقائياً للوصول للحجم المطلوب.",
                color = ui.subText,
                fontSize = 12.sp
            )
        }

        GlassButton(
            text = if (busy) "جارٍ المعالجة..." else "ضغط وتصدير",
            ui = ui,
            enabled = !busy && current != null,
            modifier = Modifier.fillMaxWidth()
        ) {
            val img = image
            val value = sizeText.toDoubleOrNull()
            if (img == null) {
                toast(ctx, "اختر صورة أولاً")
            } else if (value == null || value <= 0.0) {
                toast(ctx, "أدخل حجماً صحيحاً")
            } else {
                val target = (value * (if (unit == 0) 1024.0 else 1024.0 * 1024.0)).toLong()
                if (target < 5 * 1024L) {
                    toast(ctx, "الحجم صغير جداً (الحد الأدنى 5 KB)")
                } else {
                    val prefs = settings.exportPrefs()
                    scope.launch {
                        busy = true
                        val result = withContext(Dispatchers.Default) {
                            runCatching { ImageUtils.exportToSize(ctx, img, target, prefs) }
                                .getOrElse { SaveResult(false, "فشل التصدير: ${it.message}") }
                        }
                        busy = false
                        toast(ctx, result.message)
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  تبويب 3: تواصل                                                      */
/* ------------------------------------------------------------------ */
private fun openLink(ctx: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    } catch (_: Exception) {
        toast(ctx, "تعذر فتح الرابط")
    }
}

@Composable
fun ContactScreen(ui: UiCtx) {
    val ctx = LocalContext.current
    ScreenColumn {
        Title(ui, "تواصل معي", "تابعني على حساباتي")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassCard(ui)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            GlassButton(
                text = "تيليجرام  @xezn9",
                ui = ui,
                tint = Color(0xFF229ED9),
                modifier = Modifier.fillMaxWidth()
            ) { openLink(ctx, "https://t.me/xezn9") }

            GlassButton(
                text = "تيك توك  @xezn99",
                ui = ui,
                tint = Color(0xFFFE2C55),
                modifier = Modifier.fillMaxWidth()
            ) { openLink(ctx, "https://www.tiktok.com/@xezn99") }
        }
    }
}

/* ------------------------------------------------------------------ */
/*  تبويب 4: الإعدادات                                                  */
/* ------------------------------------------------------------------ */
@Composable
private fun SettingsCard(ui: UiCtx, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(ui)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionLabel(ui, title)
        content()
    }
}

@Composable
private fun SliderRow(ui: UiCtx, label: String, value: Float, onChange: (Float) -> Unit) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = ui.text, fontSize = 14.sp)
            Text("${(value * 100).roundToInt()}%", color = ui.subText, fontSize = 13.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(
                thumbColor = ui.accent,
                activeTrackColor = ui.accent
            )
        )
    }
}

@Composable
fun SettingsScreen(ui: UiCtx, settings: SettingsStore) {
    val ctx = LocalContext.current

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            settings.updateFolderUri(uri.toString())
            settings.updateUseCustomFolder(true)
        }
    }

    ScreenColumn {
        Title(ui, "الإعدادات", "خصّص التطبيق كما تريد")

        SettingsCard(ui, "صيغة الصورة") {
            Segmented(
                ui,
                listOf("PNG", "JPG"),
                if (settings.format == "PNG") 0 else 1,
                { settings.updateFormat(if (it == 0) "PNG" else "JPG") }
            )
        }

        SettingsCard(ui, "اسم الملف عند الحفظ") {
            Segmented(
                ui,
                listOf("الاسم الأصلي", "اسم مخصص"),
                if (settings.useCustomName) 1 else 0,
                { settings.updateUseCustomName(it == 1) }
            )
            if (settings.useCustomName) {
                OutlinedTextField(
                    value = settings.customName,
                    onValueChange = { settings.updateCustomName(it) },
                    label = { Text("الاسم المخصص") },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ui.accent,
                        unfocusedBorderColor = ui.subText.copy(alpha = 0.5f),
                        focusedLabelColor = ui.accent,
                        unfocusedLabelColor = ui.subText,
                        cursorColor = ui.accent,
                        focusedTextColor = ui.text,
                        unfocusedTextColor = ui.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        SettingsCard(ui, "مكان الحفظ") {
            Segmented(
                ui,
                listOf("مجلد التنزيلات", "مجلد مخصص"),
                if (settings.useCustomFolder) 1 else 0,
                { settings.updateUseCustomFolder(it == 1) }
            )
            if (settings.useCustomFolder) {
                val folderName = remember(settings.folderUri) {
                    if (settings.folderUri.isBlank()) null
                    else runCatching {
                        DocumentFile.fromTreeUri(ctx, Uri.parse(settings.folderUri))?.name
                    }.getOrNull()
                }
                Text(
                    text = if (folderName != null) "المجلد الحالي: $folderName" else "لم يتم اختيار مجلد (سيتم الحفظ في التنزيلات)",
                    color = ui.subText,
                    fontSize = 13.sp
                )
                GlassButton(
                    text = "اختيار المجلد",
                    ui = ui,
                    modifier = Modifier.fillMaxWidth()
                ) { folderPicker.launch(null) }
            }
        }

        SettingsCard(ui, "نمط التطبيق") {
            Segmented(
                ui,
                listOf("داكن", "فاتح"),
                if (settings.darkMode) 0 else 1,
                { settings.updateDarkMode(it == 0) }
            )
        }

        SettingsCard(ui, "أيقونة التطبيق") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconBackgrounds.forEachIndexed { i, bg ->
                    val selected = settings.iconIndex == i
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(bg)
                            .border(
                                if (selected) 3.dp else 1.dp,
                                if (selected) ui.text else Color.White.copy(alpha = 0.3f),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                settings.updateIcon(i)
                                toast(ctx, "تم تغيير الأيقونة (قد يتطلب الأمر لحظات لتظهر في الشاشة الرئيسية)")
                            }
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ic_launcher_fg),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .scale(1.7f)
                        )
                    }
                }
            }
        }

        SettingsCard(ui, "لون الأزرار") {
            AccentColors.chunked(7).forEachIndexed { rowIndex, rowColors ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    rowColors.forEachIndexed { colIndex, c ->
                        val index = rowIndex * 7 + colIndex
                        val selected = settings.accentIndex == index
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (selected) 3.dp else 1.dp,
                                    if (selected) ui.text else Color.White.copy(alpha = 0.3f),
                                    CircleShape
                                )
                                .clickable { settings.updateAccent(index) }
                        )
                    }
                }
            }
        }

        SettingsCard(ui, "التحكم في الشريط السفلي") {
            SliderRow(ui, "شدة الانكسار", settings.refraction) { settings.updateRefraction(it) }
            SliderRow(ui, "شدة الضبابية", settings.blurLevel) { settings.updateBlur(it) }
            SliderRow(ui, "شدة اللون القزحي", settings.iridescence) { settings.updateIridescence(it) }
            Spacer(Modifier.height(2.dp))
            GlassButton(
                text = "إعادة الضبط",
                ui = ui,
                modifier = Modifier.fillMaxWidth()
            ) { settings.resetBarControls() }
            Text(
                text = "تأثير الانكسار يحتاج Android 13 فأعلى، والضبابية Android 12 فأعلى.",
                color = ui.subText,
                fontSize = 12.sp
            )
        }
    }
}

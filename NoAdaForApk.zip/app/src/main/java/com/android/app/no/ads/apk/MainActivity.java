package com.android.app.no.ads.apk;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private EditText urlInput;
    private LinearLayout resultCard;
    private TextView statusText;
    private TextView foundUrl;
    private Button resolveButton;
    private Button downloadButton;
    private String apkUrl;

    private static final Pattern APK_LINK = Pattern.compile(
        "(?i)(https?://[^\\s\"'<>]+?\\.apk(?:\\?[^\\s\"'<>]*)?|/[^\\s\"'<>]+?\\.apk(?:\\?[^\\s\"'<>]*)?)"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        resultCard = findViewById(R.id.resultCard);
        statusText = findViewById(R.id.statusText);
        foundUrl = findViewById(R.id.foundUrl);
        resolveButton = findViewById(R.id.resolveButton);
        downloadButton = findViewById(R.id.downloadButton);

        resolveButton.setOnClickListener(v -> resolveUrl());
        downloadButton.setOnClickListener(v -> {
            if (apkUrl != null) downloadApk(apkUrl);
        });
    }

    private void resolveUrl() {
        final String input = urlInput.getText().toString().trim();

        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            Toast.makeText(this, "Please enter a valid http/https link.", Toast.LENGTH_SHORT).show();
            return;
        }

        resultCard.setVisibility(View.VISIBLE);
        statusText.setText("● Analyzing link...");
        foundUrl.setText("");
        resolveButton.setEnabled(false);
        downloadButton.setEnabled(false);
        apkUrl = null;

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(input);
                connection = (HttpURLConnection) url.openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setRequestMethod("GET");
                connection.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"
                );
                connection.setRequestProperty(
                    "Accept",
                    "text/html,application/xhtml+xml,application/vnd.android.package-archive,*/*"
                );

                int code = connection.getResponseCode();
                String finalUrl = connection.getURL().toString();
                String type = connection.getContentType() == null ? "" : connection.getContentType();

                if (isApk(type, finalUrl)) {
                    showFound(finalUrl);
                    return;
                }

                InputStream stream = code >= 400
                    ? connection.getErrorStream()
                    : connection.getInputStream();

                String html = stream == null ? "" : readLimited(stream, 4000000);
                String candidate = extractApk(html, finalUrl);

                if (candidate != null) {
                    showFound(candidate);
                } else {
                    showError("No direct APK link found on this page.");
                }
            } catch (Exception e) {
                showError("Could not resolve this link.");
            } finally {
                if (connection != null) connection.disconnect();
                runOnUiThread(() -> resolveButton.setEnabled(true));
            }
        }).start();
    }

    private boolean isApk(String contentType, String url) {
        String t = contentType.toLowerCase();
        String u = url.toLowerCase();
        return t.contains("application/vnd.android.package-archive")
            || t.contains("application/octet-stream") && u.contains(".apk")
            || u.contains(".apk");
    }

    private String readLimited(InputStream stream, int maxChars) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null && out.length() < maxChars) {
            out.append(line).append('\n');
        }
        reader.close();
        return out.toString();
    }

    private String extractApk(String html, String baseUrl) {
        String clean = html
            .replace("\\/", "/")
            .replace("&amp;", "&")
            .replace("\\u0026", "&");

        Matcher matcher = APK_LINK.matcher(clean);
        if (!matcher.find()) return null;

        String value = matcher.group(1);

        if (value.startsWith("/")) {
            try {
                URI base = URI.create(baseUrl);
                value = new URI(
                    base.getScheme(),
                    base.getAuthority(),
                    value,
                    null,
                    null
                ).toString();
            } catch (Exception ignored) {
                return null;
            }
        }
        return value;
    }

    private void showFound(final String url) {
        runOnUiThread(() -> {
            apkUrl = url;
            statusText.setText("✓ APK FOUND");
            foundUrl.setText(url);
            downloadButton.setEnabled(true);
        });
    }

    private void showError(final String message) {
        runOnUiThread(() -> {
            statusText.setText("✕ " + message);
            foundUrl.setText("");
            downloadButton.setEnabled(false);
        });
    }

    private void downloadApk(String url) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle("APK Resolver");
            request.setDescription("Downloading APK");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );
            request.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "APKResolver-" + System.currentTimeMillis() + ".apk"
            );

            DownloadManager manager =
                (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);

            Toast.makeText(this, "Download started.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Download failed.", Toast.LENGTH_LONG).show();
        }
    }
}

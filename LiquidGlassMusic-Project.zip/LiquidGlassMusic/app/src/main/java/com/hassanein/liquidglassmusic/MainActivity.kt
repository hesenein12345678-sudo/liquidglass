package com.hassanein.liquidglassmusic

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Ink = Color(0xFF0A1020)
private val SurfaceBlue = Color(0xFF15223A)
private val AccentDefault = Color(0xFF8BE9FD)

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { MusicApp(player!!) }
    }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable
private fun MusicApp(player: ExoPlayer) {
    val context = LocalContext.current
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var selected by remember { mutableStateOf<Song?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var accent by remember { mutableStateOf(AccentDefault) }
    var dark by remember { mutableStateOf(true) }
    var adaptColors by remember { mutableStateOf(true) }
    var glassEnabled by remember { mutableStateOf(true) }
    var fadeEnabled by remember { mutableStateOf(false) }
    var lyricsEnabled by remember { mutableStateOf(true) }
    var bottomBlur by remember { mutableFloatStateOf(0.72f) }
    var bottomAlpha by remember { mutableFloatStateOf(0.22f) }
    var bottomTint by remember { mutableStateOf(Color(0xFF6B83A8)) }
    var subPage by remember { mutableStateOf("") }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    fun loadSongs() {
        val list = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        context.contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                list += Song(id, c.getString(titleCol) ?: "Unknown title", c.getString(artistCol) ?: "Unknown artist", ContentUris.withAppendedId(collection, id))
            }
        }
        songs = list
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) loadSongs() }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else permissionLauncher.launch(permission)
    }
    val bg = if (dark) Ink else Color(0xFFF0F4FA)
    val fg = if (dark) Color.White else Color(0xFF172033)
    val muted = if (dark) Color(0xFF9EADC4) else Color(0xFF657187)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = accent, background = bg, surface = SurfaceBlue) else lightColorScheme(primary = accent, background = bg, surface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(bg, SurfaceBlue.copy(alpha = if (dark) 0.92f else 0.45f), bg)))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(26.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text(if (subPage.isNotEmpty()) subPage else listOf("Your sound, beautifully", "Discover music", "Settings")[tab], color = fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(if (subPage.isNotEmpty()) "Liquid Glass Music" else "LIQUID GLASS MUSIC", color = muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color.White.copy(alpha = 0.08f), shape = CircleShape) {
                        IconButton(onClick = { if (tab == 1) query = "" else subPage = if (subPage.isEmpty()) "About" else "" }) {
                            Icon(if (tab == 1) Icons.Rounded.Search else Icons.Rounded.GraphicEq, null, tint = accent)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                when {
                    subPage == "About" -> AboutScreen(fg, muted, accent) { subPage = "" }
                    subPage == "Theme" -> ThemeScreen(accent, { accent = it }, dark, { dark = it }, adaptColors, { adaptColors = it }, fg, muted) { subPage = "" }
                    subPage == "More" -> MoreScreen(glassEnabled, { glassEnabled = it }, fadeEnabled, { fadeEnabled = it }, lyricsEnabled, { lyricsEnabled = it }, bottomBlur, { bottomBlur = it }, bottomAlpha, { bottomAlpha = it }, bottomTint, { bottomTint = it }, fg, muted)
                    tab == 0 -> HomeScreen(songs, selected, fg, muted, accent, { song ->
                        selected = song
                        player.setMediaItem(MediaItem.fromUri(song.uri)); player.prepare(); player.play()
                    }, { expanded = true }, query)
                    tab == 1 -> LibraryScreen(query, { query = it }, fg, muted, accent)
                    else -> SettingsScreen(fg, muted, accent) { subPage = it }
                }
                Spacer(Modifier.weight(1f))
                AnimatedVisibility(visible = selected != null && !expanded, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    selected?.let { song ->
                        GlassPanel(glassEnabled, accent, bottomAlpha, Modifier.fillMaxWidth().clickable { expanded = true }.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AlbumTile(song.title, accent, 48)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(song.title, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(song.artist, color = muted, fontSize = 12.sp, maxLines = 1)
                                }
                                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) { Icon(if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = accent) }
                                IconButton(onClick = { expanded = true }) { Icon(Icons.Rounded.ExpandLess, null, tint = fg) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                GlassPanel(glassEnabled, accent, bottomAlpha, Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        NavItem("Home", Icons.Rounded.Home, tab == 0, accent, fg) { tab = 0; subPage = "" }
                        NavItem("Library", Icons.Rounded.LibraryMusic, tab == 1, accent, fg) { tab = 1; subPage = "" }
                        NavItem("Settings", Icons.Rounded.Settings, tab == 2, accent, fg) { tab = 2; subPage = "" }
                    }
                }
            }
            AnimatedVisibility(visible = expanded && selected != null, enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom, animationSpec = spring()), exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom), modifier = Modifier.align(Alignment.BottomCenter)) {
                selected?.let { song ->
                    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SurfaceBlue.copy(alpha = .98f), bg))).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            IconButton(onClick = { expanded = false }) { Icon(Icons.Rounded.ExpandMore, null, tint = fg) }
                            Text("NOW PLAYING", color = muted, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.CenterVertically))
                            IconButton(onClick = { selected = null; expanded = false; player.stop() }) { Icon(Icons.Rounded.Close, null, tint = fg) }
                        }
                        Spacer(Modifier.height(42.dp))
                        AlbumTile(song.title, accent, 240)
                        Spacer(Modifier.height(34.dp))
                        Text(song.title, color = fg, fontSize = 25.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                        Text(song.artist, color = muted, fontSize = 16.sp)
                        Spacer(Modifier.height(36.dp))
                        var progress by remember { mutableFloatStateOf(0f) }
                        Slider(value = progress, onValueChange = { progress = it; player.seekTo((player.duration.coerceAtLeast(0) * it).toLong()) }, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(player.currentPosition), color = muted); Text(formatTime(player.duration.coerceAtLeast(0)), color = muted) }
                        Spacer(Modifier.height(18.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            IconButton(onClick = { player.seekToPreviousMediaItem() }) { Icon(Icons.Rounded.SkipPrevious, null, tint = fg, modifier = Modifier.size(38.dp)) }
                            Surface(shape = CircleShape, color = accent) {
                                IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }, modifier = Modifier.size(76.dp)) { Icon(if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Ink, modifier = Modifier.size(42.dp)) }
                            }
                            IconButton(onClick = { player.seekToNextMediaItem() }) { Icon(Icons.Rounded.SkipNext, null, tint = fg, modifier = Modifier.size(38.dp)) }
                        }
                        Spacer(Modifier.height(22.dp))
                        if (lyricsEnabled) OutlinedButton(onClick = { subPage = "Lyrics"; expanded = false }) { Icon(Icons.Rounded.Lyrics, null); Spacer(Modifier.width(8.dp)); Text("Lyrics / كلمات الأغنية") }
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
            if (subPage == "Lyrics") {
                Surface(Modifier.fillMaxSize(), color = bg) {
                    Column(Modifier.padding(24.dp)) {
                        IconButton(onClick = { subPage = ""; expanded = true }) { Icon(Icons.Rounded.ArrowBack, null, tint = fg) }
                        Text("Lyrics editor", color = fg, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("الصق الكلمات أو صحّحها يدوياً. جلب الكلمات تلقائياً يحتاج مزوّد كلمات مرخّص وواجهة API.", color = muted)
                        var lyrics by remember { mutableStateOf("") }
                        OutlinedTextField(value = lyrics, onValueChange = { lyrics = it }, modifier = Modifier.fillMaxWidth().weight(1f), label = { Text("Lyrics / الكلمات") })
                        Button(onClick = { subPage = ""; expanded = true }) { Text("Save lyrics") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassPanel(enabled: Boolean, accent: Color, alpha: Float, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Row(modifier.clip(shape).background(if (enabled) Brush.linearGradient(listOf(Color.White.copy(alpha = alpha + .06f), accent.copy(alpha = alpha * .32f), Color.White.copy(alpha = .035f))) else Brush.linearGradient(listOf(Color(0xFF263248), Color(0xFF263248))), content = content)
        .then(Modifier.padding(1.dp)).clip(shape).background(Color.White.copy(alpha = if (enabled) .035f else .08f)).padding(4.dp)) {}
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, accent: Color, fg: Color, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (selected) 1.04f else 1f, label = "navScale")
    Column(Modifier.scale(scale).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).background(if (selected) accent.copy(alpha = .18f) else Color.Transparent).padding(horizontal = 22.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected) accent else fg.copy(alpha = .72f), modifier = Modifier.size(22.dp))
        Text(label, color = if (selected) accent else fg.copy(alpha = .72f), fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun HomeScreen(songs: List<Song>, selected: Song?, fg: Color, muted: Color, accent: Color, onPlay: (Song) -> Unit, onExpand: () -> Unit, query: String) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Column { Text("Your collection", color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("${songs.size} tracks on this device", color = muted, fontSize = 13.sp) }
            Icon(Icons.Rounded.Headphones, null, tint = accent, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(14.dp))
        if (songs.isEmpty()) {
            GlassInfoCard(accent, fg, muted, "No local songs yet", "Allow audio access and add music files to your device. Your library will appear here.")
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, key = { it.id }) { song ->
                GlassPanel(true, accent, .14f, Modifier.fillMaxWidth().clickable { onPlay(song) }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AlbumTile(song.title, accent, 56)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(song.title, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(song.artist, color = muted, fontSize = 12.sp, maxLines = 1) }
                        IconButton(onClick = { onPlay(song) }) { Icon(Icons.Rounded.PlayCircle, null, tint = accent, modifier = Modifier.size(30.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(query: String, onQuery: (String) -> Unit, fg: Color, muted: Color, accent: Color) {
    Column {
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), singleLine = true, leadingIcon = { Icon(Icons.Rounded.Search, null) }, placeholder = { Text("Search songs on this device") })
        Spacer(Modifier.height(18.dp))
        GlassInfoCard(accent, fg, muted, "Online library", "Search and download require a licensed music provider/API. This starter does not scrape copyrighted music or fake search results. Connect a provider in MusicRepository.kt to enable online catalog, legal downloads, and Hussaini poetry.")
        Spacer(Modifier.height(12.dp))
        GlassInfoCard(accent, fg, muted, "Hussaini poetry", "A dedicated category can be supplied by your own catalog or a provider that grants streaming and download rights.")
    }
}

@Composable
private fun SettingsScreen(fg: Color, muted: Color, accent: Color, open: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Personalize your listening space", color = muted, fontSize = 14.sp)
        SettingsRow("Theme", "Accent colors, appearance, app icon", Icons.Rounded.Palette, accent, fg, muted) { open("Theme") }
        SettingsRow("About", "App information and social links", Icons.Rounded.Info, accent, fg, muted) { open("About") }
        SettingsRow("More", "Glass, audio and lyrics options", Icons.Rounded.Tune, accent, fg, muted) { open("More") }
    }
}
@Composable
private fun SettingsRow(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, fg: Color, muted: Color, click: () -> Unit) {
    GlassPanel(true, accent, .14f, Modifier.fillMaxWidth().clickable(onClick = click)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(title, color = fg, fontWeight = FontWeight.Bold); Text(desc, color = muted, fontSize = 12.sp) }
            Icon(Icons.Rounded.ChevronRight, null, tint = muted)
        }
    }
}
@Composable
private fun ThemeScreen(accent: Color, setAccent: (Color) -> Unit, dark: Boolean, setDark: (Boolean) -> Unit, adapt: Boolean, setAdapt: (Boolean) -> Unit, fg: Color, muted: Color, back: () -> Unit) {
    val colors = listOf(0xFF8BE9FD,0xFF80CBC4,0xFF69F0AE,0xFFFFD180,0xFFFFAB91,0xFFFF8A80,0xFFF48FB1,0xFFCE93D8,0xFFB39DDB,0xFF9FA8DA,0xFF90CAF9,0xFF81D4FA,0xFF80DEEA,0xFFA5D6A7,0xFFE6EE9C,0xFFFFF59D,0xFFFFCC80,0xFFBCAAA4,0xFFB0BEC5,0xFFFFFFFF,0xFFEF5350,0xFF7E57C2,0xFF26A69A,0xFFEC407A).map { Color(it) }
    Column {
        TextButton(onClick = back) { Icon(Icons.Rounded.ArrowBack, null); Text(" Back") }
        Text("Theme", color = fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Button color", color = muted); Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            colors.chunked(6).forEach { rowColors -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { rowColors.forEach { c -> Surface(shape = CircleShape, color = c, modifier = Modifier.size(34.dp).clickable { setAccent(c) }) { if (c == accent) Icon(Icons.Rounded.Check, null, tint = Color.Black) } } } }
        }
        HorizontalDivider(Modifier.padding(vertical = 16.dp))
        SettingSwitch("Adapt colors to album art", "Accent extraction hook; album-art palette is a future integration point", adapt, setAdapt, fg, muted)
        SettingSwitch("Dark theme", "Switch between dark and light", dark, setDark, fg, muted)
        Text("App icon", color = fg, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        Text("Android launcher icon changes require declared activity-alias entries and are not switched yet in this starter.", color = muted, fontSize = 12.sp)
        Text("Custom gallery icons need a persisted image URI and launcher alias workflow.", color = muted, fontSize = 12.sp)
    }
}
@Composable
private fun MoreScreen(glass: Boolean, setGlass: (Boolean) -> Unit, fade: Boolean, setFade: (Boolean) -> Unit, lyrics: Boolean, setLyrics: (Boolean) -> Unit, blur: Float, setBlur: (Float) -> Unit, alpha: Float, setAlpha: (Float) -> Unit, tint: Color, setTint: (Color) -> Unit, fg: Color, muted: Color) {
    Column {
        Text("More", color = fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Bottom bar glass", color = muted, modifier = Modifier.padding(top = 12.dp))
        Text("Blur strength  ${(blur * 100).toInt()}%", color = fg); Slider(value = blur, onValueChange = setBlur)
        Text("Transparency  ${(alpha * 100).toInt()}%", color = fg); Slider(value = alpha, onValueChange = setAlpha)
        Text("Bar tint", color = fg)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { listOf(Color(0xFF6B83A8), Color(0xFF8268A8), Color(0xFF438F91), Color(0xFFB07D63), Color(0xFF707070)).forEach { c -> Surface(color = c, shape = CircleShape, modifier = Modifier.size(30.dp).clickable { setTint(c) }) { if (c == tint) Icon(Icons.Rounded.Check, null, tint = Color.White) } } }
        Spacer(Modifier.height(14.dp))
        SettingSwitch("Liquid Glass (low-end mode)", "Use a simpler, lighter surface style", glass, setGlass, fg, muted)
        SettingSwitch("Audio fade / noise cleanup", "Crossfade is not a noise-removal DSP; DSP requires audio processing integration", fade, setFade, fg, muted)
        SettingSwitch("Lyrics", "Show the lyrics button and manual editor", lyrics, setLyrics, fg, muted)
    }
}
@Composable
private fun SettingSwitch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit, fg: Color, muted: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = fg, fontWeight = FontWeight.SemiBold); Text(desc, color = muted, fontSize = 12.sp) }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
@Composable
private fun AboutScreen(fg: Color, muted: Color, accent: Color, back: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = back, modifier = Modifier.align(Alignment.Start)) { Icon(Icons.Rounded.ArrowBack, null, tint = fg) }
        Spacer(Modifier.height(18.dp)); AlbumTile("Liquid Glass Music", accent, 120)
        Text("Liquid Glass Music", color = fg, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
        Text("A calm, glass-inspired space for your music.", color = muted)
        Spacer(Modifier.height(20.dp))
        GlassInfoCard(accent, fg, muted, "Features", "Local audio library • Mini player • Expanded player • Theme customization • Lyrics editor • Adaptive glass settings")
        Spacer(Modifier.height(18.dp))
        OutlinedButton(onClick = { }) { Icon(Icons.Rounded.Send, null); Spacer(Modifier.width(8.dp)); Text("Telegram · @xezn9") }
        OutlinedButton(onClick = { }) { Icon(Icons.Rounded.PlayCircle, null); Spacer(Modifier.width(8.dp)); Text("TikTok · @xezn99") }
    }
}
@Composable
private fun GlassInfoCard(accent: Color, fg: Color, muted: Color, title: String, body: String) {
    GlassPanel(true, accent, .14f, Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) { Text(title, color = fg, fontWeight = FontWeight.Bold, fontSize = 17.sp); Spacer(Modifier.height(6.dp)); Text(body, color = muted, fontSize = 13.sp, lineHeight = 19.sp) }
    }
}
@Composable
private fun AlbumTile(seed: String, accent: Color, size: Int) {
    val colors = listOf(accent.copy(alpha = .9f), Color(0xFF4E5F91), Color(0xFF17233B))
    Box(Modifier.size(size.dp).clip(RoundedCornerShape((size * .22f).dp)).background(Brush.linearGradient(colors)), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.GraphicEq, null, tint = Color.White.copy(alpha = .92f), modifier = Modifier.size((size * .48f).dp))
    }
}
private fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

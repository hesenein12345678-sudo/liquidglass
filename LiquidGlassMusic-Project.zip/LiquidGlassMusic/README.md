# Liquid Glass Music (Android)

A Kotlin + Jetpack Compose starter for a local Android music player. Built around the original **Backdrop / AndroidLiquidGlass** project by Kyant0, with a bottom-tab/player UI and settings scaffold.

## Open/build
- Android Studio: open this folder and sync Gradle.
- JDK 17 is required.
- `compileSdk 35`, `minSdk 26`, Android Gradle Plugin 8.7.3.
- The GitHub Actions workflow is provided separately in `github-workflows-standalone.yml`. Copy it into `.github/workflows/android.yml` in the repository.

## Important implementation notes
- Local audio playback and MediaStore listing are implemented with Media3.
- The online library is intentionally a provider integration placeholder. To support full songs and downloads, connect a service/API that grants the required streaming and download rights; do not scrape arbitrary copyrighted tracks.
- Lyrics are a manual editor placeholder. Automatic, accurate full lyrics require a licensed lyrics API and language-specific matching; no service can guarantee zero errors.
- The color adaptation toggle and glass strength controls are UI settings scaffolds; true album-art color extraction and original Backdrop rendering need integration against the current library API.
- App icon picker and changing launcher icon require activity-alias handling and persisted image selection, not just an in-app image picker.
- The original Backdrop library is early-stage and API changes are possible. This starter declares its upstream GitHub dependency; if JitPack resolution changes, vendor the upstream module from https://github.com/Kyant0/AndroidLiquidGlass and include `:backdrop` directly.

## Upstream
- https://github.com/Kyant0/AndroidLiquidGlass
- https://kyant.gitbook.io/backdrop

This project does not copy Backdrop Catalog's source UI. It uses the upstream library dependency and provides an independently implemented starter UI. Verify library integration and visual matching on device before release.

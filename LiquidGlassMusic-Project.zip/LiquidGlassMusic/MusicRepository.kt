package com.hassanein.liquidglassmusic

/**
 * Add your chosen licensed music catalog provider here.
 * Implement search, streaming URLs and downloads only where your provider's terms allow it.
 */
interface MusicRepository {
    suspend fun search(query: String): List<OnlineTrack>
    suspend fun download(track: OnlineTrack): java.io.File
}
data class OnlineTrack(val id: String, val title: String, val artist: String, val streamUrl: String, val artworkUrl: String?)

package com.apkforge.app

import android.content.ContentResolver
import android.net.Uri
import android.util.Base64
import android.util.Base64OutputStream
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

data class Run(val conclusion: String, val url: String)
data class Asset(val id: Long, val name: String)

class GitHub(private val token: String, private val repo: String) {

    private fun open(method: String, url: String, accept: String = "application/vnd.github+json"): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", accept)
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.setRequestProperty("User-Agent", "ApkForge")
        c.connectTimeout = 30_000
        c.readTimeout = 120_000
        return c
    }

    private fun body(c: HttpURLConnection): String {
        val s = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return s?.bufferedReader()?.use { it.readText() }.orEmpty()
    }

    private fun api(path: String) = "https://api.github.com/repos/$repo$path"

    fun defaultBranch(): String {
        val c = open("GET", api(""))
        val t = body(c)
        if (c.responseCode !in 200..299) throw IOException("GitHub ${c.responseCode}: $t")
        return JSONObject(t).getString("default_branch")
    }

    /** Streams the zip as base64 straight into the Contents API request (low memory). */
    fun uploadZip(cr: ContentResolver, uri: Uri, path: String, branch: String) {
        val c = open("PUT", api("/contents/$path"))
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setChunkedStreamingMode(0)
        val out = c.outputStream
        out.write("{\"message\":\"ApkForge job\",\"branch\":\"$branch\",\"content\":\"".toByteArray())
        val shield = object : OutputStream() {
            override fun write(b: Int) = out.write(b)
            override fun write(b: ByteArray, off: Int, len: Int) = out.write(b, off, len)
            override fun flush() = out.flush()
            override fun close() = out.flush() // keep the HTTP stream open
        }
        val b64 = Base64OutputStream(shield, Base64.NO_WRAP)
        (cr.openInputStream(uri) ?: throw IOException("Cannot read file")).use { it.copyTo(b64) }
        b64.close()
        out.write("\"}".toByteArray())
        out.close()
        val t = body(c)
        if (c.responseCode !in 200..201) throw IOException("Upload failed ${c.responseCode}: $t")
    }

    fun dispatch(workflow: String, ref: String, inputs: Map<String, String>) {
        val c = open("POST", api("/actions/workflows/$workflow/dispatches"))
        c.doOutput = true
        val j = JSONObject().put("ref", ref).put("inputs", JSONObject(inputs))
        c.outputStream.use { it.write(j.toString().toByteArray()) }
        val t = body(c)
        if (c.responseCode != 204) throw IOException("Dispatch failed ${c.responseCode}: $t")
    }

    suspend fun waitRun(workflow: String, jobId: String, say: (String) -> Unit): Run {
        var last = ""
        val deadline = System.currentTimeMillis() + 100L * 60 * 1000
        while (System.currentTimeMillis() < deadline) {
            delay(7_000)
            val c = open("GET", api("/actions/workflows/$workflow/runs?event=workflow_dispatch&per_page=15"))
            val t = body(c)
            if (c.responseCode !in 200..299) throw IOException("Runs ${c.responseCode}: $t")
            val arr = JSONObject(t).getJSONArray("workflow_runs")
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                if (r.optString("display_title").contains(jobId)) {
                    val st = r.getString("status")
                    if (st != last) { last = st; say("الحالة: $st") }
                    if (st == "completed") return Run(r.optString("conclusion"), r.getString("html_url"))
                    break
                }
            }
        }
        throw IOException("انتهى وقت الانتظار")
    }

    fun findApk(jobId: String): Asset {
        val c = open("GET", api("/releases/tags/build-$jobId"))
        val t = body(c)
        if (c.responseCode !in 200..299) throw IOException("Release ${c.responseCode}: $t")
        val a = JSONObject(t).getJSONArray("assets")
        val list = (0 until a.length()).map { a.getJSONObject(it) }.filter { it.getString("name").endsWith(".apk") }
        val pick = list.firstOrNull { it.getString("name").contains("debug") }
            ?: list.firstOrNull() ?: throw IOException("ما لكيت APK بالـ release")
        return Asset(pick.getLong("id"), pick.getString("name"))
    }

    fun download(assetId: Long, dest: File) {
        val c = open("GET", api("/releases/assets/$assetId"), "application/octet-stream")
        c.instanceFollowRedirects = false
        val code = c.responseCode
        val stream = if (code in 300..399) {
            // The redirect target (S3) must NOT receive our Authorization header.
            val loc = c.getHeaderField("Location") ?: throw IOException("No redirect location")
            (URL(loc).openConnection() as HttpURLConnection).inputStream
        } else if (code in 200..299) c.inputStream else throw IOException("Download $code")
        stream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
    }
}

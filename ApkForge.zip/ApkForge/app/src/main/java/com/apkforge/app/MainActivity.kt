package com.apkforge.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

private const val WORKFLOW = "build-user-project.yml"

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", 0) }
    val scope = rememberCoroutineScope()
    val backdrop = rememberLayerBackdrop()

    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var repo by remember { mutableStateOf(prefs.getString("repo", "") ?: "") }
    var zipUri by remember { mutableStateOf<Uri?>(null) }
    var zipName by remember { mutableStateOf("") }
    var jdk by remember { mutableStateOf("auto") }
    var gradle by remember { mutableStateOf("") }
    var task by remember { mutableStateOf("assembleDebug") }
    var busy by remember { mutableStateOf(false) }
    var apk by remember { mutableStateOf<File?>(null) }
    var runUrl by remember { mutableStateOf<String?>(null) }
    val log = remember { mutableStateListOf<String>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            zipUri = uri
            zipName = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: "project.zip"
        }
    }

    fun startBuild() {
        val uri = zipUri ?: return
        scope.launch {
            busy = true; apk = null; runUrl = null; log.clear()
            prefs.edit().putString("token", token).putString("repo", repo).apply()
            try {
                withContext(Dispatchers.IO) {
                    val gh = GitHub(token.trim(), repo.trim())
                    val id = java.lang.Long.toString(System.currentTimeMillis(), 36)
                    val branch = gh.defaultBranch()
                    log.add("رفع المشروع…")
                    gh.uploadZip(ctx.contentResolver, uri, "jobs/$id.zip", branch)
                    log.add("تشغيل البناء على GitHub Actions…")
                    gh.dispatch(
                        WORKFLOW, branch,
                        mapOf(
                            "zip_path" to "jobs/$id.zip",
                            "job_id" to id,
                            "java_version" to jdk,
                            "gradle_version" to gradle.trim(),
                            "build_task" to task.trim().ifEmpty { "assembleDebug" },
                        ),
                    )
                    val run = gh.waitRun(WORKFLOW, id) { log.add(it) }
                    runUrl = run.url
                    if (run.conclusion != "success") {
                        log.add("فشل البناء (${run.conclusion}). افتح صفحة التشغيل حتى تشوف السجل.")
                        return@withContext
                    }
                    log.add("تنزيل الـ APK…")
                    val dir = File(ctx.getExternalFilesDir(null), "apks").apply { mkdirs() }
                    val asset = gh.findApk(id)
                    val f = File(dir, asset.name)
                    gh.download(asset.id, f)
                    apk = f
                    log.add("جاهز: ${asset.name}")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.add("خطأ: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) { Background() }

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("ApkForge", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("حوّل مشروع Android (zip) إلى APK", color = Color.White.copy(alpha = .75f))

            GlassCard(backdrop) {
                Text("GitHub", color = Color.White, fontWeight = FontWeight.SemiBold)
                Field("Repo (owner/name)", repo) { repo = it }
                Field("Token", token, secret = true) { token = it }
            }

            GlassCard(backdrop) {
                Text("المشروع", color = Color.White, fontWeight = FontWeight.SemiBold)
                GlassButton(backdrop, if (zipName.isEmpty()) "اختر ملف ZIP" else zipName, !busy) {
                    picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                }
                Text("نسخة Java", color = Color.White.copy(alpha = .8f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto", "8", "11", "17", "21").forEach { v ->
                        Chip(backdrop, v, selected = jdk == v) { jdk = v }
                    }
                }
                Field("Gradle (اختياري، مثل 8.10.2)", gradle) { gradle = it }
                Field("Task", task) { task = it }
            }

            GlassButton(
                backdrop,
                if (busy) "جاري البناء…" else "ابنِ APK",
                enabled = !busy && zipUri != null && token.isNotBlank() && repo.contains("/"),
            ) { startBuild() }

            if (log.isNotEmpty()) {
                GlassCard(backdrop) {
                    log.forEach { Text(it, color = Color.White, fontSize = 14.sp) }
                }
            }

            apk?.let { f ->
                GlassButton(backdrop, "تثبيت ${f.name}", true) {
                    val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW)
                            .setDataAndType(u, "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                }
            }
            runUrl?.let { url ->
                GlassButton(backdrop, "فتح صفحة التشغيل (السجل)", true) {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }
}

@Composable
private fun Background() {
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E))),
        ),
    ) {
        Box(Modifier.offset(30.dp, 120.dp).size(220.dp).background(Color(0xFFFF4E9B), CircleShape))
        Box(Modifier.offset(180.dp, 380.dp).size(260.dp).background(Color(0xFF00D4FF), CircleShape))
        Box(Modifier.offset(10.dp, 640.dp).size(200.dp).background(Color(0xFFFFC837), CircleShape))
    }
}

@Composable
private fun Field(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = Color.White.copy(alpha = .8f),
            unfocusedBorderColor = Color.White.copy(alpha = .35f),
            focusedLabelColor = Color.White,
            unfocusedLabelColor = Color.White.copy(alpha = .7f),
            cursorColor = Color.White,
        ),
    )
}

@Composable
private fun GlassButton(backdrop: Backdrop, text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .glass(backdrop, radius = 100.dp, tint = Color.White.copy(alpha = if (enabled) .18f else .06f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White.copy(alpha = if (enabled) 1f else .5f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Chip(backdrop: Backdrop, text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.glass(backdrop, radius = 100.dp, tint = Color.White.copy(alpha = if (selected) .35f else .08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) { Text(text, color = Color.White) }
}

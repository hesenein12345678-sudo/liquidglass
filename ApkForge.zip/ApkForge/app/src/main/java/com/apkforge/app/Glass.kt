package com.apkforge.app

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

/** Real liquid-glass (blur + refraction) via the Backdrop library. Needs Android 13+, falls back to a translucent panel below. */
fun Modifier.glass(
    backdrop: Backdrop,
    radius: Dp = 28.dp,
    tint: Color = Color.White.copy(alpha = 0.12f),
): Modifier =
    if (Build.VERSION.SDK_INT >= 33) {
        this.drawBackdrop(
            backdrop = backdrop,
            shape = { RoundedCornerShape(radius) },
            effects = {
                vibrancy()
                blur(6.dp.toPx())
                lens(14.dp.toPx(), 28.dp.toPx())
            },
            onDrawSurface = { drawRect(tint) },
        )
    } else {
        this.clip(RoundedCornerShape(radius)).background(tint.copy(alpha = 0.28f))
    }

@Composable
fun GlassCard(backdrop: Backdrop, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().glass(backdrop).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content,
    )
}

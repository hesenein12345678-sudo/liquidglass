# ApkForge

تطبيق Android (Jetpack Compose + Liquid Glass من مكتبة Backdrop) ياخذ مشروع Android بصيغة ZIP ويبنيه APK
عن طريق GitHub Actions (يدعم Java 8 / 11 / 17 / 21 وأي Android SDK).

## التشغيل
1. سوّي Repo جديد على GitHub (يفضل Private) وارفع محتويات هذا المجلد بالكامل (مع .github).
2. Actions ← "Build ApkForge app" ← Run workflow ← نزّل ApkForge-debug.apk وثبته.
3. سوّي Fine-grained token لنفس الـ Repo بصلاحيات: Contents (Read/Write) و Actions (Read/Write).
4. بالتطبيق: اكتب owner/repo والـ token، اختر ZIP المشروع، اضغط "ابنِ APK".

## كيف يشتغل
التطبيق يرفع الـ zip إلى jobs/ ← يشغل build-user-project.yml ← الـ workflow يفك الضغط، يحدد Gradle/JDK تلقائياً،
يقبل رخص SDK، يبني، وينشر الـ APK بـ Release (build-<id>) ← التطبيق ينزله.

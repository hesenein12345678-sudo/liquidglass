package com.kyant.backdrop.catalog.demo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.backdropcatalog.components.LiquidBottomTab
import com.example.backdropcatalog.components.LiquidBottomTabs
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BackdropTabsScreen() }
    }
}

@Composable
private fun BackdropTabsScreen() {
    var selected by rememberSaveable { mutableIntStateOf(1) }
    val backdrop = rememberLayerBackdrop()

    Box(Modifier.fillMaxSize()) {
        AnimatedWallpaper(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
        )

        // The component itself is the Backdrop Catalog LiquidBottomTabs recipe.
        LiquidBottomTabs(
            selectedTabIndex = { selected },
            onTabSelected = { selected = it },
            backdrop = backdrop,
            tabsCount = 3,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 36.dp, vertical = 18.dp)
        ) {
            repeat(3) { index ->
                LiquidBottomTab(onClick = { selected = index }) {
                    FlightIcon(
                        contentDescription = "Tab ${index + 1}",
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        "Tab ${index + 1}",
                        style = TextStyle(Color.White, 12.sp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AnimatedWallpaper(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wallpaper")
    val t by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(
            tween(8000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "drift"
    )

    Canvas(
        modifier.background(
            Brush.linearGradient(
                listOf(Color(0xFF62D9C8), Color(0xFF37A8D8), Color(0xFF0757D8))
            )
        )
    ) {
        val w = size.width
        val h = size.height

        drawCircle(
            Color(0xFF9AF0D4).copy(alpha = 0.45f),
            radius = w * 0.50f,
            center = Offset(w * (0.06f + 0.10f * t), h * 0.12f)
        )
        drawCircle(
            Color(0xFF0868E6).copy(alpha = 0.72f),
            radius = w * 0.56f,
            center = Offset(w * (0.88f - 0.12f * t), h * 0.12f)
        )
        drawCircle(
            Color(0xFF43D4D1).copy(alpha = 0.30f),
            radius = w * 0.42f,
            center = Offset(w * (0.50f + 0.08f * t), h * 0.76f)
        )
    }
}


@Composable
private fun FlightIcon(
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    androidx.compose.foundation.Canvas(modifier) {
        val p = androidx.compose.ui.graphics.Path()
        val w = size.width
        val h = size.height
        // Simple solid airplane silhouette matching the reference icon.
        p.moveTo(w * .48f, h * .03f)
        p.lineTo(w * .56f, h * .03f)
        p.lineTo(w * .59f, h * .39f)
        p.lineTo(w * .92f, h * .56f)
        p.lineTo(w * .92f, h * .66f)
        p.lineTo(w * .59f, h * .59f)
        p.lineTo(w * .59f, h * .88f)
        p.lineTo(w * .72f, h * .98f)
        p.lineTo(w * .72f, h * 1.02f)
        p.lineTo(w * .50f, h * .92f)
        p.lineTo(w * .28f, h * 1.02f)
        p.lineTo(w * .28f, h * .98f)
        p.lineTo(w * .41f, h * .88f)
        p.lineTo(w * .41f, h * .59f)
        p.lineTo(w * .08f, h * .66f)
        p.lineTo(w * .08f, h * .56f)
        p.lineTo(w * .41f, h * .39f)
        p.close()
        drawPath(p, Color.White)
    }
}

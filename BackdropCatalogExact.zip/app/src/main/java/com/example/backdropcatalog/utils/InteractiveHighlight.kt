package com.example.backdropcatalog.utils

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.spring
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class InteractiveHighlight(
    val animationScope: CoroutineScope,
    val position: (size: Size, offset: Offset) -> Offset = { _, offset -> offset }
) {
    private val pressProgressAnimation = Animatable(0f, 0.001f)
    private var startPosition = Offset.Zero
    private val positionAnimation = Animatable(Offset.Zero, Offset.VectorConverter)

    val pressProgress: Float get() = pressProgressAnimation.value

    val modifier: Modifier = Modifier.drawWithContent {
        val p = pressProgressAnimation.value
        if (p > 0f) {
            drawRect(Color.White.copy(alpha = 0.08f * p), blendMode = BlendMode.Plus)
            val center = position(size, positionAnimation.value)
            drawCircle(
                color = Color.White.copy(alpha = 0.12f * p),
                radius = size.minDimension * 0.75f,
                center = center,
                blendMode = BlendMode.Plus
            )
        }
        drawContent()
    }

    val gestureModifier: Modifier = Modifier.pointerInput(animationScope) {
        detectDragGestures(
            onDragStart = {
                startPosition = it
                animationScope.launch {
                    positionAnimation.snapTo(startPosition)
                    pressProgressAnimation.animateTo(1f, spring(0.5f, 300f, 0.001f))
                }
            },
            onDragEnd = {
                animationScope.launch {
                    launch { pressProgressAnimation.animateTo(0f, spring(0.5f, 300f, 0.001f)) }
                    launch { positionAnimation.animateTo(startPosition, spring(0.5f, 300f)) }
                }
            },
            onDragCancel = {
                animationScope.launch {
                    pressProgressAnimation.animateTo(0f, spring(0.5f, 300f, 0.001f))
                }
            }
        ) { change, _ ->
            animationScope.launch { positionAnimation.snapTo(change.position) }
            change.consume()
        }
    }
}

# Backdrop Catalog Bottom Tabs Demo

This project uses the **actual `LiquidBottomTabs` / `LiquidBottomTab` implementation
from Kyant0/AndroidLiquidGlass's `kmp` branch, not a hand-drawn replacement.
The source is copied into the app so the component remains part of this project.

The underlying Backdrop library is `io.github.kyant0:backdrop:2.0.1` and Shapes is
`io.github.kyant0:shapes:1.2.1`.

## Build

Toolchain is pinned to:

- Android Gradle Plugin 9.3.2
- Gradle 9.7.1
- Kotlin/Compose compiler plugin 2.4.10
- compileSdk 37
- JDK 17

The GitHub Actions workflow installs **Gradle 9.7.1**. It does not try to install
the nonexistent Gradle 9.1 distribution that caused the previous failure.

## GitHub

Put this ZIP at the repository root as:

`BackdropCatalogExact.zip`

Then put `build-exact.yml` at:

`.github/workflows/build.yml`

The workflow unzips the project, runs `:app:assembleDebug`, and uploads the APK.

## Attribution

The bottom-tabs component is adapted from:

https://github.com/Kyant0/AndroidLiquidGlass

See `NOTICE`. The upstream project is Apache-2.0.

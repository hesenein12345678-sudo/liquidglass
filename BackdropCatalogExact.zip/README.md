# Backdrop Catalog Exact Bottom Tabs

This app is deliberately based on the **actual Bottom Tabs implementation used
by Backdrop Catalog**, rather than a hand-drawn approximation.

The component source is based on:

`app/src/commonMain/kotlin/com/kyant/backdrop/catalog/components/LiquidBottomTabs.kt`

and:

`LiquidBottomTab.kt`

The numeric glass recipe is retained: Capsule shape, vibrancy, 8dp blur,
24dp lens, combined backdrop for the moving selection capsule, chromatic
aberration, highlight, shadow and inner shadow.

The Backdrop engine is consumed from Maven Central (`io.github.kyant0:backdrop:2.0.1`).
The animated wallpaper is custom and sits underneath the Backdrop layer.

## Attribution

See `NOTICE`. The upstream AndroidLiquidGlass project is Apache-2.0.

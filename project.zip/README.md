# Backdrop Catalog Bottom Tabs Demo

Android Compose demo containing the Backdrop Catalog liquid bottom-tabs implementation.

## Build

- JDK 17
- Gradle 9.7.1
- Android Gradle Plugin 9.3.3
- Kotlin Compose compiler plugin 2.4.21
- compileSdk / targetSdk 37

The outer repository workflow unpacks this project and builds `:app:assembleDebug`.

Zip to APK - app project (Kotlin + Compose)

package com.ziptoapk.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Screen()
                }
            }
        }
    }
}

private fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "project.zip"

@Composable
fun Screen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var repo by remember { mutableStateOf(prefs.getString("repo", "") ?: "") }
    var branch by remember { mutableStateOf(prefs.getString("branch", "main") ?: "main") }
    var zipUri by remember { mutableStateOf<Uri?>(null) }
    var zipName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("جاهز") }
    var running by remember { mutableStateOf(false) }
    var apk by remember { mutableStateOf<File?>(null) }
    var runUrl by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            zipUri = uri
            zipName = displayName(ctx, uri)
        }
    }

    fun build() {
        val uri = zipUri ?: return
        prefs.edit().putString("token", token).putString("repo", repo).putString("branch", branch).apply()
        scope.launch {
            running = true
            apk = null
            runUrl = null
            try {
                val gh = GitHub(token.trim(), repo.trim(), branch.trim())
                val id = System.currentTimeMillis().toString(36)

                status = "جاري رفع المشروع..."
                withContext(Dispatchers.IO) { gh.uploadZip(ctx, uri, id) }

                status = "جاري تشغيل البناء..."
                withContext(Dispatchers.IO) { gh.dispatch(id) }

                var runId = 0L
                var tries = 0
                while (runId == 0L && tries < 40) {
                    delay(3000)
                    val r = withContext(Dispatchers.IO) { gh.findRun(id) }
                    if (r != null) {
                        runId = r.getLong("id")
                        runUrl = r.optString("html_url")
                    }
                    tries++
                }
                if (runId == 0L) throw IllegalStateException("لم يبدأ البناء. تأكد من وجود build-project.yml في الفرع")

                var conclusion = ""
                var seconds = 0
                while (true) {
                    delay(8000)
                    seconds += 8
                    val r = withContext(Dispatchers.IO) { gh.getRun(runId) }
                    if (r.getString("status") == "completed") {
                        conclusion = r.optString("conclusion")
                        break
                    }
                    status = "جاري البناء... ${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
                }

                if (conclusion != "success") {
                    status = "فشل البناء ($conclusion). افتح السجل لمعرفة السبب."
                } else {
                    status = "جاري تنزيل APK..."
                    val f = withContext(Dispatchers.IO) { gh.downloadApk(ctx, runId) }
                    withContext(Dispatchers.IO) { saveToDownloads(ctx, f, f.name) }
                    apk = f
                    status = "تم البناء ✔ وحُفظ في Downloads"
                    installApk(ctx, f)
                }
            } catch (e: Exception) {
                status = "خطأ: ${e.message}"
            } finally {
                running = false
            }
        }
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("تحويل المشروع إلى APK", style = MaterialTheme.typography.headlineSmall)

            OutlinedTextField(
                value = token, onValueChange = { token = it },
                label = { Text("GitHub Token") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = repo, onValueChange = { repo = it },
                label = { Text("المستودع (owner/repo)") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = branch, onValueChange = { branch = it },
                label = { Text("الفرع") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !running, modifier = Modifier.fillMaxWidth()) {
                Text(if (zipName.isEmpty()) "اختر ملف المشروع (ZIP)" else zipName)
            }

            Button(
                onClick = { build() },
                enabled = !running && zipUri != null && token.isNotBlank() && repo.contains("/"),
                modifier = Modifier.fillMaxWidth()
            ) { Text("ابنِ APK") }

            if (running) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(status)

            apk?.let { f ->
                Button(onClick = { installApk(ctx, f) }, modifier = Modifier.fillMaxWidth()) { Text("تثبيت APK") }
            }
            runUrl?.let { u ->
                OutlinedButton(
                    onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("فتح سجل البناء في GitHub") }
            }
        }
    }
}

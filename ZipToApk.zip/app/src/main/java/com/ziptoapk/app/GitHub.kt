package com.ziptoapk.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import androidx.core.content.FileProvider
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class GitHub(private val token: String, repo: String, private val branch: String) {

    private val api = "https://api.github.com/repos/$repo"
    private val jsonType = "application/json".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .build()

    private fun req(url: String) = Request.Builder().url(url)
        .header("Authorization", "Bearer $token")
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")

    private fun call(r: Request): String {
        client.newCall(r).execute().use { resp ->
            val body = resp.body.string()
            if (!resp.isSuccessful) throw IOException("GitHub ${resp.code}: ${body.take(300)}")
            return body
        }
    }

    /** Uploads the project zip into uploads/<id>.zip (Contents API, up to ~100 MB). */
    fun uploadZip(ctx: Context, uri: Uri, id: String) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("تعذر قراءة الملف")
        val payload = JSONObject()
            .put("message", "upload $id")
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
            .put("branch", branch)
        call(req("$api/contents/uploads/$id.zip").put(payload.toString().toRequestBody(jsonType)).build())
    }

    fun dispatch(id: String) {
        val payload = JSONObject()
            .put("ref", branch)
            .put("inputs", JSONObject().put("id", id).put("task", "assembleDebug"))
        call(req("$api/actions/workflows/build-project.yml/dispatches")
            .post(payload.toString().toRequestBody(jsonType)).build())
    }

    fun findRun(id: String): JSONObject? {
        val runs = JSONObject(call(req("$api/actions/runs?event=workflow_dispatch&per_page=20").build()))
            .getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (r.optString("display_title") == "Build $id") return r
        }
        return null
    }

    fun getRun(runId: Long): JSONObject = JSONObject(call(req("$api/actions/runs/$runId").build()))

    /** Downloads the artifact zip of the run and extracts the APK into the cache. */
    fun downloadApk(ctx: Context, runId: Long): File {
        val list = JSONObject(call(req("$api/actions/runs/$runId/artifacts").build())).getJSONArray("artifacts")
        var artifactId = 0L
        for (i in 0 until list.length()) {
            val a = list.getJSONObject(i)
            if (a.getString("name").startsWith("apk-")) artifactId = a.getLong("id")
        }
        if (artifactId == 0L) throw IOException("لا يوجد APK ناتج")

        val dir = File(ctx.cacheDir, "apk").apply { deleteRecursively(); mkdirs() }
        var best: File? = null
        // OkHttp drops the Authorization header on the cross-host redirect, as required.
        client.newCall(req("$api/actions/artifacts/$artifactId/zip").build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("GitHub ${resp.code}")
            ZipInputStream(resp.body.byteStream()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    if (!e.isDirectory && e.name.endsWith(".apk")) {
                        val f = File(dir, File(e.name).name)
                        f.outputStream().use { out -> zin.copyTo(out) }
                        val cur = best
                        if (cur == null || (cur.name.contains("unsigned") && !f.name.contains("unsigned"))) best = f
                    }
                    e = zin.nextEntry
                }
            }
        }
        return best ?: throw IOException("الأرشيف لا يحتوي APK")
    }
}

fun saveToDownloads(ctx: Context, f: File, name: String) {
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, name)
        put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
    ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
}

fun installApk(ctx: Context, f: File) {
    if (!ctx.packageManager.canRequestPackageInstalls()) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

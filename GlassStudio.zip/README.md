# Glass Studio

Android app (Jetpack Compose) using the Kyant0 **Backdrop** library for Liquid Glass.

- Pick a photo -> a draggable Liquid Glass rectangle with your device name (editable)
- Optional circular avatar (add / change / remove)
- Customize: blur, refraction, rounded corners on/off, corner radius
- Liquid Glass bottom tabs, buttons and toggle
- Home: animated anime night scene + "e4 Developer"

## Build
Push to GitHub -> Actions -> **Build APK** -> download the `GlassStudio-debug` artifact.

Locally: `gradle assembleDebug` (Gradle 8.11.1, JDK 17).

Note: the lens/refraction effect needs Android 13+ (API 33); older versions show blur only.

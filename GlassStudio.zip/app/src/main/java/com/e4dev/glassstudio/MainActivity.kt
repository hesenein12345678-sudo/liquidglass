package com.e4dev.glassstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val editorState = remember { EditorState(deviceName(ctx)) }
    val bgBackdrop = rememberLayerBackdrop()
    val barBackdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val tabs = remember {
        listOf(
            TabItem("Home", Icons.Filled.Home),
            TabItem("Studio", Icons.Filled.Edit)
        )
    }

    Box(Modifier.fillMaxSize()) {
        // everything the bottom bar can "see through"
        Box(Modifier.fillMaxSize().layerBackdrop(barBackdrop)) {
            // plain background, used by buttons/cards
            Box(Modifier.fillMaxSize().layerBackdrop(bgBackdrop)) {
                AppBackground()
            }
            when (tab) {
                0 -> HomeScreen()
                else -> EditorScreen(editorState, bgBackdrop)
            }
        }

        LiquidBottomTabs(
            selected = tab,
            onSelect = { tab = it },
            tabs = tabs,
            backdrop = barBackdrop,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 28.dp)
                .padding(bottom = 12.dp)
        )
    }
}

@Composable
fun AppBackground() {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0B1026), Color(0xFF1B1040), Color(0xFF2A0F3D))
                )
            )
            .drawBehind {
                fun blob(cx: Float, cy: Float, r: Float, c: Color) {
                    val center = Offset(cx, cy)
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(c.copy(alpha = 0.55f), Color.Transparent),
                            center = center,
                            radius = r
                        ),
                        radius = r,
                        center = center
                    )
                }
                blob(size.width * 0.2f, size.height * 0.18f, size.width * 0.7f, Color(0xFF7C4DFF))
                blob(size.width * 0.9f, size.height * 0.5f, size.width * 0.8f, Color(0xFFFF4D9D))
                blob(size.width * 0.3f, size.height * 0.85f, size.width * 0.8f, Color(0xFF00B0FF))
            }
    )
}

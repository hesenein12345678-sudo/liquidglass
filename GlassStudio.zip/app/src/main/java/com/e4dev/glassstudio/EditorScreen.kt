package com.e4dev.glassstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class EditorState(initialName: String) {
    var photo by mutableStateOf<ImageBitmap?>(null)
    var avatar by mutableStateOf<ImageBitmap?>(null)
    var name by mutableStateOf(initialName)
    var blur by mutableFloatStateOf(6f)
    var refraction by mutableFloatStateOf(24f)
    var radius by mutableFloatStateOf(32f)
    var rounded by mutableStateOf(true)
    var offset by mutableStateOf(Offset.Zero)
}

fun deviceName(ctx: Context): String {
    val n = runCatching { Settings.Global.getString(ctx.contentResolver, "device_name") }.getOrNull()
    if (!n.isNullOrBlank()) return n
    val m = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
    return if (Build.MODEL.startsWith(Build.MANUFACTURER, ignoreCase = true)) Build.MODEL else "$m ${Build.MODEL}"
}

fun loadBitmap(ctx: Context, uri: Uri, max: Int): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > max || bounds.outHeight / sample > max) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}.getOrNull()

@Composable
fun EditorScreen(state: EditorState, bg: Backdrop) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val previewBackdrop = rememberLayerBackdrop()

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b = withContext(Dispatchers.IO) { loadBitmap(ctx, uri, 2048) }
            if (b != null) state.photo = b.asImageBitmap()
        }
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b = withContext(Dispatchers.IO) { loadBitmap(ctx, uri, 512) }
            if (b != null) state.avatar = b.asImageBitmap()
        }
    }
    val imageOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Glass Studio", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)

        // ---------- Preview ----------
        Box(
            Modifier
                .fillMaxWidth()
                .height(420.dp)
                .clip(RoundedCornerShape(28.dp))
        ) {
            val photo = state.photo
            if (photo != null) {
                Image(
                    bitmap = photo,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().layerBackdrop(previewBackdrop)
                )
            } else {
                Box(
                    Modifier
                        .fillMaxSize()
                        .layerBackdrop(previewBackdrop)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF7C4DFF), Color(0xFFFF4D9D), Color(0xFFFFB74D))
                            )
                        )
                )
                Text(
                    "Choose a photo",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 16.sp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp)
                )
            }

            // the liquid glass rectangle
            Box(
                Modifier
                    .align(Alignment.Center)
                    .offset { IntOffset(state.offset.x.roundToInt(), state.offset.y.roundToInt()) }
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            state.offset += drag
                        }
                    }
                    .fillMaxWidth(0.88f)
                    .height(80.dp)
                    .drawBackdrop(
                        backdrop = previewBackdrop,
                        shape = {
                            RoundedCornerShape(if (state.rounded) state.radius.dp else 0.dp)
                        },
                        effects = {
                            vibrancy()
                            if (state.blur > 0f) blur(state.blur.dp.toPx())
                            if (state.refraction > 0f) {
                                lens(state.refraction.dp.toPx() * 0.6f, state.refraction.dp.toPx())
                            }
                        },
                        onDrawSurface = { drawRect(Color.White.copy(alpha = 0.10f)) }
                    )
            ) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val av = state.avatar
                    if (av != null) {
                        Image(
                            bitmap = av,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(46.dp).clip(CircleShape)
                        )
                        Spacer(Modifier.width(12.dp))
                    }
                    BasicTextField(
                        value = state.name,
                        onValueChange = { state.name = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Text(
            "Drag the glass rectangle • tap the name to edit it",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 12.sp
        )

        // ---------- Buttons ----------
        LiquidButton(
            onClick = { photoPicker.launch(imageOnly) },
            backdrop = bg,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Text("Choose photo", color = Color.White, fontWeight = FontWeight.Medium)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LiquidButton(
                onClick = { avatarPicker.launch(imageOnly) },
                backdrop = bg,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Filled.Face, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Text(
                    if (state.avatar == null) "Add avatar" else "Change avatar",
                    color = Color.White,
                    fontWeight = FontWeight.Medium
                )
            }
            if (state.avatar != null) {
                LiquidButton(
                    onClick = { state.avatar = null },
                    backdrop = bg,
                    tint = Color(0xFFFF3B30),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Delete, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Text("Remove", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }

        // ---------- Customization ----------
        Column(
            Modifier
                .fillMaxWidth()
                .drawBackdrop(
                    backdrop = bg,
                    shape = { RoundedCornerShape(28.dp) },
                    effects = {
                        vibrancy()
                        blur(12.dp.toPx())
                        lens(16.dp.toPx(), 32.dp.toPx())
                    },
                    onDrawSurface = { drawRect(Color.White.copy(alpha = 0.08f)) }
                )
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Customize", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)

            LabeledSlider("Blur", state.blur, 0f..24f) { state.blur = it }
            LabeledSlider("Refraction", state.refraction, 0f..48f) { state.refraction = it }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Rounded corners", color = Color.White, fontSize = 15.sp)
                LiquidToggle(checked = state.rounded, onCheckedChange = { state.rounded = it })
            }

            LabeledSlider("Corner radius", state.radius, 0f..40f, enabled = state.rounded) {
                state.radius = it
            }
        }

        Spacer(Modifier.height(110.dp))
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean = true,
    onChange: (Float) -> Unit
) {
    val alpha = if (enabled) 1f else 0.4f
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White.copy(alpha = alpha), fontSize = 15.sp)
            Text(
                value.roundToInt().toString(),
                color = Color.White.copy(alpha = 0.7f * alpha),
                fontSize = 15.sp
            )
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White.copy(alpha = 0.9f),
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
                disabledThumbColor = Color.White.copy(alpha = 0.4f),
                disabledActiveTrackColor = Color.White.copy(alpha = 0.3f),
                disabledInactiveTrackColor = Color.White.copy(alpha = 0.15f)
            )
        )
    }
}

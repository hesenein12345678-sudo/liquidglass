package com.e4dev.glassstudio

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun HomeScreen() {
    val sceneBackdrop = rememberLayerBackdrop()

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(sceneBackdrop)) {
            AnimeScene(Modifier.fillMaxSize())
        }

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 130.dp)
                .drawBackdrop(
                    backdrop = sceneBackdrop,
                    shape = { RoundedCornerShape(36.dp) },
                    effects = {
                        vibrancy()
                        blur(6.dp.toPx())
                        lens(20.dp.toPx(), 36.dp.toPx())
                    },
                    onDrawSurface = { drawRect(Color.White.copy(alpha = 0.10f)) }
                )
                .padding(horizontal = 36.dp, vertical = 18.dp)
        ) {
            Text(
                text = "e4 Developer",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private class Star(val x: Float, val y: Float, val r: Float, val m: Int, val ph: Float)
private class Petal(
    val x0: Float, val p0: Float, val n: Int, val amp: Float,
    val size: Float, val rot: Int, val ph: Float
)

/** Animated anime-style night scene: moon, stars, torii gate, sakura petals. */
@Composable
fun AnimeScene(modifier: Modifier = Modifier) {
    val stars = remember {
        List(80) {
            val r = Random(it + 7)
            Star(r.nextFloat(), r.nextFloat() * 0.55f, 0.6f + r.nextFloat() * 1.8f, 3 + r.nextInt(6), r.nextFloat())
        }
    }
    val petals = remember {
        List(34) {
            val r = Random(it + 101)
            Petal(
                r.nextFloat(), r.nextFloat(), 1 + r.nextInt(3), 0.02f + r.nextFloat() * 0.05f,
                10f + r.nextFloat() * 14f, 1 + r.nextInt(3), r.nextFloat()
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "scene")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(30000, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    val twoPi = (2 * PI).toFloat()

    Canvas(modifier) {
        val w = size.width
        val h = size.height

        // sky
        drawRect(
            Brush.verticalGradient(
                0f to Color(0xFF120A38),
                0.45f to Color(0xFF4B2A85),
                0.75f to Color(0xFFFF7BAC),
                1f to Color(0xFFFFC38A)
            )
        )

        // stars
        stars.forEach { s ->
            val a = 0.45f + 0.55f * (0.5f + 0.5f * sin(twoPi * (t * s.m + s.ph)))
            drawCircle(Color.White.copy(alpha = a), s.r, Offset(s.x * w, s.y * h))
        }

        // moon
        val moonC = Offset(w * 0.72f, h * 0.2f)
        val moonR = w * 0.15f
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFFFFF1C9).copy(alpha = 0.55f), Color.Transparent),
                center = moonC, radius = moonR * 3f
            ),
            radius = moonR * 3f, center = moonC
        )
        drawCircle(Color(0xFFFFF4D6), moonR, moonC)
        drawCircle(Color(0xFFF1DDB0).copy(alpha = 0.6f), moonR * 0.18f, moonC + Offset(-moonR * 0.35f, -moonR * 0.2f))
        drawCircle(Color(0xFFF1DDB0).copy(alpha = 0.6f), moonR * 0.12f, moonC + Offset(moonR * 0.3f, moonR * 0.3f))

        // far mountains
        val far = Path().apply {
            moveTo(0f, h * 0.72f)
            cubicTo(w * 0.2f, h * 0.55f, w * 0.4f, h * 0.78f, w * 0.6f, h * 0.62f)
            cubicTo(w * 0.8f, h * 0.5f, w * 0.9f, h * 0.7f, w, h * 0.6f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(far, Color(0xFF3A1F5E))

        // mid hill
        val mid = Path().apply {
            moveTo(0f, h * 0.8f)
            cubicTo(w * 0.25f, h * 0.68f, w * 0.5f, h * 0.84f, w * 0.75f, h * 0.74f)
            cubicTo(w * 0.9f, h * 0.69f, w * 0.95f, h * 0.76f, w, h * 0.74f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(mid, Color(0xFF26104A))

        // torii gate
        val gx = w * 0.3f
        val gBase = h * 0.775f
        val gw = w * 0.26f
        val gh = h * 0.16f
        val pillar = gw * 0.07f
        val red = Color(0xFFC62839)
        drawRect(red, Offset(gx - gw * 0.38f, gBase - gh), Size(pillar, gh))
        drawRect(red, Offset(gx + gw * 0.38f - pillar, gBase - gh), Size(pillar, gh))
        drawRect(red, Offset(gx - gw * 0.5f, gBase - gh - gh * 0.02f), Size(gw, gh * 0.09f))
        drawRect(red, Offset(gx - gw * 0.42f, gBase - gh * 0.8f), Size(gw * 0.84f, gh * 0.06f))
        drawRect(Color(0xFF8E1B28), Offset(gx - gw * 0.55f, gBase - gh - gh * 0.08f), Size(gw * 1.1f, gh * 0.06f))

        // foreground hill
        val near = Path().apply {
            moveTo(0f, h * 0.9f)
            cubicTo(w * 0.3f, h * 0.84f, w * 0.6f, h * 0.95f, w, h * 0.86f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(near, Color(0xFF12082B))

        // sakura branch (top-left)
        val branch = Path().apply {
            moveTo(-10f, h * 0.1f)
            cubicTo(w * 0.15f, h * 0.08f, w * 0.3f, h * 0.2f, w * 0.52f, h * 0.17f)
        }
        drawPath(branch, Color(0xFF2B1236), style = Stroke(width = 9f, cap = StrokeCap.Round))
        val blossoms = listOf(
            0.08f to 0.095f, 0.16f to 0.11f, 0.24f to 0.15f, 0.33f to 0.185f,
            0.42f to 0.185f, 0.5f to 0.17f, 0.2f to 0.07f, 0.3f to 0.13f
        )
        blossoms.forEachIndexed { i, (bx, by) ->
            val sway = sin(twoPi * (t * 2 + i * 0.13f)) * 3f
            drawCircle(Color(0xFFFFB7D5).copy(alpha = 0.95f), 14f, Offset(bx * w + sway, by * h))
            drawCircle(Color(0xFFFF8FBF).copy(alpha = 0.9f), 8f, Offset(bx * w + 8f + sway, by * h + 6f))
            drawCircle(Color.White.copy(alpha = 0.8f), 4f, Offset(bx * w - 4f + sway, by * h - 3f))
        }

        // falling petals
        petals.forEach { p ->
            val px = (((p.x0 + sin(twoPi * (t + p.ph)) * p.amp) % 1f) + 1f) % 1f * w
            val py = ((p.p0 + t * p.n) % 1f) * h * 1.1f - h * 0.05f
            rotate(degrees = 360f * (t * p.rot + p.ph), pivot = Offset(px, py)) {
                drawOval(
                    Color(0xFFFFB7D5).copy(alpha = 0.9f),
                    topLeft = Offset(px - p.size / 2, py - p.size * 0.35f),
                    size = Size(p.size, p.size * 0.7f)
                )
            }
        }
    }
}

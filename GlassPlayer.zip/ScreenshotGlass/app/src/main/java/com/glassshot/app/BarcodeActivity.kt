package com.glassshot.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class BarcodeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        setContent {
            GlassTheme {
                BarcodeDialog(uri) { finish() }
            }
        }
    }
}

@Composable
private fun BarcodeDialog(uri: Uri, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var results by remember { mutableStateOf<List<String>?>(null) }

    LaunchedEffect(uri) {
        val bmp = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
        results = if (bmp == null) {
            emptyList()
        } else {
            runCatching {
                BarcodeScanning.getClient().process(InputImage.fromBitmap(bmp, 0)).await()
                    .mapNotNull { it.rawValue }
                    .distinct()
            }.getOrDefault(emptyList())
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("الباركود") },
        text = {
            val list = results
            when {
                list == null -> CircularProgressIndicator()
                list.isEmpty() -> Text("لم يتم العثور على باركود في لقطة الشاشة.")
                else -> Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    list.forEachIndexed { i, v ->
                        if (i > 0) HorizontalDivider()
                        SelectionContainer { Text(v) }
                        Row(modifier = Modifier.padding(top = 2.dp)) {
                            TextButton(onClick = {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("barcode", v))
                                Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
                            }) { Text("نسخ") }
                            if (v.startsWith("http://", true) || v.startsWith("https://", true)) {
                                TextButton(onClick = {
                                    runCatching {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(v)))
                                    }
                                }) { Text("فتح الرابط") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } },
    )
}

package com.glassshot.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            SettingsStore.isEnabled(context) &&
            Settings.canDrawOverlays(context)
        ) {
            runCatching { ScreenshotService.start(context) }
        }
    }
}

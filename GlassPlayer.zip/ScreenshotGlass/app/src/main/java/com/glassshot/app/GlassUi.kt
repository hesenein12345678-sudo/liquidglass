package com.glassshot.app

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

const val GAP_DP = 10
const val PAD_DP = 28

data class PanelItem(val iconRes: Int, val label: String, val onClick: () -> Unit)

fun panelSizeDp(s: GlassSettings, n: Int): Pair<Int, Int> {
    val len = n * s.sizeDp + (n - 1).coerceAtLeast(0) * GAP_DP
    return if (s.vertical) s.sizeDp to len else len to s.sizeDp
}

fun glassShape(s: GlassSettings): CornerBasedShape =
    if (s.rounded) RoundedCornerShape(percent = 50) else RoundedCornerShape(8.dp)

fun surfaceFor(s: GlassSettings, light: Boolean): Color =
    if (light) Color.White.copy(alpha = (s.tint + 0.30f).coerceAtMost(0.85f))
    else Color.White.copy(alpha = s.tint)

/** The liquid-glass look (Backdrop 2.x): vibrancy -> blur -> lens (refraction). */
fun Modifier.glass(
    backdrop: LayerBackdrop,
    s: GlassSettings,
    shape: CornerBasedShape,
    surface: Color,
): Modifier {
    val rh = minOf(s.refractionDp, s.sizeDp / 2f)
    return this.drawBackdrop(
        backdrop = backdrop,
        shape = { shape },
        effects = {
            vibrancy()
            if (s.blurDp > 0f) blur(s.blurDp.dp.toPx())
            if (rh > 0f) lens(rh.dp.toPx(), (rh * 2f).dp.toPx())
        },
        onDrawSurface = { drawRect(surface) },
    )
}

@Composable
fun GlassIconButton(
    backdrop: LayerBackdrop,
    s: GlassSettings,
    shape: CornerBasedShape,
    surface: Color,
    iconTint: Color,
    item: PanelItem,
) {
    Box(
        modifier = Modifier
            .size(s.sizeDp.dp)
            .glass(backdrop, s, shape, surface)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = item.onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(item.iconRes),
            contentDescription = item.label,
            colorFilter = ColorFilter.tint(iconTint),
            modifier = Modifier.size((s.sizeDp * 0.46f).dp),
        )
    }
}

@Composable
fun GlassPanel(backdrop: LayerBackdrop, s: GlassSettings, items: List<PanelItem>, light: Boolean) {
    val shape = glassShape(s)
    val surface = surfaceFor(s, light)
    val tint = if (light) Color(0xFF111114) else Color.White
    if (s.vertical) {
        Column(verticalArrangement = Arrangement.spacedBy(GAP_DP.dp)) {
            items.forEach { GlassIconButton(backdrop, s, shape, surface, tint, it) }
        }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(GAP_DP.dp)) {
            items.forEach { GlassIconButton(backdrop, s, shape, surface, tint, it) }
        }
    }
}

@Composable
fun GlassPill(
    backdrop: LayerBackdrop,
    s: GlassSettings,
    label: String,
    iconRes: Int?,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(percent = 50)
    Row(
        modifier = Modifier
            .height(48.dp)
            .glass(backdrop, s.copy(sizeDp = 48), shape, Color.Black.copy(alpha = 0.35f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            )
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (iconRes != null) {
            Image(
                painter = painterResource(iconRes),
                contentDescription = label,
                colorFilter = ColorFilter.tint(Color.White),
                modifier = Modifier.size(20.dp),
            )
        }
        Text(text = label, color = Color.White, fontSize = 15.sp)
    }
}

/**
 * Overlay content shown above the system screenshot preview.
 * [region] is the part of the screenshot located exactly under the overlay window,
 * recorded invisibly as the backdrop so the buttons refract the real screen content.
 */
@Composable
fun OverlayRoot(region: Bitmap, s: GlassSettings, itemsState: State<List<PanelItem>>, light: Boolean) {
    val backdrop = rememberLayerBackdrop()
    val items by itemsState
    Box(Modifier.fillMaxSize()) {
        Image(
            bitmap = region.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = 0.01f }
                .layerBackdrop(backdrop),
        )
        Box(Modifier.align(Alignment.Center)) {
            GlassPanel(backdrop, s, items, light)
        }
    }
}

// ---------------------------------------------------------------- app-screen glass

val LocalBackdrop = compositionLocalOf<LayerBackdrop?> { null }
val CardGlass = GlassSettings(blurDp = 14f, refractionDp = 12f, sizeDp = 64, tint = 0.10f)

/** Liquid-glass surface for cards on the app screen (falls back to a flat tint without a backdrop). */
@Composable
fun Modifier.glassCard(shape: CornerBasedShape, alpha: Float = 0.08f): Modifier {
    val backdrop = LocalBackdrop.current
    val surface = Color.White.copy(alpha = alpha)
    return (if (backdrop != null) this.glass(backdrop, CardGlass, shape, surface)
    else this.background(surface, shape))
        .border(1.dp, Color.White.copy(alpha = 0.18f), shape)
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
    height: Dp = 46.dp,
) {
    val shape = RoundedCornerShape(percent = 50)
    val a = if (accent) 0.28f else 0.10f
    Box(
        modifier = modifier
            .height(height)
            .glassCard(shape, a)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            )
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = text, color = if (accent) Color(0xFFCFE0FF) else Color.White, fontSize = 15.sp)
    }
}

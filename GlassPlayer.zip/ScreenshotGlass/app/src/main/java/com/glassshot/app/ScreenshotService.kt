package com.glassshot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class ScreenshotService : Service() {

    companion object {
        const val ACTION_TEST = "com.glassshot.app.TEST"
        private const val CHANNEL = "glassshot_service"
        private const val NOTIF_ID = 1

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, ScreenshotService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, ScreenshotService::class.java))
        }

        fun test(c: Context) {
            ContextCompat.startForegroundService(
                c, Intent(c, ScreenshotService::class.java).setAction(ACTION_TEST)
            )
        }
    }

    private data class Shot(val id: Long, val uri: Uri)

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var observer: ContentObserver? = null
    private var overlay: ComposeView? = null
    private var owner: OverlayOwner? = null
    private var hideRunnable: Runnable? = null
    private var lastId = -1L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        goForeground()

        val obs = object : ContentObserver(main) {
            override fun onChange(selfChange: Boolean) {
                scope.launch { handleLatest(force = false) }
            }
        }
        contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs
        )
        observer = obs
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TEST) {
            scope.launch { handleLatest(force = true) }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        observer?.let { contentResolver.unregisterContentObserver(it) }
        dismissOverlay()
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "خدمة لقطات الشاشة", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_text)
            .setContentTitle("لقطات زجاجية تعمل")
            .setContentText("جاهز لعرض الأزرار عند التقاط لقطة شاشة")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------------------------------------------------------------- detection

    private suspend fun handleLatest(force: Boolean) {
        val shot = withContext(Dispatchers.IO) { queryLatest(force) }
        if (shot == null) {
            if (force) Toast.makeText(this, "لا توجد لقطات شاشة للتجربة", Toast.LENGTH_SHORT).show()
            return
        }
        if (!force && shot.id == lastId) return
        lastId = shot.id
        if (!Settings.canDrawOverlays(this)) return

        // Show the buttons right away; the barcode check runs afterwards in the background.
        showOverlay(shot.uri, SettingsStore.load(this))
    }

    private fun queryLatest(force: Boolean): Shot? {
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val path = MediaStore.Images.Media.RELATIVE_PATH
        val name = MediaStore.Images.Media.DISPLAY_NAME
        val added = MediaStore.Images.Media.DATE_ADDED
        val sel = StringBuilder("($path LIKE ? OR $path LIKE ? OR $name LIKE ? OR $name LIKE ?)")
        val args = mutableListOf("%creenshot%", "%لقطات%", "%creenshot%", "%لقطة%")
        if (!force) {
            sel.append(" AND $added >= ?")
            args.add(((System.currentTimeMillis() / 1000) - 20).toString())
        }
        contentResolver.query(
            collection,
            arrayOf(MediaStore.Images.Media._ID),
            sel.toString(),
            args.toTypedArray(),
            "$added DESC"
        )?.use { c ->
            if (c.moveToFirst()) {
                val id = c.getLong(0)
                return Shot(id, ContentUris.withAppendedId(collection, id))
            }
        }
        return null
    }

    private fun buildItems(uri: Uri, hasBarcode: Boolean) = buildList {
        add(PanelItem(R.drawable.ic_text, "تحديد النص") { openActivity(TextActivity::class.java, uri) })
        if (hasBarcode) add(PanelItem(R.drawable.ic_qr, "باركود") { openActivity(BarcodeActivity::class.java, uri) })
        add(PanelItem(R.drawable.ic_delete, "حذف") { openActivity(DeleteActivity::class.java, uri) })
        add(PanelItem(R.drawable.ic_share, "مشاركة") { share(uri) })
    }

    /** Decodes ONLY the part of the screenshot under the overlay window (much faster than a full decode). */
    private fun decodeRegion(
        uri: Uri, x: Int, y: Int, winW: Int, winH: Int, screenW: Int, pad: Int, panelW: Int, panelH: Int,
    ): Pair<Bitmap, Boolean>? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val iw = bounds.outWidth
        val ih = bounds.outHeight
        if (iw <= 0 || ih <= 0) return@runCatching null

        val scale = iw / screenW.toFloat()
        val rw = (winW * scale).roundToInt().coerceAtLeast(1)
        val rh = (winH * scale).roundToInt().coerceAtLeast(1)
        val region = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(region)

        val l = (x * scale).roundToInt().coerceIn(0, iw - 1)
        val t = (y * scale).roundToInt().coerceIn(0, ih - 1)
        val r = ((x + winW) * scale).roundToInt().coerceIn(l + 1, iw)
        val b = ((y + winH) * scale).roundToInt().coerceIn(t + 1, ih)
        val src = Rect(l, t, r, b)

        val part: Bitmap? = runCatching {
            contentResolver.openInputStream(uri)?.use { ins ->
                BitmapRegionDecoder.newInstance(ins)?.let { dec ->
                    try { dec.decodeRegion(src, null) } finally { dec.recycle() }
                }
            }
        }.getOrNull()

        if (part != null) {
            canvas.drawBitmap(part, l - x * scale, t - y * scale, null)
            part.recycle()
        } else {
            val full = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: return@runCatching null
            canvas.translate(-x * scale, -y * scale)
            canvas.drawBitmap(full, 0f, 0f, null)
            full.recycle()
        }
        val light = isLight(region, (pad * scale).roundToInt(), (panelW * scale).roundToInt(), (panelH * scale).roundToInt())
        region to light
    }.getOrNull()

    /** Down-scaled copy used only for barcode scanning. */
    private fun decodeForScan(uri: Uri): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    }.getOrNull()

    // ---------------------------------------------------------------- overlay

    private suspend fun showOverlay(uri: Uri, s: GlassSettings) {
        dismissOverlay()

        val d = resources.displayMetrics.density
        val bounds = wm.currentWindowMetrics.bounds
        val screenW = bounds.width()
        val screenH = bounds.height()

        // Window is always sized for the full set so a late-arriving barcode button fits.
        val (pw, ph) = panelSizeDp(s, buildItems(uri, true).size)
        val panelW = (pw * d).roundToInt()
        val panelH = (ph * d).roundToInt()
        val pad = (PAD_DP * d).roundToInt()
        val edge = (12 * d).roundToInt()
        val winW = panelW + pad * 2
        val winH = panelH + pad * 2

        val x = if (s.sideRight) screenW - edge - panelW - pad else edge - pad
        val y = ((screenH - panelH) * s.position).roundToInt() - pad

        val (region, light) = withContext(Dispatchers.IO) {
            decodeRegion(uri, x, y, winW, winH, screenW, pad, panelW, panelH)
        } ?: return

        val lp = WindowManager.LayoutParams(
            winW, winH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        val itemsState = mutableStateOf(buildItems(uri, !s.hideBarcodeIfNone))

        dismissOverlay()
        val o = OverlayOwner().also { it.create() }
        val view = ComposeView(this)
        view.setViewTreeLifecycleOwner(o)
        view.setViewTreeSavedStateRegistryOwner(o)
        view.setViewTreeViewModelStoreOwner(o)
        view.setContent { OverlayRoot(region, s, itemsState, light) }

        try {
            wm.addView(view, lp)
        } catch (e: Exception) {
            o.destroy()
            return
        }
        overlay = view
        owner = o

        val r = Runnable { dismissOverlay() }
        hideRunnable = r
        main.postDelayed(r, s.timeoutSec * 1000L)

        // Barcode check in the background: the button is added only if a barcode is found.
        if (s.hideBarcodeIfNone) {
            scope.launch {
                val found = withContext(Dispatchers.Default) {
                    val bmp = decodeForScan(uri) ?: return@withContext false
                    runCatching {
                        BarcodeScanning.getClient().process(InputImage.fromBitmap(bmp, 0)).await().isNotEmpty()
                    }.getOrDefault(false).also { bmp.recycle() }
                }
                if (found && overlay === view) itemsState.value = buildItems(uri, true)
            }
        }
    }

    private fun isLight(region: Bitmap, pad: Int, w: Int, h: Int): Boolean = runCatching {
        val x = pad.coerceIn(0, region.width - 1)
        val y = pad.coerceIn(0, region.height - 1)
        val cw = w.coerceAtMost(region.width - x).coerceAtLeast(1)
        val ch = h.coerceAtMost(region.height - y).coerceAtLeast(1)
        val crop = Bitmap.createBitmap(region, x, y, cw, ch)
        val small = Bitmap.createScaledBitmap(crop, 16, 16, true)
        val px = IntArray(256)
        small.getPixels(px, 0, 16, 0, 0, 16, 16)
        var sum = 0.0
        for (p in px) {
            sum += (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)) / 255.0
        }
        sum / 256.0 > 0.6
    }.getOrDefault(false)

    private fun dismissOverlay() {
        hideRunnable?.let { main.removeCallbacks(it) }
        hideRunnable = null
        overlay?.let { v ->
            runCatching { v.disposeComposition() }
            runCatching { wm.removeView(v) }
        }
        overlay = null
        owner?.destroy()
        owner = null
    }

    // ---------------------------------------------------------------- actions

    private fun openActivity(cls: Class<*>, uri: Uri) {
        dismissOverlay()
        startActivity(
            Intent(this, cls).setData(uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun share(uri: Uri) {
        dismissOverlay()
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(
            Intent.createChooser(send, "مشاركة لقطة الشاشة")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

package com.glassshot.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class TextActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        val s = SettingsStore.load(this)
        setContent {
            GlassTheme {
                TextScreen(uri, s) { finish() }
            }
        }
    }
}

private data class OcrLine(val text: String, val box: Rect)

@Composable
private fun TextScreen(uri: Uri, s: GlassSettings, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var lines by remember { mutableStateOf<List<OcrLine>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val selected = remember { mutableStateListOf<Int>() }
    var translateText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uri) {
        val bmp = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
        bitmap = bmp
        if (bmp != null) {
            val result = runCatching {
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(InputImage.fromBitmap(bmp, 0)).await()
            }.getOrNull()
            lines = result?.textBlocks
                ?.flatMap { it.lines }
                ?.mapNotNull { l -> l.boundingBox?.let { OcrLine(l.text, it) } }
                .orEmpty()
        }
        loading = false
    }

    fun currentText(): String {
        val idx = if (selected.isEmpty()) lines.indices.toList() else selected.sorted()
        return idx.joinToString("\n") { lines[it].text }
    }

    val backdrop = rememberLayerBackdrop()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val bmp = bitmap
        if (bmp != null) {
            val imageBitmap = remember(bmp) { bmp.asImageBitmap() }
            BoxWithConstraints(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
                val wPx = constraints.maxWidth.toFloat()
                val hPx = constraints.maxHeight.toFloat()
                val scale = minOf(wPx / bmp.width, hPx / bmp.height)
                val ox = (wPx - bmp.width * scale) / 2f
                val oy = (hPx - bmp.height * scale) / 2f

                Image(
                    bitmap = imageBitmap,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(lines) {
                            detectTapGestures { p ->
                                val ix = ((p.x - ox) / scale).toInt()
                                val iy = ((p.y - oy) / scale).toInt()
                                val m = 14
                                val idx = lines.indexOfFirst { l ->
                                    ix >= l.box.left - m && ix <= l.box.right + m &&
                                        iy >= l.box.top - m && iy <= l.box.bottom + m
                                }
                                if (idx >= 0) {
                                    if (selected.contains(idx)) selected.remove(idx) else selected.add(idx)
                                }
                            }
                        }
                ) {
                    lines.forEachIndexed { i, l ->
                        val sel = selected.contains(i)
                        val tl = Offset(ox + l.box.left * scale, oy + l.box.top * scale)
                        val sz = Size(l.box.width() * scale, l.box.height() * scale)
                        drawRoundRect(
                            color = if (sel) Color(0x663B82F6) else Color(0x33FFFFFF),
                            topLeft = tl, size = sz, cornerRadius = CornerRadius(8f, 8f)
                        )
                        drawRoundRect(
                            color = if (sel) Color(0xFF3B82F6) else Color(0x99FFFFFF),
                            topLeft = tl, size = sz, cornerRadius = CornerRadius(8f, 8f),
                            style = Stroke(width = 2f)
                        )
                    }
                }
            }
        }

        // Top: close + hint
        Row(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassIconButton(
                backdrop, s.copy(sizeDp = 44), glassShape(s), Color.Black.copy(alpha = 0.35f), Color.White,
                PanelItem(R.drawable.ic_close, "إغلاق", onClose)
            )
            Box(
                Modifier
                    .background(Color(0x99000000), RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = when {
                        loading -> "جارٍ التعرف على النص…"
                        lines.isEmpty() -> "لم يُعثر على نص (التعرف يدعم الحروف اللاتينية)"
                        else -> "اضغط على النص لتحديده"
                    },
                    color = Color.White, fontSize = 13.sp
                )
            }
        }

        // Bottom actions
        if (lines.isNotEmpty()) {
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GlassPill(backdrop, s, "تحديد الكل", null) {
                    selected.clear()
                    selected.addAll(lines.indices)
                }
                GlassPill(backdrop, s, "نسخ", R.drawable.ic_copy) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("text", currentText()))
                    Toast.makeText(ctx, "تم نسخ النص", Toast.LENGTH_SHORT).show()
                }
                GlassPill(backdrop, s, "ترجمة", R.drawable.ic_translate) {
                    translateText = currentText()
                }
            }
        }
    }

    translateText?.let { t ->
        TranslateDialog(t, s.targetLang) { translateText = null }
    }
}

@Composable
private fun TranslateDialog(text: String, target: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var result by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(text, target) {
        result = null
        error = null
        try {
            val tag = LanguageIdentification.getClient().identifyLanguage(text).await()
            val source = TranslateLanguage.fromLanguageTag(tag) ?: TranslateLanguage.ENGLISH
            if (source == target) {
                result = text
            } else {
                val translator = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(source)
                        .setTargetLanguage(target)
                        .build()
                )
                try {
                    translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                    result = translator.translate(text).await()
                } finally {
                    translator.close()
                }
            }
        } catch (e: Exception) {
            error = "تعذّرت الترجمة. تأكد من الاتصال بالإنترنت (لتنزيل نموذج اللغة أول مرة)."
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الترجمة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                when {
                    error != null -> Text(error!!)
                    result == null -> CircularProgressIndicator()
                    else -> SelectionContainer { Text(result!!) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                result?.let {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("translation", it))
                    Toast.makeText(ctx, "تم نسخ الترجمة", Toast.LENGTH_SHORT).show()
                }
            }) { Text("نسخ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
    )
}

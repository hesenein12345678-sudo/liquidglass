package com.glassshot.app

import android.content.Context

data class GlassSettings(
    val rounded: Boolean = true,
    val sizeDp: Int = 52,
    val blurDp: Float = 4f,
    val refractionDp: Float = 14f,
    val tint: Float = 0.12f,
    val sideRight: Boolean = true,
    val vertical: Boolean = true,
    val position: Float = 0.55f,
    val timeoutSec: Int = 8,
    val hideBarcodeIfNone: Boolean = false,
    val targetLang: String = "ar",
)

val LANGS = listOf(
    "ar" to "العربية",
    "en" to "English",
    "fa" to "فارسی",
    "tr" to "Türkçe",
    "fr" to "Français",
    "de" to "Deutsch",
    "es" to "Español",
    "ru" to "Русский",
)

object SettingsStore {
    private const val NAME = "glass_prefs"
    private fun sp(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun load(c: Context): GlassSettings {
        val p = sp(c)
        val d = GlassSettings()
        return GlassSettings(
            rounded = p.getBoolean("rounded", d.rounded),
            sizeDp = p.getInt("sizeDp", d.sizeDp),
            blurDp = p.getFloat("blurDp", d.blurDp),
            refractionDp = p.getFloat("refractionDp", d.refractionDp),
            tint = p.getFloat("tint", d.tint),
            sideRight = p.getBoolean("sideRight", d.sideRight),
            vertical = p.getBoolean("vertical", d.vertical),
            position = p.getFloat("position", d.position),
            timeoutSec = p.getInt("timeoutSec", d.timeoutSec),
            hideBarcodeIfNone = p.getBoolean("hideBarcodeIfNone", d.hideBarcodeIfNone),
            targetLang = p.getString("targetLang", d.targetLang) ?: d.targetLang,
        )
    }

    fun save(c: Context, s: GlassSettings) {
        sp(c).edit()
            .putBoolean("rounded", s.rounded)
            .putInt("sizeDp", s.sizeDp)
            .putFloat("blurDp", s.blurDp)
            .putFloat("refractionDp", s.refractionDp)
            .putFloat("tint", s.tint)
            .putBoolean("sideRight", s.sideRight)
            .putBoolean("vertical", s.vertical)
            .putFloat("position", s.position)
            .putInt("timeoutSec", s.timeoutSec)
            .putBoolean("hideBarcodeIfNone", s.hideBarcodeIfNone)
            .putString("targetLang", s.targetLang)
            .apply()
    }

    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("enabled", v).apply()
    }
}

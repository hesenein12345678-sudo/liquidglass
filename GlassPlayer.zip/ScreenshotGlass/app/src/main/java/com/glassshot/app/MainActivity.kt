package com.glassshot.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val tick = mutableIntStateOf(0)

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { tick.intValue++ }

    private fun mediaPermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun requestPerms() {
        val list = mutableListOf(mediaPermission())
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(list.toTypedArray())
    }

    private fun hasMedia() =
        ContextCompat.checkSelfPermission(this, mediaPermission()) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GlassTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(tick.intValue) { requestPerms() }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
        if (SettingsStore.isEnabled(this) && Settings.canDrawOverlays(this) && hasMedia()) {
            runCatching { ScreenshotService.start(this) }
        }
    }
}

@Composable
private fun MainScreen(tick: Int, onRequestPerms: () -> Unit) {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(SettingsStore.load(ctx)) }
    var enabled by remember { mutableStateOf(SettingsStore.isEnabled(ctx)) }

    fun upd(n: GlassSettings) {
        s = n
        SettingsStore.save(ctx, n)
    }

    val hasOverlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val hasMedia = remember(tick) {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }
    val hasNotif = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }
    val noBattery = remember(tick) {
        (ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager)
            .isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val ready = hasOverlay && hasMedia

    val bg = rememberLayerBackdrop()
    CompositionLocalProvider(LocalBackdrop provides bg) {
    Box(Modifier.fillMaxSize()) {
    Canvas(Modifier.fillMaxSize().layerBackdrop(bg)) {
        drawRect(Color(0xFF0B0B0F))
        fun blob(c: Color, cx: Float, cy: Float, r: Float) = drawCircle(
            Brush.radialGradient(listOf(c, Color.Transparent), Offset(size.width * cx, size.height * cy), r),
            radius = r, center = Offset(size.width * cx, size.height * cy),
        )
        val u = size.minDimension
        blob(Color(0xFF7C3AED), 0.15f, 0.08f, u * 0.9f)
        blob(Color(0xFF06B6D4), 0.95f, 0.30f, u * 0.8f)
        blob(Color(0xFFEC4899), 0.05f, 0.55f, u * 0.8f)
        blob(Color(0xFF3B82F6), 0.90f, 0.78f, u * 0.9f)
        blob(Color(0xFFF59E0B), 0.20f, 0.95f, u * 0.7f)
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("لقطات زجاجية", fontSize = 28.sp, color = MaterialTheme.colorScheme.onBackground)
        Text(
            "تظهر أزرار زجاجية (Liquid Glass) فوق معاينة لقطة الشاشة: تحديد النص والترجمة، مسح الباركود، الحذف، والمشاركة.",
            fontSize = 14.sp, color = Color(0xFFB0B0BC)
        )

        // ---- Service / permissions
        Section("التفعيل والصلاحيات") {
            SwitchRow(
                title = "تفعيل الخدمة",
                sub = if (ready) "تعمل في الخلفية وتراقب لقطات الشاشة" else "امنح الصلاحيات المطلوبة أولاً",
                checked = enabled,
                enabled = ready,
            ) { on ->
                enabled = on
                SettingsStore.setEnabled(ctx, on)
                if (on) ScreenshotService.start(ctx) else ScreenshotService.stop(ctx)
            }
            PermRow("العرض فوق التطبيقات (مطلوب)", hasOverlay) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            }
            PermRow("الوصول إلى الصور (مطلوب - اختر السماح بالكل)", hasMedia) { onRequestPerms() }
            PermRow("الإشعارات (لإبقاء الخدمة ظاهرة)", hasNotif) { onRequestPerms() }
            PermRow("استثناء من توفير البطارية (موصى به لإنفنكس)", noBattery) {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            GlassButton(
                "تجربة على آخر لقطة شاشة",
                {
                    if (enabled) ScreenshotService.test(ctx)
                    else Toast.makeText(ctx, "فعّل الخدمة أولاً", Toast.LENGTH_SHORT).show()
                },
                Modifier.fillMaxWidth(),
            )
        }

        // ---- Live preview
        Section("معاينة مباشرة") {
            Preview(s)
        }

        // ---- Look
        Section("شكل الأزرار") {
            SwitchRow("حواف دائرية", "إيقافه يعطي زوايا شبه حادة", s.rounded) { upd(s.copy(rounded = it)) }
            SliderRow("حجم الزر", "${s.sizeDp} dp", s.sizeDp.toFloat(), 40f..72f) {
                upd(s.copy(sizeDp = it.roundToInt()))
            }
            SliderRow("شدة الضبابية (Blur)", "%.1f".format(s.blurDp), s.blurDp, 0f..24f) { upd(s.copy(blurDp = it)) }
            SliderRow("شدة الانكسار (Refraction)", "%.1f".format(s.refractionDp), s.refractionDp, 0f..24f) {
                upd(s.copy(refractionDp = it))
            }
            SliderRow("كثافة اللون الأبيض", "${(s.tint * 100).roundToInt()}%", s.tint, 0f..0.5f) {
                upd(s.copy(tint = it))
            }
        }

        // ---- Position
        Section("المكان") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip(selected = s.sideRight, onClick = { upd(s.copy(sideRight = true)) }, label = { Text("يمين الشاشة") })
                GlassChip(selected = !s.sideRight, onClick = { upd(s.copy(sideRight = false)) }, label = { Text("يسار الشاشة") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip(selected = s.vertical, onClick = { upd(s.copy(vertical = true)) }, label = { Text("عمودي") })
                GlassChip(selected = !s.vertical, onClick = { upd(s.copy(vertical = false)) }, label = { Text("أفقي") })
            }
            SliderRow("الارتفاع على الشاشة", "${(s.position * 100).roundToInt()}%", s.position, 0f..1f) {
                upd(s.copy(position = it))
            }
        }

        // ---- Behaviour
        Section("السلوك") {
            SliderRow("اختفاء الأزرار بعد", "${s.timeoutSec} ث", s.timeoutSec.toFloat(), 3f..20f) {
                upd(s.copy(timeoutSec = it.roundToInt()))
            }
            SwitchRow("إخفاء زر الباركود إن لم يوجد باركود", "يفحص اللقطة تلقائياً قبل إظهار الأزرار", s.hideBarcodeIfNone) {
                upd(s.copy(hideBarcodeIfNone = it))
            }
            Text("لغة الترجمة (الهدف)", color = MaterialTheme.colorScheme.onSurface)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LANGS.forEach { (code, label) ->
                    GlassChip(selected = s.targetLang == code, onClick = { upd(s.copy(targetLang = code)) }, label = { Text(label) })
                }
            }
        }

        GlassButton("استرجاع الإعدادات الافتراضية", { upd(GlassSettings()) }, Modifier.fillMaxWidth(), accent = true)
    }
    }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().glassCard(RoundedCornerShape(28.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(title, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun SwitchRow(
    title: String,
    sub: String? = null,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface)
            if (sub != null) Text(sub, fontSize = 12.sp, color = Color(0xFF9A9AA6))
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun SliderRow(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(title, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
            Text(valueText, color = Color(0xFF9A9AA6))
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun PermRow(title: String, ok: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
        if (ok) Text("✓", color = Color(0xFF4ADE80), fontSize = 20.sp)
        else GlassButton("منح", onGrant, accent = true, height = 38.dp)
    }
}

/** Live preview of the real glass buttons over a colorful, detailed backdrop. */
@Composable
private fun Preview(s: GlassSettings) {
    val backdrop = rememberLayerBackdrop()
    val items = listOf(
        PanelItem(R.drawable.ic_text, "نص") {},
        PanelItem(R.drawable.ic_qr, "باركود") {},
        PanelItem(R.drawable.ic_delete, "حذف") {},
        PanelItem(R.drawable.ic_share, "مشاركة") {},
    )
    val (pw, ph) = panelSizeDp(s, items.size)

    // Fixed LTR here so "right/left" always mean the physical sides.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clip(RoundedCornerShape(24.dp))
        ) {
            Canvas(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
                drawRect(
                    Brush.linearGradient(
                        listOf(Color(0xFF7C3AED), Color(0xFF06B6D4), Color(0xFFF59E0B))
                    )
                )
                drawCircle(Color(0x55FFFFFF), radius = size.minDimension * 0.28f, center = Offset(size.width * 0.3f, size.height * 0.35f))
                drawCircle(Color(0x66000000), radius = size.minDimension * 0.18f, center = Offset(size.width * 0.75f, size.height * 0.7f))
                var y = 24f
                while (y < size.height) {
                    drawRoundRect(
                        Color(0xAAFFFFFF),
                        topLeft = Offset(24f, y),
                        size = Size(size.width * (0.35f + 0.4f * ((y.toInt() / 30) % 3) / 3f), 10f),
                        cornerRadius = CornerRadius(5f, 5f)
                    )
                    y += 30f
                }
            }

            val margin = 12.dp
            val density = androidx.compose.ui.platform.LocalDensity.current
            val maxH = constraints.maxHeight
            val panelHpx = with(density) { ph.dp.roundToPx() }
            val yOff = ((maxH - panelHpx) * s.position).roundToInt().coerceAtLeast(0)
            Box(
                Modifier
                    .align(if (s.sideRight) Alignment.TopEnd else Alignment.TopStart)
                    .padding(horizontal = margin)
                    .offset { IntOffset(0, yOff) }
            ) {
                GlassPanel(backdrop, s, items, light = false)
            }
        }
    }
}

@Composable
private fun GlassChip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = label,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color.White.copy(alpha = 0.06f),
            selectedContainerColor = Color(0xFF8AB4FF).copy(alpha = 0.35f),
            labelColor = Color.White,
            selectedLabelColor = Color.White,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = Color.White.copy(alpha = 0.2f),
            selectedBorderColor = Color.White.copy(alpha = 0.35f),
        ),
    )
}

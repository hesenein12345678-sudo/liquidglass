package com.glassplayer.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Player {
    var deviceSongs by mutableStateOf<List<Song>>(emptyList())
    var queue by mutableStateOf<List<Song>>(emptyList())
    var index by mutableIntStateOf(-1)
    var isPlaying by mutableStateOf(false)
    var isLoading by mutableStateOf(false)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)

    val current: Song? get() = queue.getOrNull(index)

    private var queueIsDevice = false
    private var mp: MediaPlayer? = null
    private var app: Context? = null
    private var focusReq: AudioFocusRequest? = null
    private var eq: Equalizer? = null
    private var lastVol = 1f

    fun init(ctx: Context) {
        if (app == null) app = ctx.applicationContext
    }

    fun setLibrary(list: List<Song>) {
        deviceSongs = list
        if (queueIsDevice) {
            val curId = current?.id
            queue = list
            index = if (curId == null) -1 else list.indexOfFirst { it.id == curId }
        }
    }

    fun playQueue(list: List<Song>, i: Int, device: Boolean) {
        queue = list
        queueIsDevice = device
        playIndex(i)
    }

    private fun playIndex(i: Int) {
        val ctx = app ?: return
        val s = queue.getOrNull(i) ?: return
        releasePlayer()
        index = i
        positionMs = 0L
        durationMs = 0L
        val online = s.uri.scheme?.startsWith("http") == true
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            p.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(ctx, s.uri)
            p.setOnCompletionListener { next() }
            p.setOnErrorListener { _, _, _ ->
                isPlaying = false
                isLoading = false
                true
            }
            mp = p
            if (online) {
                isLoading = true
                isPlaying = false
                p.setOnPreparedListener { m ->
                    if (mp === m) {
                        isLoading = false
                        begin(m, s)
                    }
                }
                p.prepareAsync()
            } else {
                p.prepare()
                begin(p, s)
            }
        } catch (e: Exception) {
            try { p.release() } catch (_: Exception) {}
            if (mp === p) mp = null
            isPlaying = false
            isLoading = false
        }
    }

    private fun begin(p: MediaPlayer, s: Song) {
        durationMs = p.duration.toLong()
        positionMs = 0L
        requestFocus()
        applyEffects(p)
        setVol(p, if (AppTheme.fadeEnabled) 0f else 1f)
        p.start()
        isPlaying = true
        notifyService(s, true)
    }

    private fun setVol(p: MediaPlayer, v: Float) {
        lastVol = v
        try { p.setVolume(v, v) } catch (_: IllegalStateException) {}
    }

    private fun applyEffects(p: MediaPlayer) {
        releaseEq()
        if (!AppTheme.fadeEnabled) return
        try {
            val e = Equalizer(0, p.audioSessionId)
            val min = e.bandLevelRange[0].toInt()
            for (b in 0 until e.numberOfBands.toInt()) {
                val f = e.getCenterFreq(b.toShort())
                val cut = when {
                    f > 12_000_000 -> -1200
                    f > 6_000_000 -> -600
                    else -> 0
                }
                if (cut != 0) e.setBandLevel(b.toShort(), maxOf(cut, min).toShort())
            }
            e.setEnabled(true)
            eq = e
        } catch (_: Throwable) {
        }
    }

    private fun releaseEq() {
        try { eq?.release() } catch (_: Throwable) {}
        eq = null
    }

    fun toggle() {
        val p = mp
        val s = current
        if (p == null || s == null) {
            if (queue.isNotEmpty()) playIndex(if (index >= 0) index else 0)
            return
        }
        if (isLoading) return
        try {
            if (p.isPlaying) {
                p.pause()
                isPlaying = false
                notifyService(s, false)
            } else {
                requestFocus()
                p.start()
                isPlaying = true
                notifyService(s, true)
            }
        } catch (_: IllegalStateException) {
        }
    }

    fun next() {
        if (queue.isEmpty()) return
        playIndex((index + 1) % queue.size)
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (positionMs > 3000L) {
            seekTo(0L)
        } else {
            playIndex((index - 1 + queue.size) % queue.size)
        }
    }

    fun seekTo(ms: Long) {
        try {
            mp?.seekTo(ms.toInt())
            positionMs = ms
        } catch (_: IllegalStateException) {
        }
    }

    fun tick() {
        val p = mp ?: return
        try {
            if (!p.isPlaying) return
            val pos = p.currentPosition
            positionMs = pos.toLong()
            if (AppTheme.fadeEnabled) {
                val fin = (pos / 1500f).coerceIn(0f, 1f)
                val fout = if (durationMs > 0) ((durationMs - pos) / 2000f).coerceIn(0f, 1f) else 1f
                val v = minOf(fin, fout)
                setVol(p, v * v)
            } else if (lastVol != 1f) {
                setVol(p, 1f)
            }
        } catch (_: IllegalStateException) {
        }
    }

    private fun pauseNow() {
        try {
            mp?.let { if (it.isPlaying) it.pause() }
        } catch (_: IllegalStateException) {
        }
        isPlaying = false
        current?.let { notifyService(it, false) }
    }

    private fun releasePlayer() {
        releaseEq()
        try {
            mp?.release()
        } catch (_: Exception) {
        }
        mp = null
        isLoading = false
    }

    private fun requestFocus() {
        val ctx = app ?: return
        val am = ctx.getSystemService(AudioManager::class.java) ?: return
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS ||
                    change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
                ) pauseNow()
            }
            .build()
            .also { focusReq = it }
        am.requestAudioFocus(req)
    }

    private fun notifyService(s: Song, playing: Boolean) {
        val ctx = app ?: return
        try {
            val i = Intent(ctx, MusicService::class.java)
            if (playing) {
                i.putExtra("title", s.title).putExtra("artist", s.artist)
                ctx.startForegroundService(i)
            } else {
                ctx.stopService(i)
            }
        } catch (_: Exception) {
        }
    }
}

/** Keeps playback alive in the background (foreground notification). */
class MusicService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra("title") ?: "Playing"
        val artist = intent?.getStringExtra("artist") ?: ""
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("music", "Music playback", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "music")
            .setContentTitle(title)
            .setContentText(artist)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
        return START_NOT_STICKY
    }
}

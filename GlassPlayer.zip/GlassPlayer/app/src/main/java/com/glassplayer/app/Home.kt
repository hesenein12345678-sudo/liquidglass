package com.glassplayer.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.vibrancy

@Composable
fun EqBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(
        0.25f, 1f,
        infiniteRepeatable(tween(380, easing = LinearEasing), RepeatMode.Reverse), label = "a"
    )
    val b by t.animateFloat(
        0.2f, 1f,
        infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "b"
    )
    val c by t.animateFloat(
        0.3f, 1f,
        infiniteRepeatable(tween(450, easing = LinearEasing), RepeatMode.Reverse), label = "c"
    )
    Canvas(modifier.size(22.dp)) {
        val hs = if (playing) listOf(a, b, c) else listOf(0.4f, 0.4f, 0.4f)
        val bw = size.width / 5f
        hs.forEachIndexed { i, h ->
            val bh = size.height * h
            drawRoundRect(
                color,
                topLeft = Offset(i * bw * 2f, size.height - bh),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f)
            )
        }
    }
}

@Composable
fun SongRow(song: Song, isCurrent: Boolean, bg: Backdrop, onClick: () -> Unit) {
    val isDark = LocalIsDark.current
    val accent = LocalAccent.current
    val fg = LocalFg.current
    val art = rememberArt(song, 160)

    Row(
        Modifier
            .fillMaxWidth()
            .height(70.dp)
            .bounceClick(onClick)
            .glassBox(bg, RoundedCornerShape(24.dp), glassSurface(isDark, if (isCurrent) 0.55f else 0.32f), 10f)
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(accent.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) {
            if (art != null) {
                Image(
                    bitmap = art,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Ic.Note, fg.copy(alpha = 0.8f), 24.dp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt(song.title, 16f, bold = true, color = if (isCurrent) accent else null)
            Txt(song.artist, 13f, alpha = 0.65f)
        }
        Spacer(Modifier.width(10.dp))
        if (isCurrent) EqBars(accent, Player.isPlaying)
        else Txt(fmtTime(song.durationMs), 12f, alpha = 0.5f)
    }
}

@Composable
fun HomeScreen(bg: Backdrop, granted: Boolean, onRequest: () -> Unit) {
    val accent = LocalAccent.current
    FullPage(
        header = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Txt("Home", 34f, bold = true)
                    if (granted) Txt("${Player.deviceSongs.size} songs", 13f, alpha = 0.6f)
                }
                if (granted && Player.deviceSongs.isNotEmpty()) {
                    GlassPill(
                        backdrop = bg,
                        tint = accent,
                        onClick = { Player.playQueue(Player.deviceSongs, 0, true) },
                        modifier = Modifier.height(42.dp)
                    ) {
                        Box(Modifier.padding(horizontal = 18.dp)) { Txt("Play all", 14f, bold = true, color = Color.White) }
                    }
                }
            }
        }
    ) { top ->
        when {
            !granted -> Box(Modifier.padding(top = top, start = 18.dp, end = 18.dp)) {
                MessageCard(bg, "Allow access to the music on your device", "Allow", onRequest)
            }
            Player.deviceSongs.isEmpty() -> Box(Modifier.padding(top = top, start = 18.dp, end = 18.dp)) {
                MessageCard(bg, "No songs found on this device", null, {})
            }
            else -> LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = top, bottom = 250.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(Player.deviceSongs, key = { _, s -> s.id }) { i, s ->
                    SongRow(s, s.id == Player.current?.id, bg) { Player.playQueue(Player.deviceSongs, i, true) }
                }
            }
        }
    }
}

@Composable
fun MessageCard(bg: Backdrop, text: String, button: String?, onClick: () -> Unit) {
    val isDark = LocalIsDark.current
    val accent = LocalAccent.current
    Column(
        Modifier
            .fillMaxWidth()
            .glassBox(bg, RoundedCornerShape(28.dp), glassSurface(isDark, 0.35f), 10f)
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Txt(text, 16f, maxLines = 3)
        if (button != null) {
            GlassPill(bg, tint = accent, onClick = onClick, modifier = Modifier.height(44.dp)) {
                Box(Modifier.padding(horizontal = 24.dp)) { Txt(button, 15f, bold = true, color = Color.White) }
            }
        }
    }
}

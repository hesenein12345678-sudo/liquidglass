package com.glassplayer.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private fun vec(name: String, build: PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .path(fill = SolidColor(Color.Black), pathBuilder = build)
        .build()

private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
    moveTo(cx - r, cy)
    arcTo(r, r, 0f, true, true, cx + r, cy)
    arcTo(r, r, 0f, true, true, cx - r, cy)
    close()
}

object Ic {
    val Play: ImageVector = vec("play") {
        moveTo(8f, 5f); lineTo(19f, 12f); lineTo(8f, 19f); close()
    }
    val Pause: ImageVector = vec("pause") {
        moveTo(6f, 5f); horizontalLineTo(10f); verticalLineTo(19f); horizontalLineTo(6f); close()
        moveTo(14f, 5f); horizontalLineTo(18f); verticalLineTo(19f); horizontalLineTo(14f); close()
    }
    val Next: ImageVector = vec("next") {
        moveTo(5f, 5f); lineTo(15f, 12f); lineTo(5f, 19f); close()
        moveTo(17f, 5f); horizontalLineTo(20f); verticalLineTo(19f); horizontalLineTo(17f); close()
    }
    val Prev: ImageVector = vec("prev") {
        moveTo(19f, 5f); lineTo(9f, 12f); lineTo(19f, 19f); close()
        moveTo(4f, 5f); horizontalLineTo(7f); verticalLineTo(19f); horizontalLineTo(4f); close()
    }
    val Note: ImageVector = vec("note") {
        circle(9.5f, 18f, 3.5f)
        moveTo(12.5f, 4f); horizontalLineTo(15f); verticalLineTo(18f); horizontalLineTo(12.5f); close()
        moveTo(15f, 4f)
        curveTo(17f, 6f, 19f, 7f, 19f, 10f)
        curveTo(17.5f, 8.5f, 16f, 8.5f, 15f, 8.5f)
        close()
    }
    val Down: ImageVector = vec("down") {
        moveTo(6.5f, 9f); lineTo(12f, 14.5f); lineTo(17.5f, 9f); lineTo(19f, 10.5f)
        lineTo(12f, 17.5f); lineTo(5f, 10.5f); close()
    }
    val Lyrics: ImageVector = vec("lyrics") {
        moveTo(4f, 6f); horizontalLineTo(20f); verticalLineTo(8f); horizontalLineTo(4f); close()
        moveTo(4f, 11f); horizontalLineTo(20f); verticalLineTo(13f); horizontalLineTo(4f); close()
        moveTo(4f, 16f); horizontalLineTo(13f); verticalLineTo(18f); horizontalLineTo(4f); close()
    }
    val Download: ImageVector = vec("download") {
        moveTo(11f, 4f); horizontalLineTo(13f); verticalLineTo(12f); horizontalLineTo(16.5f)
        lineTo(12f, 17f); lineTo(7.5f, 12f); horizontalLineTo(11f); close()
        moveTo(5f, 19f); horizontalLineTo(19f); verticalLineTo(21f); horizontalLineTo(5f); close()
    }
    val Check: ImageVector = vec("check") {
        moveTo(9f, 16.2f); lineTo(4.8f, 12f); lineTo(3.4f, 13.4f); lineTo(9f, 19f)
        lineTo(20.6f, 7.4f); lineTo(19.2f, 6f); close()
    }
    val Back: ImageVector = vec("back") {
        moveTo(15.5f, 4.5f); lineTo(8f, 12f); lineTo(15.5f, 19.5f); lineTo(17.5f, 17.5f)
        lineTo(12f, 12f); lineTo(17.5f, 6.5f); close()
    }
}

@Composable
fun Icon(v: ImageVector, tint: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Image(
        imageVector = v,
        contentDescription = null,
        colorFilter = ColorFilter.tint(tint),
        modifier = modifier.size(size)
    )
}

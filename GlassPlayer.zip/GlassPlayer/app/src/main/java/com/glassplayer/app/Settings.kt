package com.glassplayer.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.kyant.backdrop.Backdrop

private val iconAliases = listOf("IconBlue", "IconPurple", "IconSunset", "IconMint", "IconNight")
private val iconColors = listOf(
    Color(0xFF0A84FF), Color(0xFF7C4DFF), Color(0xFFFF6D00), Color(0xFF00BFA5), Color(0xFF101828)
)

private fun setLauncherIcon(ctx: Context, index: Int) {
    val pm = ctx.packageManager
    // enable the new one first so the app never has zero launcher entries
    iconAliases.forEachIndexed { i, n ->
        if (i == index) pm.setComponentEnabledSetting(
            ComponentName(ctx.packageName, "com.glassplayer.app.$n"),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
        )
    }
    iconAliases.forEachIndexed { i, n ->
        if (i != index) pm.setComponentEnabledSetting(
            ComponentName(ctx.packageName, "com.glassplayer.app.$n"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
        )
    }
}

/** Hides the original launcher icon (all aliases off) so only the pinned picture shortcut stays on the home screen. */
private fun hideOriginalIcon(ctx: Context) {
    val pm = ctx.packageManager
    iconAliases.forEach { n ->
        pm.setComponentEnabledSetting(
            ComponentName(ctx.packageName, "com.glassplayer.app.$n"),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
        )
    }
}

private fun confirmHideOriginalIcon(ctx: Context) {
    try {
        android.app.AlertDialog.Builder(ctx)
            .setTitle("Hide the original icon?")
            .setMessage(
                "Do this only AFTER your picture icon appears on the home screen. " +
                    "The app will then show only with your picture. " +
                    "If you remove that shortcut you can still open the app from Settings > Apps, " +
                    "and you can bring the original icon back from here."
            )
            .setPositiveButton("Hide") { _, _ -> hideOriginalIcon(ctx) }
            .setNegativeButton("Cancel", null)
            .show()
    } catch (_: Exception) {
    }
}

private fun pinGalleryShortcut(ctx: Context, uri: Uri) {
    try {
        val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (src == null) {
            Toast.makeText(ctx, "Could not read the image", Toast.LENGTH_SHORT).show()
            return
        }
        val bmp = ThumbnailUtils.extractThumbnail(src, 192, 192)
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
            Toast.makeText(ctx, "Your launcher does not support this", Toast.LENGTH_LONG).show()
            return
        }
        val info = ShortcutInfoCompat.Builder(ctx, "custom_" + System.currentTimeMillis())
            .setShortLabel("Glass Player")
            .setIcon(IconCompat.createWithBitmap(bmp))
            .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
            .build()
        ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not create the shortcut", Toast.LENGTH_SHORT).show()
    }
}

private fun openLink(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun SettingsRow(bg: Backdrop, title: String, subtitle: String, onClick: () -> Unit) {
    val isDark = LocalIsDark.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(74.dp)
            .bounceClick(onClick)
            .glassBox(bg, RoundedCornerShape(26.dp), glassSurface(isDark, 0.32f), 10f)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Txt(title, 18f, bold = true)
            Txt(subtitle, 13f, alpha = 0.6f)
        }
    }
}

@Composable
private fun PageHeader(bg: Backdrop, title: String, onBack: () -> Unit) {
    val fg = LocalFg.current
    Row(
        Modifier.padding(top = 14.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassButton(bg, onBack, size = 46.dp) { Icon(Ic.Back, fg, 24.dp) }
        Spacer(Modifier.width(14.dp))
        Txt(title, 28f, bold = true)
    }
}

@Composable
private fun SwitchRow(bg: Backdrop, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Txt(title, 16f, bold = true, maxLines = 2)
            Txt(subtitle, 12f, alpha = 0.6f, maxLines = 3)
        }
        Spacer(Modifier.width(12.dp))
        LiquidSwitch(bg, checked, onChange)
    }
}

@Composable
fun SettingsScreen(bg: Backdrop) {
    var page by remember { mutableIntStateOf(0) }
    BackHandler(enabled = page != 0) { page = 0 }

    Crossfade(targetState = page, animationSpec = tween(220), label = "settings") { p ->
        when (p) {
            0 -> FullPage(
                header = { Box(Modifier.padding(top = 18.dp, bottom = 14.dp)) { Txt("Settings", 34f, bold = true) } }
            ) { top, header ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(start = 18.dp, end = 18.dp, top = top, bottom = 250.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    header()
                    SettingsRow(bg, "Theme", "Colors, dark / light, app icon") { page = 1 }
                    SettingsRow(bg, "About", "What this app does") { page = 2 }
                    SettingsRow(bg, "More", "Bottom bar, effects, lyrics, audio") { page = 3 }
                }
            }
            1 -> FullPage(header = { PageHeader(bg, "Theme") { page = 0 } }) { top, header -> ThemePage(bg, top, header) }
            2 -> FullPage(header = { PageHeader(bg, "About") { page = 0 } }) { top, header -> AboutPage(bg, top, header) }
            else -> FullPage(header = { PageHeader(bg, "More") { page = 0 } }) { top, header -> MorePage(bg, top, header) }
        }
    }
}

@Composable
private fun ThemePage(bg: Backdrop, top: androidx.compose.ui.unit.Dp, header: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val fg = LocalFg.current
    val accent = LocalAccent.current
    val isDark = LocalIsDark.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) pinGalleryShortcut(ctx, uri)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, top = top, bottom = 250.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        header()
        GlassCard(bg) {
            Txt("Button color", 17f, bold = true)
            Spacer(Modifier.height(12.dp))
            AppTheme.palette.chunked(6).forEachIndexed { r, rowColors ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    rowColors.forEachIndexed { c, color ->
                        val idx = r * 6 + c
                        val selected = AppTheme.accentIndex == idx && !AppTheme.adaptive
                        Box(
                            Modifier
                                .size(42.dp)
                                .bounceClick { AppTheme.setAccent(ctx, idx) }
                                .clip(CircleShape)
                                .background(color)
                                .then(if (selected) Modifier.border(3.dp, fg, CircleShape) else Modifier)
                        )
                    }
                }
            }
        }

        GlassCard(bg) {
            SwitchRow(
                bg, "Adapt app colors",
                "The app takes its colors from the cover of the song that is playing.",
                AppTheme.adaptive
            ) { AppTheme.setAdaptive(ctx, it) }
        }

        GlassCard(bg) {
            Txt("Appearance", 17f, bold = true)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassPill(
                    bg,
                    modifier = Modifier.height(46.dp).weight(1f),
                    tint = if (isDark) accent else null,
                    onClick = { AppTheme.setDarkMode(ctx, 1) }
                ) { Txt("Dark", 15f, bold = true, color = if (isDark) Color.White else null) }
                GlassPill(
                    bg,
                    modifier = Modifier.height(46.dp).weight(1f),
                    tint = if (!isDark) accent else null,
                    onClick = { AppTheme.setDarkMode(ctx, 2) }
                ) { Txt("Light", 15f, bold = true, color = if (!isDark) Color.White else null) }
            }
        }

        GlassCard(bg) {
            Txt("App icon", 17f, bold = true)
            Spacer(Modifier.height(4.dp))
            Txt("Pick one. Your launcher may take a few seconds to refresh.", 12f, alpha = 0.6f, maxLines = 3)
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                iconColors.forEachIndexed { i, color ->
                    Box(
                        Modifier
                            .size(52.dp)
                            .bounceClick {
                                AppTheme.setIcon(ctx, i)
                                setLauncherIcon(ctx, i)
                            }
                            .clip(RoundedCornerShape(15.dp))
                            .background(color)
                            .then(
                                if (AppTheme.iconIndex == i) Modifier.border(3.dp, fg, RoundedCornerShape(15.dp))
                                else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) { Icon(Ic.Note, Color.White, 26.dp) }
                }
            }
            Spacer(Modifier.height(14.dp))
            PillButton(bg, "Use a picture from gallery", { picker.launch("image/*") }, tint = accent)
            Spacer(Modifier.height(4.dp))
            Txt(
                "Android does not allow replacing the real icon with any picture, so this adds a home-screen icon with your picture. " +
                    "After it appears, tap \"Hide original icon\" so only your picture icon remains.",
                12f, alpha = 0.6f, maxLines = 6
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(bg, "Hide original icon", { confirmHideOriginalIcon(ctx) })
                PillButton(bg, "Restore original", {
                    setLauncherIcon(ctx, AppTheme.iconIndex)
                    Toast.makeText(ctx, "Original icon restored", Toast.LENGTH_SHORT).show()
                })
            }
        }
    }
}

@Composable
private fun AboutPage(bg: Backdrop, top: androidx.compose.ui.unit.Dp, header: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, top = top, bottom = 250.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        header()
        GlassCard(bg) {
            Txt("Glass Player", 24f, bold = true)
            Spacer(Modifier.height(10.dp))
            Txt(
                "مشغل موسيقى بتصميم Liquid Glass يشغّل الأغاني الموجودة على جهازك، ويحتوي مكتبة على الإنترنت للبحث عن الأغاني والقصائد الحسينية وتنزيلها.",
                15f, alpha = 0.9f, maxLines = 10, modifier = Modifier.fillMaxWidth()
            )
        }
        GlassCard(bg) {
            Txt("Features", 18f, bold = true)
            Spacer(Modifier.height(8.dp))
            listOf(
                "تشغيل أغاني الجهاز بواجهة زجاجية وأنيميشن سلس",
                "مشغل صغير ومشغل كبير يفتح بحركة ناعمة",
                "مكتبة أونلاين مع بحث وتنزيل، والأغنية المنزّلة تضاف لأغاني الجهاز",
                "أكثر من 20 لون للأزرار مع تكيّف الألوان على غلاف الأغنية",
                "ثيم داكن وفاتح وعدة أيقونات للتطبيق",
                "كلمات الأغاني مع إمكانية التعديل",
                "تحكم كامل بالشريط السفلي، وإطفاء الزجاج للأجهزة الضعيفة"
            ).forEach { line ->
                Txt("•  $line", 14f, alpha = 0.85f, maxLines = 4, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp))
            }
        }
        GlassCard(bg) {
            Txt("Contact", 18f, bold = true)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassPill(
                    bg,
                    modifier = Modifier.height(48.dp).weight(1f),
                    tint = accent,
                    onClick = { openLink(ctx, "https://t.me/xezn9") }
                ) { Txt("Telegram", 15f, bold = true, color = Color.White) }
                GlassPill(
                    bg,
                    modifier = Modifier.height(48.dp).weight(1f),
                    tint = accent,
                    onClick = { openLink(ctx, "https://www.tiktok.com/@xezn99") }
                ) { Txt("TikTok", 15f, bold = true, color = Color.White) }
            }
        }
    }
}

@Composable
private fun MorePage(bg: Backdrop, top: androidx.compose.ui.unit.Dp, header: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val fg = LocalFg.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 18.dp, end = 18.dp, top = top, bottom = 250.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        header()
        GlassCard(bg) {
            Txt("Bottom bar", 18f, bold = true)
            Spacer(Modifier.height(10.dp))
            Txt("Blur", 14f, alpha = 0.8f)
            GlassSeekBar(bg, AppTheme.barBlur / 30f, {}, onSeek = { AppTheme.setBarBlur(ctx, it * 30f) })
            Txt("Refraction", 14f, alpha = 0.8f)
            GlassSeekBar(bg, AppTheme.barRefraction / 30f, {}, onSeek = { AppTheme.setBarRefraction(ctx, it * 30f) })
            Txt("Opacity", 14f, alpha = 0.8f)
            GlassSeekBar(bg, AppTheme.barAlpha / 0.9f, {}, onSeek = { AppTheme.setBarAlpha(ctx, it * 0.9f) })
            Spacer(Modifier.height(8.dp))
            Txt("Color", 14f, alpha = 0.8f)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier
                        .size(38.dp)
                        .bounceClick { AppTheme.setBarColor(ctx, -1) }
                        .clip(CircleShape)
                        .background(fg.copy(alpha = 0.25f))
                        .then(if (AppTheme.barColorIndex == -1) Modifier.border(3.dp, fg, CircleShape) else Modifier),
                    contentAlignment = Alignment.Center
                ) { Txt("A", 14f, bold = true) }
                AppTheme.palette.forEachIndexed { i, color ->
                    Box(
                        Modifier
                            .size(38.dp)
                            .bounceClick { AppTheme.setBarColor(ctx, i) }
                            .clip(CircleShape)
                            .background(color)
                            .then(if (AppTheme.barColorIndex == i) Modifier.border(3.dp, fg, CircleShape) else Modifier)
                    )
                }
            }
        }

        GlassCard(bg) {
            SwitchRow(
                bg, "Liquid glass effects",
                "Turn off on weak devices to make the app lighter.",
                AppTheme.glassEnabled
            ) { AppTheme.setGlass(ctx, it) }
            SwitchRow(
                bg, "Smooth fade and hiss reduction",
                "Fades songs in and out, and softens high frequencies to reduce hiss (basic filter, applies from the next song).",
                AppTheme.fadeEnabled
            ) { AppTheme.setFade(ctx, it) }
            SwitchRow(
                bg, "Lyrics",
                "Adds a lyrics button to the big player. Lyrics are searched online and you can edit them.",
                AppTheme.lyricsEnabled
            ) { AppTheme.setLyrics(ctx, it) }
        }
    }
}

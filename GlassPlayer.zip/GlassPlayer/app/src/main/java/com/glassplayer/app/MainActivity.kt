package com.glassplayer.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Player.init(this)
        AppTheme.load(this)
        enableEdgeToEdge()
        setContent { AppRoot() }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Home", Icons.Filled.Home),
    TabItem("Library", Icons.Filled.Search),
    TabItem("Settings", Icons.Filled.Settings),
)

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val isDark = when (AppTheme.darkMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val fg = if (isDark) Color.White else Color.Black
    val accent = AppTheme.accent

    val bgBackdrop = rememberLayerBackdrop()
    val contentBackdrop = rememberLayerBackdrop()
    var tab by remember { mutableIntStateOf(0) }
    val expand = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val showBig by remember { derivedStateOf { expand.value > 0.001f } }

    // system bar icon colors follow the chosen theme
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !isDark
            c.isAppearanceLightNavigationBars = !isDark
        }
    }

    // permissions + songs
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[audioPerm] == true ||
            ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED
    }
    val requestPerms: () -> Unit = {
        val list = ArrayList<String>()
        list.add(audioPerm)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        launcher.launch(list.toTypedArray())
    }
    LaunchedEffect(Unit) { if (!granted) requestPerms() }
    LaunchedEffect(granted) {
        if (granted) {
            val list = withContext(Dispatchers.IO) { MusicRepository.load(ctx) }
            Player.setLibrary(list)
        }
    }

    // playback position ticker
    LaunchedEffect(Player.isPlaying, Player.index) {
        while (Player.isPlaying) {
            Player.tick()
            delay(250)
        }
    }

    BackHandler(enabled = showBig) {
        scope.launch { expand.animateTo(0f, spring(0.9f, 300f)) }
    }

    CompositionLocalProvider(
        LocalFg provides fg,
        LocalIsDark provides isDark,
        LocalAccent provides accent,
        LocalLayoutDirection provides LayoutDirection.Ltr
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val hPx = constraints.maxHeight.toFloat()

            Box(
                Modifier
                    .fillMaxSize()
                    .layerBackdrop(contentBackdrop)
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .layerBackdrop(bgBackdrop)
                ) { AppBackground(isDark) }

                Crossfade(targetState = tab, animationSpec = tween(260), label = "tab") { t ->
                    when (t) {
                        0 -> HomeScreen(bgBackdrop, granted, requestPerms)
                        1 -> LibraryScreen(bgBackdrop)
                        else -> SettingsScreen(bgBackdrop)
                    }
                }
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AnimatedVisibility(
                    visible = Player.current != null,
                    enter = slideInVertically { it / 2 } + fadeIn(),
                    exit = slideOutVertically { it / 2 } + fadeOut()
                ) {
                    MiniPlayer(
                        backdrop = contentBackdrop,
                        onOpen = {
                            scope.launch { expand.animateTo(1f, spring(0.78f, 170f)) }
                        },
                        modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 12.dp)
                    )
                }

                LiquidBottomTabs(
                    selectedTabIndex = { tab },
                    onTabSelected = { tab = it },
                    backdrop = contentBackdrop,
                    tabsCount = tabs.size,
                    isDark = isDark,
                    accent = accent,
                    modifier = Modifier.padding(start = 36.dp, end = 36.dp, bottom = 24.dp)
                ) {
                    tabs.forEachIndexed { index, item ->
                        LiquidBottomTab(onClick = { tab = index }) {
                            Image(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                colorFilter = ColorFilter.tint(fg),
                                modifier = Modifier.size(26.dp)
                            )
                            BasicText(
                                item.label,
                                style = TextStyle(color = fg, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            )
                        }
                    }
                }
            }

            if (showBig) {
                BigPlayer(
                    progress = { expand.value },
                    onDrag = { d ->
                        scope.launch { expand.snapTo((expand.value - d / hPx).coerceIn(0f, 1f)) }
                    },
                    onDragEnd = { v ->
                        scope.launch {
                            val target = if (v > 1200f || (expand.value < 0.65f && v > -1200f)) 0f else 1f
                            expand.animateTo(target, spring(0.85f, 300f))
                        }
                    },
                    onClose = {
                        scope.launch { expand.animateTo(0f, spring(0.9f, 300f)) }
                    }
                )
            }
        }
    }
}

package com.glassplayer.app

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

data class CatalogArtist(
    val id: Long,
    val key: String,
    val name: String,
    val pictureUrl: String?,
    val songs: List<Song>
)

/**
 * Famous songs grouped by singer, with the ORIGINAL album covers.
 * Data comes from Deezer's free public API (no key). Deezer only gives a 30-second
 * preview for each song, so these songs play as previews.
 * The catalog is cached on the device and refreshed automatically when you leave the app.
 */
object Catalog {
    const val TRENDING = "Trending now"

    // Order here = order of the sections on screen.
    private val artistNames = listOf(
        // Arabic
        "Kadim Al Sahir", "Majida El Roumi", "Fairuz", "Umm Kulthum", "Amr Diab",
        "Nancy Ajram", "Fadel Shaker", "Hussain Al Jassmi", "Assala", "Ahlam",
        "Wael Kfoury", "Ragheb Alama", "Tamer Hosny", "Elissa", "Mohammed Abdu",
        "Abdulmajeed Abdullah", "Rashed Al Majed", "Saad Lamjarred", "Hatim Al Iraqi",
        "Mohamed Hamaki", "Sherine", "Najwa Karam", "Haifa Wehbe", "Nawal El Zoghbi",
        // International
        "Taylor Swift", "Ed Sheeran", "The Weeknd", "Eminem", "Billie Eilish",
        "Michael Jackson", "Adele", "Drake", "Coldplay", "Imagine Dragons",
        "Bruno Mars", "Dua Lipa", "Rihanna", "Ariana Grande", "Justin Bieber",
        "Queen", "Post Malone", "Shakira", "Maroon 5", "Alec Benjamin",
        "Linkin Park", "Selena Gomez", "Sia", "Charlie Puth"
    )

    var sections by mutableStateOf<List<CatalogArtist>>(emptyList())
        private set
    var refreshing by mutableStateOf(false)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private const val MIN_GAP_MS = 10 * 60 * 1000L

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "catalog_v1.json")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("catalog", Context.MODE_PRIVATE)

    // ---------- cache ----------

    fun loadCache(ctx: Context) {
        if (sections.isNotEmpty()) return
        try {
            val f = cacheFile(ctx)
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            val out = ArrayList<CatalogArtist>()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                val songsJson = a.getJSONArray("songs")
                val songs = ArrayList<Song>()
                for (j in 0 until songsJson.length()) {
                    val s = songsJson.getJSONObject(j)
                    songs.add(
                        Song(
                            id = s.getLong("id"),
                            title = s.getString("title"),
                            artist = s.getString("artist"),
                            album = s.optString("album"),
                            durationMs = s.optLong("dur", 30_000L),
                            uri = Uri.parse(s.getString("url")),
                            artUrl = s.optString("art").ifBlank { null }
                        )
                    )
                }
                out.add(CatalogArtist(a.getLong("id"), a.optString("key", a.getString("name")), a.getString("name"), a.optString("pic").ifBlank { null }, songs))
            }
            sections = out
        } catch (_: Exception) {
        }
    }

    private fun saveCache(ctx: Context, list: List<CatalogArtist>) {
        try {
            val arr = JSONArray()
            list.forEach { a ->
                val songs = JSONArray()
                a.songs.forEach { s ->
                    songs.put(
                        JSONObject()
                            .put("id", s.id).put("title", s.title).put("artist", s.artist)
                            .put("album", s.album).put("dur", s.durationMs)
                            .put("url", s.uri.toString()).put("art", s.artUrl ?: "")
                    )
                }
                arr.put(
                    JSONObject().put("id", a.id).put("key", a.key).put("name", a.name)
                        .put("pic", a.pictureUrl ?: "").put("songs", songs)
                )
            }
            cacheFile(ctx).writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    // ---------- network ----------

    private fun api(path: String): JSONObject {
        val j = JSONObject(httpGet("https://api.deezer.com/$path"))
        if (j.has("error")) throw java.io.IOException("deezer error")
        return j
    }

    private fun parseTrack(t: JSONObject): Song? {
        val preview = t.optString("preview")
        if (preview.isBlank()) return null
        val album = t.optJSONObject("album")
        val cover = album?.optString("cover_big")?.ifBlank { null }
            ?: album?.optString("cover_medium")?.ifBlank { null }
        return Song(
            id = -(10_000_000_000L + t.getLong("id")),
            title = t.optString("title_short").ifBlank { t.optString("title") },
            artist = t.optJSONObject("artist")?.optString("name") ?: "",
            album = album?.optString("title") ?: "",
            durationMs = 30_000L, // Deezer gives a 30 second preview
            uri = Uri.parse(preview),
            artUrl = cover
        )
    }

    private fun parseTracks(arr: JSONArray?): List<Song> {
        if (arr == null) return emptyList()
        val out = ArrayList<Song>()
        for (i in 0 until arr.length()) parseTrack(arr.getJSONObject(i))?.let { out.add(it) }
        return out.distinctBy { it.id }
    }

    private fun fetchArtist(name: String): CatalogArtist? {
        val found = api("search/artist?limit=1&q=" + URLEncoder.encode(name, "UTF-8"))
            .optJSONArray("data")?.optJSONObject(0) ?: return null
        val id = found.getLong("id")
        val pic = found.optString("picture_big").ifBlank { found.optString("picture_medium") }.ifBlank { null }
        val songs = parseTracks(api("artist/$id/top?limit=15").optJSONArray("data"))
        if (songs.isEmpty()) return null
        return CatalogArtist(id, name, found.optString("name").ifBlank { name }, pic, songs)
    }

    private fun fetchTrending(): CatalogArtist? {
        val songs = parseTracks(api("chart/0/tracks?limit=30").optJSONArray("data"))
        if (songs.isEmpty()) return null
        return CatalogArtist(-1L, TRENDING, TRENDING, null, songs)
    }

    /** Searches single songs (used by the search bar in Library). */
    suspend fun searchTracks(q: String): List<Song> = withContext(Dispatchers.IO) {
        parseTracks(api("search?limit=30&q=" + URLEncoder.encode(q, "UTF-8")).optJSONArray("data"))
    }

    // ---------- refresh ----------

    /** Called at start (only if nothing is cached) and every time the app goes to the background. */
    fun refresh(ctx: Context, force: Boolean = false) {
        val app = ctx.applicationContext
        if (refreshing) return
        val last = prefs(app).getLong("last", 0L)
        if (!force && sections.isNotEmpty() && System.currentTimeMillis() - last < MIN_GAP_MS) return
        refreshing = true
        scope.launch {
            try {
                val old = sections.associateBy { it.key }
                val fresh = HashMap<String, CatalogArtist>()
                try { fetchTrending()?.let { fresh[it.key] = it } } catch (_: Exception) {}
                // small batches so we stay under Deezer's rate limit
                artistNames.chunked(5).forEach { batch ->
                    batch.map { n ->
                        async { try { fetchArtist(n) } catch (_: Exception) { null } }
                    }.awaitAll().forEach { a -> if (a != null) fresh[a.key] = a }
                    publish(app, old, fresh, save = false)
                    delay(1500)
                }
                publish(app, old, fresh, save = true)
                if (fresh.isNotEmpty()) prefs(app).edit().putLong("last", System.currentTimeMillis()).apply()
            } catch (_: Exception) {
            } finally {
                withContext(Dispatchers.Main) { refreshing = false }
            }
        }
    }

    private suspend fun publish(
        app: Context,
        old: Map<String, CatalogArtist>,
        fresh: Map<String, CatalogArtist>,
        save: Boolean
    ) {
        // a singer that failed this time keeps his old data
        val list = (listOf(TRENDING) + artistNames).mapNotNull { k -> fresh[k] ?: old[k] }.distinctBy { it.id }
        if (list.isEmpty()) return
        if (save) saveCache(app, list)
        withContext(Dispatchers.Main) { sections = list }
    }
}

/** Singer photo + name + Play button, shown above his songs. */
@Composable
fun ArtistHeader(bg: Backdrop, artist: CatalogArtist) {
    val accent = LocalAccent.current
    val fg = LocalFg.current
    val photo = rememberArt(
        Song(-(20_000_000_000L + artist.id), artist.name, artist.name, "", 0L, Uri.EMPTY, artist.pictureUrl),
        160
    )
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) {
            if (photo != null) {
                Image(photo, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Icon(Ic.Note, fg.copy(alpha = 0.8f), 22.dp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) { Txt(artist.name, 20f, bold = true) }
        PillButton(bg, "Play", { Player.playQueue(artist.songs, 0, false) }, tint = accent)
    }
}

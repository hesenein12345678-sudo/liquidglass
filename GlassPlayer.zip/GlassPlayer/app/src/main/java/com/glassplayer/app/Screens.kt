package com.glassplayer.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.vibrancy

@Composable
fun LibraryScreen(bg: Backdrop) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Box(Modifier.padding(top = 18.dp, bottom = 14.dp)) { Txt("Library", 34f, bold = true) }
        MessageCard(bg, "The online library (search + download) arrives in the next update.", null, {})
    }
}

@Composable
private fun SettingsRow(bg: Backdrop, title: String, subtitle: String, onClick: () -> Unit) {
    val isDark = LocalIsDark.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(74.dp)
            .bounceClick(onClick)
            .drawBackdrop(
                backdrop = bg,
                shape = { RoundedCornerShape(26.dp) },
                effects = {
                    vibrancy()
                    blur(10f.dp.toPx())
                },
                onDrawSurface = { drawRect(glassSurface(isDark, 0.32f)) }
            )
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Txt(title, 18f, bold = true)
            Txt(subtitle, 13f, alpha = 0.6f)
        }
    }
}

@Composable
fun SettingsScreen(bg: Backdrop) {
    var page by remember { mutableIntStateOf(0) }
    BackHandler(enabled = page != 0) { page = 0 }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        if (page == 0) {
            Box(Modifier.padding(top = 18.dp, bottom = 14.dp)) { Txt("Settings", 34f, bold = true) }
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SettingsRow(bg, "Theme", "Button colors, dark / light") { page = 1 }
                SettingsRow(bg, "About", "Coming in the next update") {}
                SettingsRow(bg, "More", "Coming in the next update") {}
            }
        } else {
            ThemePage(bg) { page = 0 }
        }
    }
}

@Composable
private fun ThemePage(bg: Backdrop, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val fg = LocalFg.current
    val accent = LocalAccent.current
    val isDark = LocalIsDark.current

    Row(
        Modifier.padding(top = 14.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassButton(bg, onBack, size = 46.dp) { Icon(Ic.Back, fg, 24.dp) }
        Spacer(Modifier.width(14.dp))
        Txt("Theme", 28f, bold = true)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 250.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        GlassCard(bg) {
            Txt("Button color", 17f, bold = true)
            Spacer(Modifier.height(12.dp))
            AppTheme.palette.chunked(6).forEachIndexed { r, rowColors ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    rowColors.forEachIndexed { c, color ->
                        val idx = r * 6 + c
                        val selected = AppTheme.accentIndex == idx
                        Box(
                            Modifier
                                .size(42.dp)
                                .bounceClick { AppTheme.setAccent(ctx, idx) }
                                .clip(CircleShape)
                                .background(color)
                                .then(
                                    if (selected) Modifier.border(3.dp, fg, CircleShape) else Modifier
                                )
                        )
                    }
                }
            }
        }

        GlassCard(bg) {
            Txt("Appearance", 17f, bold = true)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassPill(
                    bg,
                    tint = if (isDark) accent else null,
                    onClick = { AppTheme.setDarkMode(ctx, 1) },
                    modifier = Modifier.height(46.dp).weight(1f)
                ) { Txt("Dark", 15f, bold = true, color = if (isDark) Color.White else null) }
                GlassPill(
                    bg,
                    tint = if (!isDark) accent else null,
                    onClick = { AppTheme.setDarkMode(ctx, 2) },
                    modifier = Modifier.height(46.dp).weight(1f)
                ) { Txt("Light", 15f, bold = true, color = if (!isDark) Color.White else null) }
            }
        }
    }
}

@Composable
private fun GlassCard(bg: Backdrop, content: @Composable () -> Unit) {
    val isDark = LocalIsDark.current
    Column(
        Modifier
            .fillMaxWidth()
            .drawBackdrop(
                backdrop = bg,
                shape = { RoundedCornerShape(28.dp) },
                effects = {
                    vibrancy()
                    blur(10f.dp.toPx())
                },
                onDrawSurface = { drawRect(glassSurface(isDark, 0.32f)) }
            )
            .padding(18.dp)
    ) { content() }
}

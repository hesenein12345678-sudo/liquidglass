package com.glassplayer.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.URLEncoder

object LyricsStore {
    private fun key(s: Song) = (s.title.trim() + "|" + s.artist.trim()).lowercase()
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lyrics", Context.MODE_PRIVATE)

    fun get(ctx: Context, s: Song): String? = prefs(ctx).getString(key(s), null)

    fun set(ctx: Context, s: Song, text: String) {
        prefs(ctx).edit().putString(key(s), text).apply()
    }

    /** Looks the song up on LRCLIB (free lyrics database). Returns null if nothing found. */
    suspend fun fetch(s: Song): String? = withContext(Dispatchers.IO) {
        try {
            val artist = if (s.artist == "Unknown artist") "" else " " + s.artist
            val q = URLEncoder.encode(s.title + artist, "UTF-8")
            val arr = JSONArray(httpGet("https://lrclib.net/api/search?q=$q"))
            var found: String? = null
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i).optString("plainLyrics", "")
                if (p.isNotBlank() && p != "null") {
                    found = p
                    break
                }
            }
            found
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun LyricsPanel(song: Song, backdrop: Backdrop, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val fg = LocalFg.current
    val isDark = LocalIsDark.current
    var text by remember(song.id) { mutableStateOf(LyricsStore.get(ctx, song) ?: "") }
    var editing by remember(song.id) { mutableStateOf(false) }
    var loading by remember(song.id) { mutableStateOf(false) }
    var notFound by remember(song.id) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val fetchLyrics: () -> Unit = {
        scope.launch {
            loading = true
            notFound = false
            val r = LyricsStore.fetch(song)
            if (r != null) {
                text = r
                LyricsStore.set(ctx, song, r)
            } else {
                notFound = true
            }
            loading = false
        }
    }
    LaunchedEffect(song.id) { if (text.isBlank()) fetchLyrics() }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .glassBox(backdrop, RoundedCornerShape(36.dp), glassSurface(isDark, 0.55f), 16f, 18f, 36f)
            .padding(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.weight(1f)) { Txt("Lyrics", 22f, bold = true) }
            if (editing) {
                PillButton(backdrop, "Save", {
                    LyricsStore.set(ctx, song, text)
                    editing = false
                }, tint = accent)
            } else {
                PillButton(backdrop, "Edit", { editing = true })
                PillButton(backdrop, "Auto", { fetchLyrics() })
            }
            PillButton(backdrop, "Close", onClose)
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(top = 14.dp)
        ) {
            when {
                editing -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        textStyle = TextStyle(color = fg, fontSize = 18.sp, lineHeight = 28.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                loading -> Txt("Searching for lyrics...", 16f, alpha = 0.7f)
                text.isBlank() -> Txt(
                    if (notFound) "No lyrics found. Tap Edit to write or paste them." else "No lyrics yet.",
                    16f, alpha = 0.7f, maxLines = 4
                )
                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Txt(text, 19f, maxLines = 100000, modifier = Modifier.fillMaxWidth())
                    Box(Modifier.size(24.dp))
                }
            }
        }
    }
}

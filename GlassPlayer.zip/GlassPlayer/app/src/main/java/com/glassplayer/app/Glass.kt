package com.glassplayer.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.shapes.Capsule
import kotlin.math.roundToInt

fun glassSurface(isDark: Boolean, a: Float = 0.4f): Color =
    if (isDark) Color(0xFF121212).copy(a) else Color(0xFFFAFAFA).copy(a)

@Composable
fun Txt(
    text: String,
    size: Float = 14f,
    bold: Boolean = false,
    alpha: Float = 1f,
    color: Color? = null,
    maxLines: Int = 1,
    modifier: Modifier = Modifier
) {
    BasicText(
        text,
        modifier,
        style = TextStyle(
            color = (color ?: LocalFg.current).copy(alpha = alpha),
            fontSize = size.sp,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal
        ),
        overflow = TextOverflow.Ellipsis,
        maxLines = maxLines
    )
}

/** Springy "press" animation + tap handling. */
@Composable
fun Modifier.bounceClick(onClick: () -> Unit): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(0.45f, 420f),
        label = "bounce"
    )
    val cb by rememberUpdatedState(onClick)
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    try {
                        tryAwaitRelease()
                    } finally {
                        pressed = false
                    }
                },
                onTap = { cb() }
            )
        }
}

@Composable
fun GlassButton(
    backdrop: Backdrop,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    tint: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalIsDark.current
    Box(
        modifier
            .size(size)
            .bounceClick(onClick)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { CircleShape },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(12f.dp.toPx(), 24f.dp.toPx())
                },
                onDrawSurface = {
                    if (tint != null) drawRect(tint.copy(alpha = 0.8f))
                    else drawRect(glassSurface(isDark))
                }
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun GlassPill(
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    tint: Color? = null,
    onClick: (() -> Unit)? = null,
    refract: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalIsDark.current
    val base = if (onClick != null) modifier.bounceClick(onClick) else modifier
    Box(
        base.drawBackdrop(
            backdrop = backdrop,
            shape = { Capsule() },
            effects = {
                vibrancy()
                blur(6f.dp.toPx())
                if (refract) lens(14f.dp.toPx(), 28f.dp.toPx())
            },
            onDrawSurface = {
                if (tint != null) drawRect(tint.copy(alpha = 0.6f))
                else drawRect(glassSurface(isDark, 0.35f))
            }
        ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun GlassSeekBar(
    backdrop: Backdrop,
    fraction: Float,
    onSeekFinished: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccent.current
    val fg = LocalFg.current
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    val finish by rememberUpdatedState(onSeekFinished)
    val shown = (if (dragging) dragFraction else fraction).coerceIn(0f, 1f)
    val thumbW = 40.dp
    val thumbH = 26.dp
    val thumbScale by animateFloatAsState(
        targetValue = if (dragging) 1.25f else 1f,
        animationSpec = spring(0.5f, 380f),
        label = "thumb"
    )

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .pointerInput(Unit) {
                val tw = thumbW.toPx()
                fun frac(x: Float): Float =
                    ((x - tw / 2f) / (size.width - tw).coerceAtLeast(1f)).coerceIn(0f, 1f)
                inspectDragGestures(
                    onDragStart = { down ->
                        dragging = true
                        dragFraction = frac(down.position.x)
                    },
                    onDragEnd = {
                        dragging = false
                        finish(dragFraction)
                    },
                    onDragCancel = { dragging = false }
                ) { change, _ ->
                    dragFraction = frac(change.position.x)
                }
            }
    ) {
        val density = LocalDensity.current
        val travel = with(density) { (maxWidth - thumbW).toPx() }
        val fillWidth = with(density) { (shown * travel + thumbW.toPx() / 2f).toDp() }

        Box(
            Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape)
                .background(fg.copy(alpha = 0.25f))
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .width(fillWidth)
                .height(6.dp)
                .clip(CircleShape)
                .background(accent)
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset { IntOffset((shown * travel).roundToInt(), 0) }
                .size(thumbW, thumbH)
                .graphicsLayer {
                    scaleX = thumbScale
                    scaleY = thumbScale
                }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { Capsule() },
                    effects = {
                        vibrancy()
                        blur(2f.dp.toPx())
                        lens(8f.dp.toPx(), 12f.dp.toPx())
                    },
                    onDrawSurface = { drawRect(Color.White.copy(alpha = 0.55f)) }
                )
        )
    }
}

fun fmtTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

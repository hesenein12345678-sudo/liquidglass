package com.glassplayer.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

/** Staggered reveal: fades/slides a block in as the player expands. */
private fun Modifier.reveal(progress: () -> Float, start: Float, rise: Dp): Modifier =
    graphicsLayer {
        val p = ((progress().coerceIn(0f, 1f) - start) / (1f - start)).coerceIn(0f, 1f)
        translationY = (1f - p) * rise.toPx()
        alpha = p
    }

@Composable
fun BigPlayer(
    progress: () -> Float,
    onDrag: (Float) -> Unit,
    onDragEnd: (Float) -> Unit,
    onClose: () -> Unit
) {
    val song = Player.current
    if (song == null) return
    val art = rememberArt(song, 900)
    val accent = LocalAccent.current
    val fg = LocalFg.current
    val isDark = LocalIsDark.current
    val wash = if (isDark) Color(0xFF0B0B12) else Color.White
    val playerBackdrop = rememberLayerBackdrop()
    var showLyrics by remember { mutableStateOf(false) }
    BackHandler(enabled = showLyrics) { showLyrics = false }
    val dragState = rememberDraggableState { delta -> onDrag(delta) }
    val artScale by animateFloatAsState(
        targetValue = if (Player.isPlaying) 1f else 0.84f,
        animationSpec = spring(0.55f, 260f),
        label = "art"
    )

    CompositionLocalProvider(LocalFg provides fg, LocalIsDark provides isDark) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val p = progress().coerceIn(0f, 1f)
                    translationY = (1f - p) * size.height
                    val s = lerp(0.92f, 1f, p)
                    scaleX = s
                    scaleY = s
                    alpha = (p * 2f).coerceIn(0f, 1f)
                    shape = RoundedCornerShape((44f * (1f - p)).dp)
                    clip = true
                }
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStopped = { v -> onDragEnd(v) }
                )
        ) {
            // same aurora background as the rest of the app, softly tinted by the cover
            Box(
                Modifier
                    .fillMaxSize()
                    .layerBackdrop(playerBackdrop)
            ) {
                AppBackground(
                    isDark,
                    if (AppTheme.adaptive && AppTheme.adaptiveColor != null) accent else null
                )
                if (art != null) {
                    Image(
                        bitmap = art,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = 1.35f
                                scaleY = 1.35f
                                alpha = 0.5f
                            }
                            .blur(80.dp, BlurredEdgeTreatment.Unbounded)
                    )
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(wash.copy(alpha = 0.10f), wash.copy(alpha = 0.40f))
                            )
                        )
                )
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 28.dp, vertical = 14.dp)
            ) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .size(44.dp, 5.dp)
                        .clip(CircleShape)
                        .background(fg.copy(alpha = 0.25f))
                )
                Spacer(Modifier.size(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .reveal(progress, 0.1f, 40.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassButton(playerBackdrop, onClose, size = 46.dp) {
                        Icon(Ic.Down, fg, 26.dp)
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Txt("Now Playing", 15f, bold = true, alpha = 0.85f)
                    }
                    if (AppTheme.lyricsEnabled) {
                        GlassButton(playerBackdrop, { showLyrics = true }, size = 46.dp) {
                            Icon(Ic.Lyrics, fg, 24.dp)
                        }
                    } else {
                        Spacer(Modifier.size(46.dp))
                    }
                }

                Spacer(Modifier.weight(0.5f))

                val artShape = RoundedCornerShape(38.dp)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .reveal(progress, 0.2f, 140.dp)
                        .graphicsLayer {
                            scaleX = artScale
                            scaleY = artScale
                        }
                        .shadow(30.dp, artShape, ambientColor = accent, spotColor = accent)
                        .background(accent.copy(alpha = 0.35f), artShape)
                        .border(1.dp, Color.White.copy(alpha = 0.5f), artShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (art != null) {
                        Image(
                            bitmap = art,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(artShape)
                        )
                    } else {
                        Icon(Ic.Note, fg.copy(alpha = 0.85f), 96.dp)
                    }
                }

                Spacer(Modifier.weight(0.45f))

                Column(
                    Modifier
                        .fillMaxWidth()
                        .reveal(progress, 0.35f, 90.dp)
                ) {
                    Txt(song.title, 26f, bold = true)
                    Spacer(Modifier.size(4.dp))
                    Txt(if (Player.isLoading) "Loading..." else song.artist, 16f, alpha = 0.7f)
                }

                Spacer(Modifier.weight(0.25f))

                Column(
                    Modifier
                        .fillMaxWidth()
                        .reveal(progress, 0.45f, 80.dp)
                ) {
                    val frac = if (Player.durationMs > 0)
                        Player.positionMs.toFloat() / Player.durationMs.toFloat() else 0f
                    GlassSeekBar(playerBackdrop, frac, onSeekFinished = { f ->
                        Player.seekTo((f * Player.durationMs).toLong())
                    })
                    Row(Modifier.fillMaxWidth()) {
                        Txt(fmtTime(Player.positionMs), 12f, alpha = 0.7f)
                        Spacer(Modifier.weight(1f))
                        Txt(fmtTime(Player.durationMs), 12f, alpha = 0.7f)
                    }
                }

                Spacer(Modifier.weight(0.3f))

                Row(
                    Modifier
                        .fillMaxWidth()
                        .reveal(progress, 0.55f, 80.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassButton(playerBackdrop, { Player.prev() }, size = 68.dp) {
                        Icon(Ic.Prev, fg, 30.dp)
                    }
                    GlassButton(playerBackdrop, { Player.toggle() }, size = 88.dp, tint = accent) {
                        Crossfade(targetState = Player.isPlaying, label = "pp") { playing ->
                            Icon(if (playing) Ic.Pause else Ic.Play, Color.White, 38.dp)
                        }
                    }
                    GlassButton(playerBackdrop, { Player.next() }, size = 68.dp) {
                        Icon(Ic.Next, fg, 30.dp)
                    }
                }

                Spacer(Modifier.weight(0.3f))
            }

            AnimatedVisibility(
                visible = showLyrics,
                enter = fadeIn() + slideInVertically { it / 4 },
                exit = fadeOut() + slideOutVertically { it / 4 }
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(14.dp)
                ) {
                    LyricsPanel(song, playerBackdrop) { showLyrics = false }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(
    backdrop: Backdrop,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val song = Player.current ?: return
    val art = rememberArt(song, 160)
    val accent = LocalAccent.current
    val fg = LocalFg.current

    GlassPill(
        backdrop,
        modifier = modifier
            .fillMaxWidth()
            .height(70.dp),
        onClick = onOpen,
        refract = true
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                if (art != null) {
                    Image(
                        bitmap = art,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Ic.Note, fg.copy(alpha = 0.85f), 24.dp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(song.title, 15f, bold = true)
                Txt(song.artist, 12f, alpha = 0.65f)
            }
            Box(
                Modifier
                    .size(46.dp)
                    .bounceClick { Player.toggle() },
                contentAlignment = Alignment.Center
            ) {
                Crossfade(targetState = Player.isPlaying, label = "mini") { playing ->
                    Icon(if (playing) Ic.Pause else Ic.Play, fg, 28.dp)
                }
            }
            Box(
                Modifier
                    .size(46.dp)
                    .bounceClick { Player.next() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Ic.Next, fg, 26.dp)
            }
        }
    }
}

package com.glassplayer.app

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

fun httpGet(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 12000
    c.readTimeout = 20000
    c.setRequestProperty("User-Agent", "GlassPlayer/1.0")
    try {
        return c.inputStream.bufferedReader().use { it.readText() }
    } finally {
        c.disconnect()
    }
}

data class OnlineItem(val id: String, val title: String, val creator: String)

data class OnlineTrack(val name: String, val title: String, val url: String, val sizeBytes: Long, val ext: String)

/** Online catalog: the Internet Archive (public search API, no key needed). */
object Archive {
    suspend fun search(query: String): List<OnlineItem> = withContext(Dispatchers.IO) {
        val clean = query.replace(Regex("[\"()\\[\\]{}:^~*?\\\\/]"), " ").trim()
        val q = URLEncoder.encode("($clean) AND mediatype:(audio)", "UTF-8")
        val url = "https://archive.org/advancedsearch.php?q=$q" +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator" +
            "&sort%5B%5D=downloads+desc&rows=40&page=1&output=json"
        val docs = JSONObject(httpGet(url)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<OnlineItem>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.getString("identifier")
            val creator = when (val c = d.opt("creator")) {
                is JSONArray -> if (c.length() > 0) c.optString(0) else ""
                is String -> c
                else -> ""
            }
            val title = when (val t = d.opt("title")) {
                is JSONArray -> if (t.length() > 0) t.optString(0) else ""
                is String -> t
                else -> ""
            }
            out.add(OnlineItem(id, title.ifBlank { id }, creator))
        }
        out
    }

    suspend fun tracks(item: OnlineItem): List<OnlineTrack> = withContext(Dispatchers.IO) {
        val files = JSONObject(httpGet("https://archive.org/metadata/${item.id}")).optJSONArray("files")
            ?: return@withContext emptyList()
        val mp3 = ArrayList<OnlineTrack>()
        val other = ArrayList<OnlineTrack>()
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val name = f.optString("name")
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext != "mp3" && ext != "ogg" && ext != "m4a") continue
            if (f.optString("format").contains("Sample", true)) continue
            val title = f.optString("title").ifBlank { name.substringAfterLast('/').substringBeforeLast('.') }
            val url = "https://archive.org/download/${item.id}/" +
                name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
            val t = OnlineTrack(name, title, url, f.optString("size", "0").toLongOrNull() ?: 0L, ext)
            if (ext == "mp3") mp3.add(t) else other.add(t)
        }
        (if (mp3.isNotEmpty()) mp3 else other).distinctBy { it.name }.sortedBy { it.name }
    }

    fun toSong(item: OnlineItem, t: OnlineTrack): Song = Song(
        id = -(abs(t.url.hashCode().toLong()) + 1L),
        title = t.title,
        artist = item.creator.ifBlank { item.title },
        album = item.title,
        durationMs = 0L,
        uri = android.net.Uri.parse(t.url),
        artUrl = "https://archive.org/services/img/${item.id}"
    )
}

/** Downloads a track into the device music library so it shows up in Home. */
object Downloads {
    val progress = mutableStateMapOf<String, Float>()
    val done = mutableStateMapOf<String, Boolean>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun toast(ctx: Context, msg: String) {
        scope.launch(Dispatchers.Main) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }

    fun start(ctx: Context, t: OnlineTrack, artist: String) {
        val app = ctx.applicationContext
        if (progress.containsKey(t.url) || done[t.url] == true) return
        progress[t.url] = 0f
        toast(app, "Downloading: ${t.title}")
        scope.launch {
            try {
                download(app, t, artist)
                done[t.url] = true
                progress.remove(t.url)
                toast(app, "Saved: ${t.title}")
                delay(1200)
                if (ContextCompat.checkSelfPermission(
                        app,
                        if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_AUDIO
                        else android.Manifest.permission.READ_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    val list = MusicRepository.load(app)
                    withContext(Dispatchers.Main) { Player.setLibrary(list) }
                }
            } catch (e: Exception) {
                progress.remove(t.url)
                toast(app, "Download failed")
            }
        }
    }

    private fun copy(input: InputStream, out: OutputStream, total: Long, key: String) {
        val buf = ByteArray(32 * 1024)
        var read = 0L
        var lastReported = 0f
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            read += n
            if (total > 0) {
                val f = read.toFloat() / total.toFloat()
                if (f - lastReported >= 0.02f) {
                    lastReported = f
                    progress[key] = f
                }
            }
        }
        out.flush()
    }

    private fun download(app: Context, t: OnlineTrack, artist: String) {
        val mime = when (t.ext) {
            "ogg" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            else -> "audio/mpeg"
        }
        val safe = t.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "track" }
        val conn = URL(t.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "GlassPlayer/1.0")
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "$safe.${t.ext}")
                    put(MediaStore.Audio.Media.MIME_TYPE, mime)
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Glass Player")
                    put(MediaStore.Audio.Media.TITLE, t.title)
                    put(MediaStore.Audio.Media.ARTIST, artist)
                    put(MediaStore.Audio.Media.IS_MUSIC, 1)
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
                val resolver = app.contentResolver
                val uri = resolver.insert(
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values
                ) ?: throw IOException("insert failed")
                try {
                    val out = resolver.openOutputStream(uri) ?: throw IOException("no stream")
                    out.use { copy(input, it, total, t.url) }
                    val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val dir = File(app.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Glass Player")
                dir.mkdirs()
                val f = File(dir, "$safe.${t.ext}")
                FileOutputStream(f).use { copy(input, it, total, t.url) }
                MediaScannerConnection.scanFile(app, arrayOf(f.absolutePath), null, null)
            }
        }
        conn.disconnect()
    }
}

private val categories = listOf(
    "Husseini poems" to "قصائد حسينية",
    "Latmiyat" to "لطميات",
    "Radood" to "رادود حسيني",
    "Majalis" to "مجالس حسينية",
    "Nasheed" to "husseini nasheed"
)

@Composable
fun LibraryScreen(bg: Backdrop) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val fg = LocalFg.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<OnlineItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<OnlineItem?>(null) }
    var tracks by remember { mutableStateOf<List<OnlineTrack>>(emptyList()) }

    fun runSearch(q: String) {
        if (q.isBlank()) return
        focus.clearFocus()
        selected = null
        scope.launch {
            loading = true
            error = null
            try {
                results = Archive.search(q)
                if (results.isEmpty()) error = "No results. Try another word."
            } catch (e: Exception) {
                error = "Could not reach the library. Check your internet."
            }
            loading = false
        }
    }

    fun openItem(item: OnlineItem) {
        selected = item
        tracks = emptyList()
        scope.launch {
            loading = true
            error = null
            try {
                tracks = Archive.tracks(item)
                if (tracks.isEmpty()) error = "No audio files in this item."
            } catch (e: Exception) {
                error = "Could not load this item."
            }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        if (results.isEmpty()) {
            query = categories[0].second
            runSearch(categories[0].second)
        }
    }
    BackHandler(enabled = selected != null) { selected = null; error = null }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            Modifier.padding(top = 18.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selected != null) {
                GlassButton(bg, { selected = null; error = null }, size = 44.dp) {
                    Icon(Ic.Back, fg, 22.dp)
                }
                Spacer(Modifier.width(12.dp))
                Box(Modifier.weight(1f)) { Txt(selected?.title ?: "", 20f, bold = true) }
            } else {
                Txt("Library", 34f, bold = true)
            }
        }

        // glass search bar + search button
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassPill(bg, Modifier.weight(1f).height(52.dp)) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp), contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Txt("Search songs and poems...", 15f, alpha = 0.5f)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = fg, fontSize = 16.sp),
                        cursorBrush = SolidColor(accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { runSearch(query) }),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            GlassButton(bg, { runSearch(query) }, size = 52.dp, tint = accent) {
                Icon(Icons.Filled.Search, Color.White, 26.dp)
            }
        }

        if (selected == null) {
            Row(
                Modifier
                    .padding(vertical = 12.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { (label, q) ->
                    PillButton(bg, label, { query = q; runSearch(q) })
                }
            }
        } else {
            Spacer(Modifier.height(12.dp))
        }

        when {
            loading -> Txt("Loading...", 16f, alpha = 0.7f, modifier = Modifier.padding(8.dp))
            error != null -> MessageCard(bg, error ?: "", null, {})
            selected != null -> LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 250.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val item = selected!!
                itemsIndexed(tracks, key = { _, t -> t.url }) { i, t ->
                    TrackRow(bg, item, t) {
                        Player.playQueue(tracks.map { Archive.toSong(item, it) }, i, false)
                    }
                }
            }
            else -> LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 250.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(results, key = { _, r -> r.id }) { _, item ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .bounceClick { openItem(item) }
                            .glassBox(bg, RoundedCornerShape(24.dp), glassSurface(LocalIsDark.current, 0.32f), 10f)
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Txt(item.title, 16f, bold = true, maxLines = 2)
                        if (item.creator.isNotBlank()) Txt(item.creator, 13f, alpha = 0.6f)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackRow(bg: Backdrop, item: OnlineItem, t: OnlineTrack, onPlay: () -> Unit) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val fg = LocalFg.current
    val isDark = LocalIsDark.current
    val prog = Downloads.progress[t.url]
    val saved = Downloads.done[t.url] == true
    val playing = Player.current?.uri?.toString() == t.url

    Row(
        Modifier
            .fillMaxWidth()
            .glassBox(bg, RoundedCornerShape(24.dp), glassSurface(isDark, if (playing) 0.55f else 0.32f), 10f)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Txt(t.title, 15f, bold = true, maxLines = 2, color = if (playing) accent else null)
            val mb = if (t.sizeBytes > 0) "%.1f MB".format(t.sizeBytes / 1048576.0) else ""
            Txt(
                when {
                    prog != null -> "Downloading ${(prog * 100).toInt()}%"
                    saved -> "Saved to your music"
                    else -> mb
                },
                12f, alpha = 0.6f
            )
        }
        Spacer(Modifier.width(8.dp))
        GlassButton(bg, onPlay, size = 44.dp) { Icon(Ic.Play, fg, 22.dp) }
        Spacer(Modifier.width(8.dp))
        GlassButton(
            bg,
            { Downloads.start(ctx, t, item.creator.ifBlank { item.title }) },
            size = 44.dp,
            tint = if (saved) accent else null
        ) { Icon(if (saved) Ic.Check else Ic.Download, if (saved) Color.White else fg, 22.dp) }
    }
}

package com.glassplayer.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalIsDark = staticCompositionLocalOf { true }
val LocalFg = staticCompositionLocalOf { Color.White }
val LocalAccent = staticCompositionLocalOf { Color(0xFF0088FF) }

object AppTheme {
    val palette: List<Color> = listOf(
        Color(0xFF0088FF), Color(0xFF00B8D4), Color(0xFF00BFA5), Color(0xFF1DE9B6),
        Color(0xFF34C759), Color(0xFF76FF03), Color(0xFFC6FF00), Color(0xFFFFD60A),
        Color(0xFFFFAB00), Color(0xFFFF9500), Color(0xFFFF6D00), Color(0xFFFF3B30),
        Color(0xFFFF1744), Color(0xFFFF4081), Color(0xFFFF2D92), Color(0xFFE040FB),
        Color(0xFFAF52DE), Color(0xFF7C4DFF), Color(0xFF5856D6), Color(0xFF3D5AFE),
        Color(0xFF2979FF), Color(0xFF64D2FF), Color(0xFFA2845E), Color(0xFF8E8E93)
    )

    var accentIndex by mutableIntStateOf(0)
    // 0 = follow system, 1 = dark, 2 = light
    var darkMode by mutableIntStateOf(0)
    var adaptive by mutableStateOf(false)
    var adaptiveColor by mutableStateOf<Color?>(null)
    var glassEnabled by mutableStateOf(true)
    var fadeEnabled by mutableStateOf(false)
    var lyricsEnabled by mutableStateOf(false)
    var barBlur by mutableFloatStateOf(8f)
    var barRefraction by mutableFloatStateOf(24f)
    var barAlpha by mutableFloatStateOf(0.4f)
    var barColorIndex by mutableIntStateOf(-1)
    var iconIndex by mutableIntStateOf(0)

    val accent: Color
        get() {
            val base = palette[accentIndex.coerceIn(0, palette.lastIndex)]
            return if (adaptive) (adaptiveColor ?: base) else base
        }

    val barColor: Color? get() = palette.getOrNull(barColorIndex)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        accentIndex = p.getInt("accent", 0)
        darkMode = p.getInt("dark", 0)
        adaptive = p.getBoolean("adaptive", false)
        glassEnabled = p.getBoolean("glass", true)
        fadeEnabled = p.getBoolean("fade", false)
        lyricsEnabled = p.getBoolean("lyrics", false)
        barBlur = p.getFloat("barBlur", 8f)
        barRefraction = p.getFloat("barRefraction", 24f)
        barAlpha = p.getFloat("barAlpha", 0.4f)
        barColorIndex = p.getInt("barColor", -1)
        iconIndex = p.getInt("icon", 0)
    }

    fun setAccent(ctx: Context, v: Int) { accentIndex = v; prefs(ctx).edit().putInt("accent", v).apply() }
    fun setDarkMode(ctx: Context, v: Int) { darkMode = v; prefs(ctx).edit().putInt("dark", v).apply() }
    fun setAdaptive(ctx: Context, v: Boolean) { adaptive = v; prefs(ctx).edit().putBoolean("adaptive", v).apply() }
    fun setGlass(ctx: Context, v: Boolean) { glassEnabled = v; prefs(ctx).edit().putBoolean("glass", v).apply() }
    fun setFade(ctx: Context, v: Boolean) { fadeEnabled = v; prefs(ctx).edit().putBoolean("fade", v).apply() }
    fun setLyrics(ctx: Context, v: Boolean) { lyricsEnabled = v; prefs(ctx).edit().putBoolean("lyrics", v).apply() }
    fun setBarBlur(ctx: Context, v: Float) { barBlur = v; prefs(ctx).edit().putFloat("barBlur", v).apply() }
    fun setBarRefraction(ctx: Context, v: Float) { barRefraction = v; prefs(ctx).edit().putFloat("barRefraction", v).apply() }
    fun setBarAlpha(ctx: Context, v: Float) { barAlpha = v; prefs(ctx).edit().putFloat("barAlpha", v).apply() }
    fun setBarColor(ctx: Context, v: Int) { barColorIndex = v; prefs(ctx).edit().putInt("barColor", v).apply() }
    fun setIcon(ctx: Context, v: Int) { iconIndex = v; prefs(ctx).edit().putInt("icon", v).apply() }
}

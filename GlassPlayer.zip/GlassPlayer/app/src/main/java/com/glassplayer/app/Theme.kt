package com.glassplayer.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalIsDark = staticCompositionLocalOf { true }
val LocalFg = staticCompositionLocalOf { Color.White }
val LocalAccent = staticCompositionLocalOf { Color(0xFF0088FF) }

object AppTheme {
    val palette: List<Color> = listOf(
        Color(0xFF0088FF), Color(0xFF00B8D4), Color(0xFF00BFA5), Color(0xFF1DE9B6),
        Color(0xFF34C759), Color(0xFF76FF03), Color(0xFFC6FF00), Color(0xFFFFD60A),
        Color(0xFFFFAB00), Color(0xFFFF9500), Color(0xFFFF6D00), Color(0xFFFF3B30),
        Color(0xFFFF1744), Color(0xFFFF4081), Color(0xFFFF2D92), Color(0xFFE040FB),
        Color(0xFFAF52DE), Color(0xFF7C4DFF), Color(0xFF5856D6), Color(0xFF3D5AFE),
        Color(0xFF2979FF), Color(0xFF64D2FF), Color(0xFFA2845E), Color(0xFF8E8E93)
    )

    var accentIndex by mutableIntStateOf(0)
    // 0 = follow system, 1 = dark, 2 = light
    var darkMode by mutableIntStateOf(0)

    val accent: Color get() = palette[accentIndex.coerceIn(0, palette.lastIndex)]

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)
        accentIndex = p.getInt("accent", 0)
        darkMode = p.getInt("dark", 0)
    }

    fun setAccent(ctx: Context, index: Int) {
        accentIndex = index
        ctx.getSharedPreferences("theme", Context.MODE_PRIVATE).edit().putInt("accent", index).apply()
    }

    fun setDarkMode(ctx: Context, mode: Int) {
        darkMode = mode
        ctx.getSharedPreferences("theme", Context.MODE_PRIVATE).edit().putInt("dark", mode).apply()
    }
}

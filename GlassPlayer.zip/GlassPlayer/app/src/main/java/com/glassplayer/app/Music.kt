package com.glassplayer.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri
)

object MusicRepository {
    fun load(ctx: Context): List<Song> {
        val list = ArrayList<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            ctx.contentResolver.query(collection, projection, selection, null, order)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = c.getString(iArtist)
                    list.add(
                        Song(
                            id = id,
                            title = c.getString(iTitle) ?: "Unknown",
                            artist = if (artist == null || artist == "<unknown>") "Unknown artist" else artist,
                            album = c.getString(iAlbum) ?: "",
                            durationMs = c.getLong(iDur),
                            uri = ContentUris.withAppendedId(collection, id)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return list
    }
}

object ArtLoader {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = HashSet<String>()

    suspend fun load(ctx: Context, song: Song, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "${song.id}_$px"
        cache.get(key)?.let { return@withContext it }
        if (synchronized(missing) { missing.contains(key) }) return@withContext null

        var bmp: Bitmap? = null
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                bmp = ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            } catch (_: Throwable) {
            }
        }
        if (bmp == null) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, song.uri)
                val bytes = r.embeddedPicture
                r.release()
                if (bytes != null) {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var sample = 1
                    while (o.outWidth / (sample * 2) >= px) sample *= 2
                    val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
                    bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                }
            } catch (_: Throwable) {
            }
        }
        if (bmp != null) cache.put(key, bmp) else synchronized(missing) { missing.add(key) }
        bmp
    }
}

@Composable
fun rememberArt(song: Song?, px: Int): ImageBitmap? {
    val ctx = LocalContext.current.applicationContext
    val state: State<ImageBitmap?> = produceState<ImageBitmap?>(null, song?.id, px) {
        value = if (song == null) null else ArtLoader.load(ctx, song, px)?.asImageBitmap()
    }
    return state.value
}
